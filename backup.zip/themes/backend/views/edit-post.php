<?php require_once 'header.php'; ?>

            <!-- Main content -->
            <div class="content-wrapper">
                <!-- Page header -->
                <div class="page-header">
                    <div class="page-header-content">
                        <div class="page-title">
                            <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                        </div>

                        <div class="heading-elements">
                            <div class="heading-btn-group">
                                <a href="<?php echo base_url('admin/new_post') ?>" class="btn btn-link btn-float has-text"><i class="icon-plus2 text-primary"></i><span>Thêm bài viết</span></a>
                            </div>
                        </div>
                        <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
                    </div>
                    <div class="breadcrumb-line">
                        <ol class="breadcrumb">
                            <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                            <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                        </ol>
                    </div>
                </div>
                <!-- /page header -->
                <!-- Content area -->
                <div class="content">
                    <?php echo form_open_multipart('admin/post_edit/' . $post['id'], array('id' => 'edit_product', 'name' => 'edit_product')); ?>
                        <div class="row blogs-form">
                            <div class="col-md-9">
                                <div class="panel panel-flat">
                                    <div class="panel-body">
                                        <?php if(validation_errors() != false): ?>
                                        <div class="alert alert-danger">
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <strong>Có lỗi xảy ra!</strong>
                                            <ul>
                                                <?php echo validation_errors('<li>' , '</li>'); ?>
                                            </ul>
                                        </div>
                                        <?php endif; ?>
                                        <ul class="nav nav-tabs" id="theTab">
                                            <li class="active"><a data-target="#general" data-toggle="tab">Thông tin chung</a></li>
                                            <li><a data-target="#seo" data-toggle="tab">SEO</a></li>
                                        </ul>
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="general">
                                                <!-- Tiêu đề Start -->
                                                <div class="form-group">
                                                    <label for="title">Tên sản phẩm</label>
                                                    <?php if(isset($_SESSION['post']['title'])): $title = $_SESSION['post']['title']; else: $title = $post['title']; endif; ?>
                                                    <?php echo form_input('title', $title, 'class="form-control post-title" id="postTitle" placeholder="Tên sản phẩm"') ?>
                                                </div>
                                                <!-- Tiêu đề END -->
                                                <!-- Slug Start -->
                                                <div class="form-group">
                                                    <label for="slug">Slug</label>
                                                    <?php if(isset($_SESSION['post']['slug'])): $slug = $_SESSION['post']['slug']; else: $slug = $post['slug']; endif; ?>
                                                    <?php echo form_input('slug', $slug, 'class="form-control post-slug" id="postSlug" placeholder="Đường dẫn tới sản phẩm"') ?>
                                                </div>
                                                <!-- Slug END -->
                                                <!-- Excerpt Start -->
                                                <div class="form-group">
                                                    <label for="excerpt">Mô tả ngắn</label>
                                                    <?php if(isset($_SESSION['post']['excerpt'])): $excerpt = $_SESSION['post']['excerpt']; else: $excerpt = $post['excerpt']; endif; ?>
                                                    <?php echo form_textarea('excerpt', $excerpt, 'class="form-control post-excerpt" rows="3" cols="40" style="height: 100px" id="excerpt"') ?>
                                                </div>
                                                <!-- Excerpt excerpt -->
                                                <!-- Body Start -->
                                                <div class="form-group">
                                                    <?php if(isset($_SESSION['post']['content'])): $content = $_SESSION['post']['content']; else: $content = $post['content']; endif; ?>
                                                    <?php echo form_textarea('content', $content, 'class="form-control" rows="5" cols="50" id="content"') ?>
                                                </div>
                                                <!-- Body End -->
                                            </div>
                                            <div class="tab-pane" id="seo">
                                                <div class="form-group" style="max-width: 600px">
                                                    <div class="sample-title" id="sample-title"></div>
                                                    <div class="sample-url" id="sample-url"></div>
                                                    <div class="sample-meta-description">
                                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto corporis
                                                        deserunt
                                                        iusto laboriosam molestiae nostrum quaerat rerum sed, voluptatum? A dignissimos
                                                        dolorem
                                                        error iusto molestias quas quisquam rem rerum. Error!
                                                    </div>
                                                </div>
                                                <!-- Tiêu đề Start -->
                                                <div class="form-group">
                                                    <label for="seo_title">Seo Title</label>
                                                    <?php if(isset($_SESSION['post']['title_seo'])): $title_seo = $_SESSION['post']['title_seo']; else: $title_seo= $post['title_seo']; endif; ?>
                                                    <?php echo form_input('title_seo', $title_seo, 'class="form-control seo-title" id="seo_title"') ?>
                                                </div>
                                                <!-- Tiêu đề END -->
                                                <!-- Excerpt Start -->
                                                <div class="form-group">
                                                    <label for="meta_description">Meta Description</label>
                                                    <?php if(isset($_SESSION['post']['description'])): $description = $_SESSION['post']['description']; else: $description = $post['description']; endif; ?>
                                                    <?php echo form_textarea('description', $description, 'class="form-control meta-description" rows="3" cols="40" style="height: 100px" id="meta_description"') ?>
                                                </div>
                                                <!-- Excerpt excerpt -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <!-- Panel _start -->
                                <div class="panel-flat">
                                    <div class="panel-body thumbnail">
                                        <?php if($post['thumbnail']): ?>
                                            <input type="hidden" name="old_thumb" value="<?php echo $post['thumbnail']; ?>">
                                        <?php endif; ?>
                                        <h5>Ảnh đại diện</h5>
                                        <div id="kvt-thumbnail-errors" class="center-block" style="display:none"></div>
                                        <div class="kvt-thumbnail center-block" style="width:100%">
                                            <input type="file" id="thumbnail" name="thumbnail_post" class="file-loading file-styled">
                                        </div>
                                    </div>
                                </div>
                                <!-- Panel End -->
                                <!-- Panel _start -->
                                <div class="panel panel-flat">
                                    <div class="panel-body">
                                        <h5>Danh mục</h5>
                                        <div class="form-group">
                                            <select name="cat_id" class="form-control select2">
                                                <option value="">-- Chọn danh mục --</option>
                                                <?php echo $cat_post; ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label><input type="checkbox" name="status" value="1" <?php echo (!empty($post['status']))? 'checked' : '' ?> /> Post HOT</label>
                                        </div>
                                    </div>
                                </div>
                                <!-- Panel End -->

                                <div class="panel panel-flat">
                                    <div class="panel-body">
                                        <h5>Tags</h5>
                                        <?php if(!empty($post['tag'])) $l_tags = $post['tag']; else $l_tags = ''; ?>
                                        <?php if(isset($_SESSION['post']['tags'])): $tags = $_SESSION['post']['tags']; else: $tags = $l_tags; endif; ?>
                                        <?php echo form_input('tags', $tags, 'id="tags-input" class="form-control"') ?>
                                        <div class="help-block">
                                            Gõ tag, sau đó nhấn enter hoặc dấu "," để hoàn thành thêm tag
                                        </div>
                                    </div>
                                </div>

                                <div class="panel panel-flat">
                                    <div class="panel-body">
                                        <h5>Xuất bản</h5>
                                        <!-- Submit -->
                                        <div class="">
                                            <button name="button" value="save_and_exists" class="btn btn-primary">Lưu lại</button>
                                            <button name="button" value="save" class="btn btn-info">Lưu & thoát</button>
                                            <a href="<?php echo base_url('admin/list-product.html') ?>" class="btn btn-default">Hủy</a>
                                        </div>
                                        <!-- Submit End -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php echo form_close(); ?>
                    </div>
                    <!-- /content area -->
                </div>
                <!-- /main content -->
            </div>
        </div>
        <!-- /page container -->
        <script>
            CKEDITOR.replace('content', {
                height: 400,
            });
            $('#ButtonCreationDemoButton').click(function (e) {
                $('#ButtonCreationDemoInput').AnyTime_noPicker().AnyTime_picker().focus();
                e.preventDefault();
            });
            $('#tags-input, #size-input, #color-input').tokenfield({

            });
        </script>
        <script>
            $("#thumbnail").fileinput({
                overwriteInitial: true,
                maxFileSize: 1500,
                showClose: false,
                showCaption: false,
                browseLabel: '',
                removeLabel: '',
                browseIcon: '<i class="glyphicon glyphicon-folder-open"></i>',
                removeIcon: '<i class="glyphicon glyphicon-remove"></i>',
                removeTitle: 'Cancel or reset changes',
                elErrorContainer: '#kvt-thumbnail-errors',
                msgErrorClass: 'alert alert-block alert-danger',
                defaultPreviewContent: '<img src="<?php echo $post['thumbnail_url'] ?>" alt="Hình thumbnail" style="width:100%">',
                layoutTemplates: {main2: '{preview} ' + ' {remove} {browse}'},
                allowedFileExtensions: ["jpg", "png", "gif"]
            });
        </script>
    </body>
</html>
