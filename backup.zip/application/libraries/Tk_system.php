<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CodeIgniter Template Class
 *
 * Build your CodeIgniter pages much easier with partials, breadcrumbs, layouts and themes
 *
 * @package			CodeIgniter
 * @subpackage		Libraries
 * @category		Libraries
 * @author			Tam Kieu
 * @license			http://tamkieu.com
 * @link			http://tamkieu.com
 */
class Tk_system {
  function __construct($config = array()) {
      $this->_ci = & get_instance();
      if (!empty($config)) {
          $this->initialize($config);
      }
      log_message('debug', 'Template Class Initialized');
  }
  public function pagination($number = 30, $name) {
      $config['per_page'] = $number;
      $config['full_tag_open'] = '<ul class="pagination"><li class="page-item">';
      $config['full_tag_close'] = '</li></ul>';
      $config['attributes'] = array('class' => 'page-link');
      $config['first_link'] = 'Trang đầu';
      $config['last_link'] = 'Trang cuối';
      $config['next_link'] = '<i class="fa fa-angle-double-right"></i>';
      $config['prev_link'] = '<i class="fa fa-angle-double-left"></i>';
      $config['base_url'] = base_url($name);
      return $config;
  }
  private function stripHTMLtags($str) {
      $t = preg_replace('/<[^<|>]+?>/', '', htmlspecialchars_decode($str));
      $t = htmlentities($t, ENT_QUOTES, "UTF-8");
      return $t;
  }
  public function file_edit($path_dir, $name_sl, $old_thumb = false) {
      $path = dirname(BASEPATH) . '/uploads/' . $path_dir . '/';
      $tmp_name = $_FILES[$name_sl]['tmp_name'];
      $name = $_FILES[$name_sl]['name'];
      $array = explode('.', $name);
      $n = count($array);
      $name_file = md5(microtime() . rand(1, 1000));
      $new_name = $name_file . '.' . $array[$n - 1];
      if ($old_thumb != false) {
          $path_old = dirname(BASEPATH) . '/uploads/' . $path_dir . '/' . $old_thumb;
          unlink($path_old);
      }
      move_uploaded_file($tmp_name, $path . $new_name);
      return $new_name;
  }
}
