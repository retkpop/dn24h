<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Pages extends CI_Controller {
		public function __construct() {
	      parent::__construct();
				if ($this->router->fetch_method() != 'login' && $this->router->fetch_method() != 'register') {
            if (!isset($_SESSION['loggedInUser']) || $_SESSION['loggedInUser']['type'] != 1) {
                redirect('admin/login');
            }
        }
	      $this->load->library('session');  //Load the Session
	      $this->template->set_theme('backend');
	      date_default_timezone_set('Asia/Saigon');
	      $method = $this->router->fetch_method();
	      $this->template->set('page', $method)->set_breadcrumb('Pages', base_url('index'));
	      //pagination
	      $this->load->library('pagination');
				$this->load->helper('url');
	      $this->load->helper('text');
				$this->load->model('page_m');
	  }
    public function list_page() {
        $config = $this->pagination(30, 'list_page');
        $config['total_rows'] = $this->page_m->count_all_pages();
        $this->pagination->initialize($config);
        $data['all_pages'] = $this->page_m->all_pages($config['per_page'],$this->uri->segment(3));
        $this->template->title('Danh sách trang')->build('list-page',$data);
    }
    public function page_edit($id) {
        $val = $this->validation_page();
        if($val != false) {
            $button = $_POST['button'];
            unset($_POST['button']);
            $page_update = $this->page_m->page_edit($this->input->post(), $id);
            if($button == 'save_and_edit') {
                redirect('admin/page_edit/'.$id);
            } else {
                redirect('admin/list_page');
            }
        } else {
            $data['data_page'] = $this->page_m->data_page($id);
            $this->template->title('Chỉnh sửa trang')->build('edit-page', $data);
        }
    }
    public function new_page() {
        $val = $this->validation_page();
        if($val != false) {
            $button = $_POST['button'];
            unset($_POST['button']);
            $_POST['author_id'] = $_SESSION['loggedInUser']['id'];
            $_POST['date_post'] = date("Y-m-d");
            $page_id = $this->page_m->insert_page($this->input->post());
            if($page_id != false){
                if($button == 'save_and_edit') {
                    redirect('admin/page_edit/'.$page_id);
                } else {
                    redirect('admin/list_page');
                }
            } else {
                echo 'Cập nhật bài viết không thành công, vui lòng kiểm tra lại các trường bạn nhập liệu';
            }
        } else {
            $this->template->title('Thêm trang mới')->build('new-page');
        }
    }
    public function bulk_action_page() {
        if(!empty($_POST['bulk_action_page'])) {
            if(isset($_POST['id'])) {
                if($_POST['bulk_action_page'] == 'delete') {
                    foreach ($_POST['id'] as $value) {
                        $this->page_m->delete_page($value);
                    }
                }
            }
        }
        redirect('admin/list_page');
    }

    public function delete_page($id) {
        $this->page_m->delete_page($id);
        redirect('admin/list_page');
    }
		public function validation_page() {
        $rules = array(
            array(
                'field' => 'title',
                'label' => 'Tên bài viết',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'title_seo',
                'label' => 'Tiêu đề SEO',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'slug',
                'label' => 'Đường dẫn tới bài viết',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'content',
                'label' => 'Nội dung bài viết',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'description',
                'label' => 'Description',
                'rules' => 'trim|required'
            )
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run($this)) {
            return true;
        } else {
            return false;
        }
    }
    public function pagination($number = 30, $name) {
        $config['per_page'] = $number;
        $config['full_tag_open'] = '<ul class="pagination"><li class="page-item">';
        $config['full_tag_close'] = '</li></ul>';
        $config['attributes'] = array('class' => 'page-link');
        $config['first_link'] = 'Trang đầu';
        $config['last_link'] = 'Trang cuối';
        $config['next_link'] = '<i class="fa fa-angle-double-right"></i>';
        $config['prev_link'] = '<i class="fa fa-angle-double-left"></i>';
        $config['base_url'] = base_url('admin/'.$name);
        return $config;
    }
		public function createSlug($str) {
        if ((bool) $str == false) {
            exit('');
        }
        $str = mb_strtolower(urldecode($str));
        echo url_title(removesign($str), '-');
    }
}
