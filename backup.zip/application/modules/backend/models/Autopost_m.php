<?php

  Class Autopost_m extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    public function insert_auto_post($input) {
        $query = $this->db->where("slug", $input['slug'])->get("posts");
        if($query->num_rows()>0) {
            return false;
        } else {
            $this->db->insert('posts', $input);
            return true;
        }
    }
    public function add_auto_post($input) {
        $query = $this->db->where('slug', $input['slug'])->get('posts');
        if($query->num_rows()==0) {
            $this->db->insert('posts', $input);
        }
    }
    public function check_post($slug) {
        $check = $this->db->where("slug", $slug)->get("posts");
        if($check->num_rows()>0) {
            return 001;
        } else {
            return 0;
        }
    }
    public function add_site($input) {
        $query = $this->db->where("name_site")->get("auto_post");
        if($query->num_rows() > 0) {
            return false;
        } else {
            try{
                $this->db->insert("auto_post", $input);
                return true;
            } catch (Exception $ex) {
                return false;
            }
        }
    }
    public function get_listSite() {
        $query = $this->db->order_by('name_site', 'asc')->get("auto_post");
        if($query->num_rows()>0) {
            return $query->result_array();
        } else {
            return false;
        }
    }
    public function get_site_auto_post($url) {
        $query = $this->db->where("url", $url)->get("auto_post")->row_array();
        return $query;
    }
    public function site_auto_post() {
        $site = $this->db->order_by("id", "desc")->get("auto_post");
        if($site->num_rows()>0) {
            return $site->result_array();
        } else {
            return false;
        }
    }
  }
?>
