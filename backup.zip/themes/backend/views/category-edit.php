<?php require_once 'header.php'; ?>

                <!-- Main content -->
                <div class="content-wrapper">
                    <!-- Page header -->
                    <div class="page-header">
                        <div class="page-header-content">
                            <div class="page-title">
                                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                            </div>

                            <div class="heading-elements">
                                <div class="heading-btn-group">
                                    <a href="" class="btn btn-link btn-float has-text"><i class="icon-plus2 text-primary"></i><span>Thêm bài viết</span></a>
                                </div>
                            </div>
                            <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
                        </div>
                        <div class="breadcrumb-line">
                            <ol class="breadcrumb">
                                <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                                <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                            </ol>
                        </div>
                    </div>
                    <!-- /page header -->


                    <!-- Content area -->
                    <div class="content">
                        <div class="col-md-12">
                            <?php if(isset($_SESSION['return_add'])): ?>
                            <div class="flash alert <?php echo ($_SESSION['return_add'] == 0)? 'alert-error': 'alert-success' ?> alert-styled-left">
                                <?php if($_SESSION['return_add'] == 0): ?>
                                <span class="text-semibold">Lỗi! </span> Danh mục đã tồn tại
                                <?php else: ?>
                                <span class="text-semibold">Thành công </span> Chỉnh sửa danh mục thành công
                                <?php endif; ?>
                                <div class="heading-elements">
                                    <ul class="icons-list">
                                        <li><a class="close" data-action="close"></a></li>
                                    </ul>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(validation_errors() != false): ?>
                            <div class="alert alert-danger">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <strong>Có lỗi xảy ra!</strong>
                                <ul>
                                    <?php echo validation_errors('<li>' , '</li>'); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="clearfix"></div>
                        <?php echo form_open_multipart('admin/edit_cat?id=' .$category['id']) ?>
                            <!-- Panel _start -->
                            <div class="panel panel-flat">
                                <div class="panel-heading">
                                    <h5>Thêm danh mục</h5>
                                    <div class="heading-elements">
                                        <ul class="icons-list">
                                            <li><a data-action="collapse"></a></li>
                                            <li><a data-action="reload"></a></li>
                                            <li><a data-action="close"></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <!-- Tiêu đề Start -->
                                    <div class="form-group">
                                        <label for="name">Tên danh mục</label>
                                        <?php if(isset($_POST['title'])): $title = $_POST['title']; else: $title = $category['title']; endif; ?>
                                        <?php echo form_input('title', $title, 'class="form-control" id="title" placeholder="Tên danh mục sản phẩm"') ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="title_seo">Tên danh mục hiện ở title</label>
                                        <?php if(isset($_POST['title_seo'])): $title_seo = $_POST['title_seo']; else: $title_seo = $category['title_seo']; endif; ?>
                                        <?php echo form_input('title_seo', $title_seo, 'class="form-control" id="title_seo" placeholder="Tên danh mục sản phẩm hiện ở title"') ?>
                                    </div>
                                    <!-- Tiêu đề END -->

                                    <!-- URI Start -->
                                    <div class="form-group">
                                        <label for="slug">Slug</label>
                                        <?php if(isset($_POST['slug'])): $slug = $_POST['slug']; else: $slug = $category['slug']; endif; ?>
                                        <?php echo form_input('slug', $slug, 'class="form-control" id="slug" placeholder="Đường dẫn tới danh mục"') ?>
                                    </div>
                                    <!-- URI END -->
                                    <?php if(!empty($_GET['categorys_product'])): ?>
                                    <div class="form-group row">
                                        <label for="" class="col-md-12">Parent</label>
                                        <div class="col-md-8">
                                            <select name="parent" class="form-control select2">
                                                <option value="">-- Chọn danh mục --</option>
                                                <?php echo $all_cat; ?>
                                            </select>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div class="help-block col-xs-12">
                                            Danh mục cha
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <!-- URI Start -->
                                    <div class="form-group">
                                        <label for="">Mô tả</label>
                                        <?php if(isset($_POST['description'])): $description = $_POST['description']; else: $description = $category['description']; endif; ?>
                                        <?php echo form_textarea('description', $description, 'class="form-control" rows="3" cols="40" style="height: 100px" id="description"') ?>
                                    </div>
                                    <!-- URI END -->
                                    <button type="submit" class="btn btn-primary">Lưu lại</button>
                                </div>
                            </div><!-- Panel End -->
                        <?php echo form_close(); ?>
                    </div>
                </div>
                <script>
                    $(document).ready(function () {
                        $('#title').on('change, keyup', function () {
                            var value = $(this).val();
                            var uri;
                            if (value == '') {
                                uri =  ' ';
                            } else {
                                uri = value;
                            }
                            $.ajax({
                                url: encodeURI('<?php echo base_url('admin/createSlug/') ?>/' + uri),
                                success: function (data) {
                                    $('#slug').val(data);
                                }
                            });
                        });
                    })
                </script>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
    </body>
</html>
