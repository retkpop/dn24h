<?php

Class Single_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    function add_viewer($id)
    {
        $this->db->where('id', $id)->set('views', 'views+1', FALSE)->update('posts'); //tại id cần thêm
    }
    public function single_post($slug, $id) {
        $post = $this->db->where('id', $id)->where('slug', $slug)->get('posts');
        if($post->num_rows()>0) {
            $post = $post->row_array();
            $author = $this->db->where('id', $post['author_id'])->get('users')->row_array();
            $cat = $this->db->where('id', $post['cat_id'])->get('categories_post')->row_array();

            $date = date_create($post['date_post']);
            $name_sl = date_format($date,"Y/m");
            $post['date_post'] = date_format($date,"d/m/Y");

            if($post['thumbnail'] == '') {
                $post['thumbnail'] = base_url('uploads/thumbnail_post/no-thumbnail.jpg');
            } else {
                $post['thumbnail'] = base_url('uploads/thumbnail_post/' . $name_sl . '/' . $post['thumbnail']);
            }
            $post['url'] = base_url($post['slug'] . '-' . $post['id'] . '.html');
            $post['cat_name'] = $cat['title'];
            $post['url_cat'] = base_url('danhmuc/'. $cat['slug'].'.html');
            $post['author_name'] = $author['last_name'] . ' ' . $author['first_name'];
            return $post;
        }
        return false;
    }
    public function related_articles($id_post, $id_cat, $limit) {
      $posts = $this->db->order_by('id', 'desc')->limit($limit)->where('cat_id', $id_cat)->get('posts');
      if($posts->num_rows()>0) {
          $posts = $posts->result_array();
          foreach ($posts as $key => $post) {
              if($post['id'] == $id_post) {
                  unset($posts[$key]);
              }
          }
          if(!empty($posts)) {
              foreach ($posts as $value) {
                  $date = date_create($value['date_post']);
                  $name_sl = date_format($date,"Y/m");
                  $value['date_post'] = date_format($date,"d/m/Y");
                  $value['url'] = base_url($value['slug'] . '-' . $value['id'] . '.html');
                  if($value['thumbnail'] == '') {
                      $value['thumbnail'] = base_url('uploads/thumbnail_post/no-thumbnail.jpg');
                  } else {
                      $value['thumbnail'] = base_url('uploads/thumbnail_post/' . $name_sl . '/' . $value['thumbnail']);
                  }
                  $data[] = $value;
              }
              return $data;
          } else {
              return false;
          }
      } else {
          return false;
      }
    }
}
?>
