<?php

Class User_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function count_all_users() {
        return $this->db->count_all('users');
    }
    public function all_user() {
        $query = $this->db->get('users');
        if($query->num_rows()>0) {
            return $query->result_array();
        } else {
            return false;
        }
    }
    public function all_subscribe($number, $offset) {
        $query = $this->db->get('subscribes',$number,$offset);
        if($query->num_rows()>0) {
            return $query->result_array();
        } else {
            return false;
        }
    }
    public function delete_subscribe($id) {
        $this->db->where('id', $id)->delete('subscribes');
    }
    public function all_kh() {
        $query = $this->db->get('subscribes');
        if($query->num_rows()>0) {
            return $query->result_array();
        } else {
            return false;
        }
    }
    public function add_subscribe($input) {
        $checkemail= $this->db->where('email', $input['email'])->get('subscribes');
        if($checkemail->num_rows()>0) {
            $this->session->set_flashdata('error_subscribe', '<li>Email đã đăng ký</li>');
            $this->session->set_flashdata('error_subscribe2', '<li>Email đã đăng ký</li>');
            $this->session->set_flashdata('return_add', false);
            return false;
        }
        $this->db->insert('subscribes', $input);
        $this->session->set_flashdata('error_subscribe', '<li>Đăng ký thành công, chúng tôi sẽ liên hệ ngay với bạn</li>');
        $this->session->set_flashdata('return_add', true);
        return true;
    }
    public function get_user($id) {
        $query = $this->db->where('id', $id)->get('users');
        if($query->num_rows()>0) {
            return $query->row_array();
        } else {
            return false;
        }
    }
    public function edit($input, $id) {
        $this->db->where('id', $id)->update('users', $input);
    }
    public function delete_user($id) {
        $this->db->where('id', $id)->where('type', 0)->delete('users');
    }
    public function login($username, $password) {
        $user = $this->db->where('email', $username)
                        ->where('password', $password)->get('users');
        if ($user->num_rows() > 0) {
            $user = $user->row_array();
            $user['fullname'] = $user['last_name'] . ' ' .$user['first_name'];
            unset($user['password']);
            return $user;
        }
        return false;
    }
    public function register($input) {
        $queryEmail = $this->db->where('email', $input['email'])->get('users')->row_array();
        if(!empty($queryEmail)) {
            return $this->session->set_flashdata('return_register','Email: <strong>' . $queryEmail['email'] . '</strong> đã tồn tại trong hệ thống');
        } else {
            $this->db->insert('users', $input);
            if($this->db->affected_rows()==1){
                return true;
            } else {
                return false;
            }
        }
        return $_SESSION;
    }
    public function update_info_user($input) {
        if(isset($input['note'])) {
            unset($input['note']);
        }
        $this->db->where('id', $_SESSION['loggedInUser']['id'])->update('users', $input);
    }
}
