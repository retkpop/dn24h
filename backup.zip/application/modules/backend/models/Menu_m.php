<?php

Class Menu_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function get_all_menu() {
        $data['cat_post'] = $this->db->get('categories_post')->result_array();
        $data['list_pages'] = $this->db->get('pages')->result_array();
        return $data;
    }
    public function update_menu($input, $menu_id) {
        $query = $this->db->where('id', $menu_id)->get('menus');
        if($query->num_rows()>0) {
            if(isset($input['type']['page'])) {
                foreach ($input['type']['page'] as $value) {
                    $page = $this->db->where('id', $value)->get('pages')->row_array();
                    $data = array (
                        'menu_id' => $menu_id,
                        'label' => $page['title'],
                        'link' => base_url($page['slug'] . '.html'),
                    );
                    $this->db->insert('menu_detail', $data);
                }
            }
            if(isset($input['type']['post_cat'])) {
                foreach ($input['type']['post_cat'] as $value) {
                    $page = $this->db->where('id', $value)->get('categories_post')->row_array();
                    $data = array (
                        'menu_id' => $menu_id,
                        'label' => $page['title'],
                        'link' => base_url('danhmuc/'. $page['slug'] . '.html'),
                    );
                    $this->db->insert('menu_detail', $data);
                }
            }
            if(isset($input['link'])) {
                if(!empty($input['link']['label'])) {
                    $data = array (
                        'menu_id' => $menu_id,
                        'label' => $input['link']['label'],
                        'link' => $input['link']['value'],
                        'icon' => $input['link_icon'],
                    );
                    $this->db->insert('menu_detail', $data);
                }
            }
            return true;
        } else {
            return false;
        }
    }
    public function get_menu($menu_id,$parent = 0) {
        $query = $this->db->order_by('arrange', 'asc')->where('menu_id', $menu_id)->where('parent', $parent)->get('menu_detail');
        if($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    function get_submenu($menu_id, $parent) {
        $query = $this->db->order_by('arrange', 'asc')->where('menu_id', $menu_id)->where('parent', $parent)->get('menu_detail');
        if($query->num_rows()>0) {
            return $query->result();
        } else {
            return false;
        }
    }
    public function update_list_menu($input, $id) {
        $id_list = $input['id'];
        unset($input['id']);
        $this->db->where('menu_id', $id)->where('id', $id_list)->update('menu_detail', $input);
    }

    public function check_menu($id) {
        $menu = $this->db->where('id', $id)->get('menus');
        if($menu->num_rows()>0) {
            return true;
        } else {
            return false;
        }
    }

    public function remove_list_menu($id, $menu_id) {
        $this->db->where('id', $id)->where('menu_id', $menu_id)->delete('menu_detail');
        if($this->db->affected_rows()) {
            $query = $this->db->where('parent', $id)->where('menu_id', $menu_id)->get('menu_detail');
            if($query->num_rows()>0) {
                $input['parent'] = '0';
                foreach ($query->result_array() as $value) {
                    $this->db->where('id', $value['id'])->where('menu_id', $menu_id)->update('menu_detail', $input);
                }
            }
            return true;
        } else {
            return false;
        }
    }
    public function save_menu_change($data, $menu_id) {
        $id = $data['id'];
        $menus = $this->db->where('id', $id)->where('menu_id', $menu_id)->update('menu_detail', $data);
        if($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    public function all_menu() {
        $query = $this->db->get('menus');
        if($query->num_rows()>0) {
            return $query->result_array();
        } else {
            return false;
        }
    }
    public function delete_menu($id) {
        $this->db->where('id', $id)->delete('menus');
        if($this->db->affected_rows()) {
            $this->db->where('menu_id', $id)->delete('menu_detail');
        } else {
            return false;
        }
    }
    public function add_menu($input) {
        $query = $this->db->where('slug', $input['slug'])->get('menus');
        if($query->num_rows()>0) {
            $this->session->set_flashdata('return_add', false);
        } else {
            $this->db->insert('menus', $input);
            $this->session->set_flashdata('return_add', $this->db->insert_id());
        }
    }
}
?>
