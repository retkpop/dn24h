<?php

Class User_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function get_user_by_username($username) {
      $user = $this->db->where('username', $username)->get('users');
      if($user->num_rows()>0) {
        $user = $user->row_array();
        $user['fullname'] = $user['last_name'] . ' ' . $user['first_name'];
        $user['avatar_name'] = $user['avatar'];
        $user['email_show'] = '****' . substr($user['email'], 4);
        if(!empty($user['phone'])){
          $numb = strlen($user['phone']);
          $user['phone_show'] = substr($user['phone'], 0, $numb-3) . '***';
        }
        $user['provinces'] = $this->get_provinces_by_id($user['living_place']);
        $user['avatar'] = (!empty($user['avatar']))? base_url('uploads/avatar/'.$user['avatar']) : $this->template->dir() .'views/images/no-avatar.png';
        return $user;
      }
    }
    public function get_provinces_by_id($id){
      $provinces = $this->db->where('id', $id)->get('provinces');
      if($provinces->num_rows()>0) {
        return $provinces->row_array();
      }
      return false;
    }
    public function edit_user_by_username($input, $username) {
      $this->db->where('username', $username)->update('users', $input);
      $user = $this->get_user_by_username($username);
      $this->session->set_userdata('loggedInUser', $user);
    }
    public function login($input) {
        $query = $this->db->where('email', $input['username'])->where('password', $input['password'])->get('users');
        if ($query->num_rows() > 0) {
            $query = $query->row_array();
            $query['fullname'] = $query['last_name'] . ' ' . $query['first_name'];
            $query['avatar_name'] = $query['avatar'];
            $user['provinces'] = $this->get_provinces_by_id('living_place');
            $query['avatar'] = (!empty($query['avatar']))? base_url('uploads/avatar/'.$query['avatar']) : $this->template->dir() .'views/images/no-avatar.png';
            return $query;
        } else {
           $query2 = $this->db->where('username', $input['username'])->where('password', $input['password'])->get('users');
           if ($query2->num_rows() > 0) {
             $query2 = $query2->row_array();
             $query2['fullname'] = $query2['last_name'] . ' ' . $query2['first_name'];
             $user['provinces'] = $this->get_provinces_by_id('living_place');
             $query2['avatar_name'] = $query2['avatar'];
             $query2['avatar'] = (!empty($query2['avatar']))? base_url('uploads/avatar/'.$query2['avatar']) : $this->template->dir() .'views/images/no-avatar.png';
             return $query2;
           } else {
             return false;
           }
        }
        return false;
    }
    public function register($input) {
      $queryEmail = $this->db->where('email', $input['email'])->or_where('username', $input['username'])->get('users')->row_array();
      if(!empty($queryEmail)) {
          $data = array(
            'code' => 1001,
            'message' => 'Email hoặc Username đã tồn tại trên hệ thống!'
          );
      } else {
          $input['date_create'] = date('Y-m-d');
          $this->db->insert('users', $input);
          if($this->db->affected_rows()==1){
            $data = array(
              'code' => 200,
              'message' => 'Đăng ký thành công'
            );
          } else {
            $data = array(
              'code' => 1002,
              'message' => 'Connect database error!'
            );
          }
      }
      return $data;
    }
}
?>
