<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
        <title>404</title>
        <meta property="og:url" content="<?php echo current_url() ?>" />
        <meta content="INDEX,FOLLOW" name="robots" />
        <meta http-equiv="audience" content="General" />
        <meta name="resource-type" content="Document" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon" />
        <meta property="og:site_name" content="<?php echo base_url() ?>" />
        <meta property="og:type" content="website" />
        <meta property="og:locale" content="vi_VN" />
        <meta http-equiv="x-dns-prefetch-control" content="on">
        <script src="<?php echo $this->template->dir() ?>views/js/jquery-1.12.3.min.js" type="text/javascript"></script>
        <link href="<?php echo $this->template->dir() ?>views/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo $this->template->dir() ?>views/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo $this->template->dir() ?>views/style.css" rel="stylesheet" type="text/css"/>
        <style media="screen">
          .mainPage {
            padding: 50px 0;
            text-align: center;
          }
          .mainPage .content {
            display: inline-block;
            padding: 30px;
            background: #fff;
            border: 1px solid #ececec;
          }
          .mainPage .content .imagess {
            padding: 40px;
          }
        </style>
    </head>
    <body>
        <input type="hidden" class="baseUrl" value="<?php echo base_url() ?>" />
        <header class="main">
            <div class="topHeader">
                <div class="container">
                    <div class="itemHeadLeft logo">
                        <img src="<?php echo $this->template->dir() ?>views/images/logo.png" alt="Logo" class="img-fluid logoImg"/>
                    </div>
                    <div class="itemHeadLeft topMenu">
                        <ul>
                            <li><a href="">Hình ảnh</a></li>
                            <li><a href="">Clip</a></li>
                            <li><a href="">News</a></li>
                            <li><a href="">Hẹn hò</a></li>
                        </ul>
                    </div>
                    <div class="itemHeadLeft search">
                        <div class="formSearch">
                            <input type="text" class="form-text-ct" placeholder="Enter search keywords" required />
                            <button type="submit" class="btnSearch"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                    <?php if(empty($_SESSION['loggedInUser'])): ?>
                    <div class="itemHeadRight login">
                      <div class="btnUser btnLogin" formPopup='popupLogin'> Đăng nhập </div>
                      <div class="btnUser btnRegister" formPopup='popupRegister'> Đăng ký </div>
                    </div>
                    <div class="popupUser popupRegister">
                      <div class="olw-sm-tk"></div>
                      <div class="formGroup">
                        <div class="closePopup"><i class="fa fa-times"></i></div>
                        <div class="heading">
                          <span>Đăng ký thành viên</span>
                        </div>
                        <div class="formInput">
                          <div class="rowTk">
                            <div class="col-TK-6">
                              <div class="form-group formItem">
                                <label for="last_name"><i class="fa fa-info-circle"></i></label>
                                <input type="text" name="last_name" placeholder="Họ" class="last_name form-control" />
                              </div>
                            </div>
                            <div class="col-TK-6">
                              <div class="form-group formItem">
                                <label for="first_name"><i class="fa fa-info-circle"></i></label>
                                <input type="text" name="first_name" placeholder="Tên đệm và tên" class="first_name form-control" />
                              </div>
                            </div>
                          </div>

                          <div class="form-group formItem">
                            <label for="username"><i class="fa fa-user"></i></label>
                            <input type="text" name="username" placeholder="Tên đăng nhập" class="username form-control" />
                            <p>Tên tài khoản gồm các chữ cái và số, KHÔNG bao gồm khoảng trắng, ký tự đặc biệt</p>
                          </div>
                          <div class="form-group formItem">
                            <label for="email"><i class="fa fa-envelope"></i></label>
                            <input type="text" name="email" placeholder="Email" class="email form-control" />
                            <p>Nhập đúng thông tin địa chỉ email để xác nhận đăng ký thành viên</p>
                          </div>
                          <div class="form-group formItem">
                            <label for="phone"><i class="fa fa-phone-square"></i></label>
                            <input type="text" name="phone" placeholder="Số điện thoại" class="phone form-control" />
                            <p>Không bắt buộc, khuyến khích nhập đầy đủ để nhận thông báo quan trọng</p>
                          </div>
                          <div class="rowTk">
                            <div class="col-TK-6">
                              <div class="form-group formItem">
                                <label for="password"><i class="fa fa-key"></i></label>
                                <input type="password" name="password" placeholder="Mật khẩu" class="password form-control" />
                              </div>
                            </div>
                            <div class="col-TK-6">
                              <div class="form-group formItem">
                                <label for="passcf"><i class="fa fa-key"></i></label>
                                <input type="password" name="passcf" placeholder="Nhập lại mật khẩu" class="passcf form-control" />
                              </div>
                            </div>
                          </div>
                          <div class="form-group formMessage">
                            <div class="alert alert-dismissible in">
                              <a href="#" class="close" aria-label="close">&times;</a>
                              <div class="message"></div>
                            </div>
                          </div>
                          <div class="form-group">
                            <button type="button" class="btnSubmit">Đăng ký</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="popupUser popupLogin">
                      <div class="olw-sm-tk"></div>
                      <div class="formGroup">
                        <div class="closePopup"><i class="fa fa-times"></i></div>
                        <div class="heading">
                          <span>Đăng nhập</span>
                        </div>
                        <div class="formInput">
                          <div class="form-group formItem">
                            <label for="username"><i class="fa fa-user"></i></label>
                            <input type="text" name="username" placeholder="Email hoặc Username đăng nhập" class="username form-control" />
                            <p>Nhập username hoặc email để đăng nhập</p>
                          </div>
                          <div class="form-group formItem">
                            <label for="password"><i class="fa fa-key"></i></label>
                            <input type="password" name="password" placeholder="Mật khẩu" class="password form-control" />
                          </div>
                          <div class="form-group formMessage">
                            <div class="alert alert-dismissible in">
                              <a href="#" class="close" aria-label="close">&times;</a>
                              <div class="message"></div>
                            </div>
                          </div>
                          <div class="form-group">
                            <button type="button" class="btnSubmit">Đăng nhập</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  <?php else: ?>
                    <div class="itemHeadRight login">
                      <div class="loggedInUser">
                        <div class="avatar"><img src="<?php echo $_SESSION['loggedInUser']['avatar'] ?>" class="img-fluid" /></div>
                        <div class="btnUser btnUserLg"> <?php echo $_SESSION['loggedInUser']['fullname'] ?> </div>
                        <div class="btnUser btnCreatePost"> Đăng bài </div>
                      </div>
                      <div class="infomation">
                        <ul>
                          <li><a href="">Tường nhà bạn</a></li>
                          <li><a href="">Thông tin cá nhân</a></li>
                          <li><a href="">Cài đặt</a></li>
                          <li><a href="<?php echo base_url('user/logout?url_redirect='.current_url()) ?>">Thoát</a></li>
                        </ul>
                      </div>
                    </div>
                  <?php endif; ?>
                </div>
            </div>
            <div class="mainMenu">
                <div class="container">
                    <div class="itemHeadLeft">
                        <div class="listMenu">
                            <ul>
                                <li><a href="">Bí kíp yêu</a></li>
                                <li><a href="">Thôn zai</a></li>
                                <li><a href="">Làng gái</a></li>
                                <li><a href="">Câu chuyện hẹn hò</a></li>
                                <li><a href="">Góc tâm sự</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="itemHeadLeft">
                        <div class="events">Không có sự kiện nào sắp diễn ra</div>
                    </div>
                </div>
            </div>
        </header>
        <div class="mainPage">
          <div class="container">
            <div class="content">
              <div class="imagess">
                <img src="<?php echo $this->template->dir() ?>views/images/404.png" class="img-fluid" />
              </div>
              <div class="tilePage">
                <h1>404 not found</h1>
              </div>
              <div class="info">
                Trang bạn truy cập không hợp lệ, vui lòng kiểm tra lại đường dẫn.
              </div>
            </div>
          </div>
        </div>
        <footer>
            <div class="main">
                <div class="shortcuts">
                   <div class="container">
                      <ol class="list">
                         <li class="item active"><a href="" class="itemMenu">Tin mới</a></li>
                         <li class="item "><a href="" class="itemMenu">Sản phẩm công nghệ mới</a></li>
                         <li class="item "><a href="" class="itemMenu">Khuyến mãi</a></li>
                         <li class="item "><a href="" class="itemMenu">Sự kiện</a></li>
                         <li class="item "><a href="" class="itemMenu">Video</a></li>
                      </ol>
                   </div>
                </div>
                <div class="links">
                    <div class="container">
                        <ol class="mainFooter">
                           <li class="itemLink">
                                <h3 class="heading">Tinh Tế</h3>
                                <ol class="list">
                                   <li class="item"><a href="" target="_self" class="">Nội quy diễn đàn</a></li>
                                   <li class="item"><a href="" target="_self" class="">Góp ý</a></li>
                                   <li class="item"><a href="" target="_self" class="">Hỗ trợ, hướng dẫn</a></li>
                                   <li class="item"><a href="" target="_self" class="">Liên hệ quảng cáo</a></li>
                                   <li class="item"><a href="" target="_self" class="">Tinh Tế RSS</a></li>
                                </ol>
                           </li>
                           <li class="itemLink">
                                <h3 class="heading">Diễn đàn</h3>
                                <ol class="list">
                                   <li class="item"><a href="" target="_self" class="itemMenu">Điện thoại</a></li>
                                   <li class="item"><a href="" target="_self" class="itemMenu">Máy tính</a></li>
                                   <li class="item"><a href="" target="_self" class="itemMenu">Camera</a></li>
                                   <li class="item"><a href="" target="_self" class="itemMenu">Xe</a></li>
                                   <li class="item"><a href="" target="_self" class="itemMenu">Khoa học công nghệ</a></li>
                                </ol>
                           </li>
                           <li class="itemLink">
                                <h3 class="heading">Nhật Tảo</h3>
                                <ol class="list">
                                   <li class="item"><a href="" target="_blank" class="itemMenu">Mua bán điện thoại</a></li>
                                   <li class="item"><a href="" target="_blank" class="itemMenu">Mua bán máy tính</a></li>
                                   <li class="item"><a href="" target="_blank" class="itemMenu">Mua bán máy tính bảng</a></li>
                                   <li class="item"><a href="" target="_blank" class="itemMenu">Mua bán camera</a></li>
                                   <li class="item"><a href="" target="_blank" class="itemMenu">Mua bán đồng hồ thông minh</a></li>
                                   <li class="item"><a href="" target="_blank" class="itemMenu">Mua bán xe</a></li>
                                </ol>
                           </li>
                           <li class="itemLink">
                                <h3 class="heading">Liên kết</h3>
                                <ol class="list">
                                   <li class="item"><a href="" target="_blank" class="itemMenu">Cà phê Tinh tế</a></li>
                                   <li class="item"><a href="" target="_blank" class="itemMenu">Khắc tên</a></li>
                                   <li class="item"><a href="" target="_blank" class="itemMenu">ChiMua.vn</a></li>
                                   <li class="item"><a href="" target="_blank" class="itemMenu">1Tudien</a></li>
                                   <li class="item"><a href="" target="_blank" class="itemMenu">NhacCuaTui</a></li>
                                   <li class="item"><a href="" target="_blank" class="itemMenu">5Giay</a></li>
                                </ol>
                           </li>
                           <li class="itemLink">
                                <h3 class="heading">Theo dõi chúng tôi</h3>
                                <ol class="list">
                                   <li class="item">
                                      <a href="https://www.facebook.com/" target="_blank" class=""><i class="fa fa-facebook-square"></i> Facebook</a>
                                   </li>
                                   <li class="item">
                                      <a href="https://www.youtube.com/" target="_blank" class=""><i class="fa fa-youtube-square"></i> Youtube </a>
                                   </li>
                                   <li class="item">
                                      <a href="" target="_blank" class=""><i class="fa fa-image"></i> Flickr </a>
                                   </li>
                                   <li class="item">
                                      <a href="https://twitter.com/retkpop/" target="_blank" class=""><i class="fa fa-twitter-square"></i> Twitter </a>
                                   </li>
                                   <li class="item">
                                      <a href="https://plus.google.com/" target="_blank" class=""><i class="fa fa-google-plus"></i> Google+</a>
                                   </li>
                                </ol>
                           </li>
                        </ol>
                    </div>
                </div>
                <div class="infos">
                   <div class="container">
                        <div class="bottom-footer">
                            <div class="item">Chịu trách nhiệm nội dung: Trần Mạnh Hiệp</div>
                            <div class="item">© 2018 Công ty Cổ phần MXH Tinh Tế</div>
                            <div class="item">Địa chỉ: 209 Đường Nam Kỳ Khởi Nghĩa, Phường 7, Quận 3, TP.HCM</div>
                            <div class="item">Giấy phép MXH số 385/GP-TTTT do Bộ TTTT cấp</div>
                        </div>
                   </div>
                </div>
             </div>
        </footer>
        <?php if(empty($_SESSION['loggedInUser'])): ?>
        <script type="text/javascript">
          var baseUrl = "<?php echo base_url() ?>";
          var current_url = '<?php echo current_url() ?>';
          $('.popupRegister .btnSubmit').on('click', function(){
            var last_name = $('.popupRegister .formInput .last_name').val();
            var first_name = $('.popupRegister .formInput .first_name').val();
            var username = $('.popupRegister .formInput .username').val();
            var email = $('.popupRegister .formInput .email').val();
            var phone = $('.popupRegister .formInput .phone').val();
            var password = $('.popupRegister .formInput .password').val();
            var passcf = $('.popupRegister .formInput .passcf').val();
            $('.popupRegister .formInput').addClass('action');
            $.ajax({
                type: "POST",
                url: baseUrl + "user/register",
                cache: false,
                dataType: 'json',
                data: {"last_name": last_name,"first_name":first_name, "username": username, "email": email, "phone": phone, "password": password, "passcf": passcf},
                success: function(data) {
                  $('.popupRegister .formMessage').show();
                  console.log(data);
                   if(data.code == 200) {
                      $('.popupRegister .formMessage .alert').removeClass('alert-danger');
                      $('.popupRegister .formMessage .alert').addClass('alert-success');
                      $('.popupRegister .formMessage .message').html(data.message);
                      $('.popupRegister .formMessage .message').append('<p>Click <span class="actionLogin">vào đây</span> để đăng nhập hệ thống</p>');
                      $('.actionLogin').on('click', function(){
                        $('.popupUser.popupRegister').hide();
                        $('.btnLogin').click();
                      });
                    } else {
                      $('.popupRegister .formMessage .alert').addClass('alert-danger');
                      $('.popupRegister .formMessage .message').html(data.message);
                    }
                    $('.popupRegister .formMessage .close').on('click', function() {
                      $('.popupRegister .formMessage').hide();
                    });
                    $('.popupRegister .formInput').removeClass('action');
                }
            });
          });
          $('.popupLogin .btnSubmit').on('click', function(){
            var username = $('.popupLogin .formInput .username').val();
            var password = $('.popupLogin .formInput .password').val();
            $('.popupLogin .formInput').addClass('action');
            $.ajax({
                type: "POST",
                url: baseUrl + "user/login",
                cache: false,
                dataType: 'json',
                data: {"username": username, "password": password},
                success: function(data) {
                  $('.popupLogin .formMessage').show();
                  console.log(data);
                   if(data.code == 200) {
                      $('.popupLogin .formMessage .alert').removeClass('alert-danger');
                      $('.popupLogin .formMessage .alert').addClass('alert-success');
                      $('.popupLogin .formMessage .message').html(data.message);
                      $('.popupLogin .formMessage .message').append('<p>Hệ thống sẽ tự động chuyển hướng trong <span class="progressBar">3</span>s</p>');
                      var timeleft = 3;
                      var downloadTimer = setInterval(function(){
                          timeleft--;
                          $(".progressBar").html(timeleft);
                          if(timeleft <= 0)
                              clearInterval(downloadTimer);
                      },1000);
                      setTimeout(function(){
                          window.location.replace(current_url);
                      }, 3000);
                    } else {
                      $('.popupLogin .formMessage .alert').addClass('alert-danger');
                      $('.popupLogin .formMessage .message').html(data.message);
                    }
                    $('.formMessage .close').on('click', function() {
                      $('.popupLogin .formMessage').hide();
                    });
                    $('.popupLogin .formInput').removeClass('action');
                }
            });
          });
          $('.popupUser .closePopup, .popupUser .olw-sm-tk').on('click', function(){
            $('.popupUser').hide();
          });
          $('.topHeader .btnUser').on('click', function(){
            var classUs = $(this).attr('formPopup');
            $('.popupUser.'+classUs).show();
          });
        </script>
        <?php endif ?>
        <?php if(!empty($_SESSION['loggedInUser'])): ?>
          <script type="text/javascript">
            $('.loggedInUser .btnUserLg').on('click', function(){
              $(this).toggleClass('show');
              $('.itemHeadRight .infomation').toggleClass('active');
            })
          </script>
        <?php endif; ?>
        <script src="<?php echo $this->template->dir() ?>views/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo $this->template->dir() ?>views/js/jquery.slideandswipe.min.js" type="text/javascript"></script>
        <script src="<?php echo $this->template->dir() ?>views/js/jquery.touchSwipe.min.js" type="text/javascript"></script>
        <script src="<?php echo $this->template->dir() ?>views/js/main.js" type="text/javascript"></script>
    </body>
</html>
