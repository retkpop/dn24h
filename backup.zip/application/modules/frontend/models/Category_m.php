<?php

Class Category_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function count_all_post($slug) {
        $cat = $this->db->where('slug', $slug)->get('categories_post')->row_array();
        return $this->db->where('id_cat', $cat['id'])->count_all('posts');
    }
    public function category_post($number, $offset, $slug) {
        $cat = $this->db->where('slug', $slug)->get('categories_post')->row_array();
        $query = $this->db->order_by('id', 'desc')->where('cat_id', $cat['id'])->get('posts',$number,$offset);
        $data = array(
            'cat_id' => $cat['id'],
            'cat_name' => $cat['title'],
            'cat_description' => $cat['description'],
        );
        if($query->num_rows()>0) {
            foreach ($query->result_array() as $value) {
                $value['url'] = base_url($value['slug']. '-' . $value['id'] . '.html');
                $date = date_create($value['date_post']);
                $name_sl = date_format($date,"Y/m");
                $value['date_post'] = date_format($date,"d/m/Y");
                $value['thumbnail'] = (!empty($value['thumbnail']))? base_url('uploads/thumbnail_post/'. $name_sl . '/' .$value['thumbnail']) : base_url('uploads/images/no-thumbnail.jpg');
                $author = $this->db->where('id', $value['author_id'])->get('users')->row_array();
                $value['author_name'] = $author['last_name'] . ' ' . $author['first_name'];
                $post[] = $value;
            }
            $data['post'] = $post;
            return $data;
        }
        return $data;
    }
}
?>
