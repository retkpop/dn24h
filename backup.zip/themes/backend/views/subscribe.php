<?php require_once 'header.php'; ?>
                <!-- Main content -->
                <div class="content-wrapper">
                    <!-- Page header -->
                    <div class="page-header">
                        <div class="page-header-content">
                            <div class="page-title">
                                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                            </div>
                            <div class="heading-elements">
                                <div class="heading-btn-group">
                                    <a data-toggle="modal" data-target="#myModal" href="<?php echo base_url('admin/import_user') ?>" class="btn btn-link btn-float has-text"><i class="icon-upload text-primary"></i><span>Import</span></a>
                                </div>
                            </div>
                            <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
                        </div>
                        <div class="breadcrumb-line">
                            <ol class="breadcrumb">
                                <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                                <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                            </ol>
                        </div>
                    </div>
                    <div id="myModal" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <?php echo form_open_multipart('admin/upload_import'); ?>
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Upload danh sách sách thành viên từ file excel</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <input type="file" name="file" id="file">
                                        <p class="help-block">Only Excel/CSV File Import.</p>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-primary">Import</button>
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
                                </div>
                                <?php echo form_close() ?>
                            </div>
                        </div>
                    </div>
                    <!-- /page header -->
                    <!-- Content area -->
                    <div class="content">
                        <div class="col-md-3">
                            <h5>Thêm khách hàng</h5>
                            <hr>
                            <div class="inner">
                                <?php if(isset($_SESSION['return_add'])): ?>
                                <div class="flash alert <?php echo ($_SESSION['return_add'] == false)? 'alert-error': 'alert-success' ?> alert-styled-left">
                                    <?php if($_SESSION['return_add'] == false): ?>
                                    <span class="text-semibold">Lỗi! Email khách hàng đã tồn tại</span>
                                    <?php else: ?>
                                    <span class="text-semibold">Thêm khách hàng mới thành công</span> 
                                    <?php endif; ?>
                                    <div class="heading-elements">
                                        <ul class="icons-list">
                                            <li><a class="close" data-action="close"></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php if(validation_errors() != false): ?>
                                <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <strong>Có lỗi xảy ra!</strong>
                                    <ul>
                                        <?php echo validation_errors('<li>' , '</li>'); ?>
                                    </ul>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="clearfix"></div>
                            <?php echo form_open() ?>
                                <div class="form-group">
                                    <label for="fullname">Họ tên</label>
                                    <?php echo form_input('fullname', '', 'class="form-control" id="fullname"') ?>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <?php echo form_input('email', '', 'class="form-control" id="email"') ?>
                                </div>
                                <div class="form-group">
                                    <label for="phone">Số điện thoại</label>
                                    <?php echo form_input('phone', '', 'class="form-control" id="phone"') ?>
                                </div>
                                <div class="form-group">
                                    <label for="title">Loại khách hàng</label>
                                    <select name="type" class="form-control select2">
                                        <option value="">-- Lựa chọn danh sách gửi --</option>
                                        <option value="1">KH đã mua SP</option>
                                        <option value="0">Thành viên</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="address">Địa chỉ</label>
                                    <textarea name="address" class="form-control" rows="4"></textarea>
                                </div>
                                <button class="btn btn-primary">Thêm KH</button>
                            <?php echo form_close() ?>
                        </div>


                        <div class="col-md-9">
                            <h5>Danh sách khách hàng</h5>
                            <hr>
                            <?php echo form_open('admin/bulk_action_subscribe') ?>
                                <!-- Bulk Action -->
                                <div class="bulk-action row">
                                    <div class="col-sm-6 col-md-5 col-lg-4">
                                        <div class="input-group input-group-xs">
                                            <select name="bulk_action_subscribe" class="select-bulk-action">
                                                <option value="">-- Bulk Action</option>
                                                <option value="delete">Delete</option>
                                            </select>
                                            <span class="input-group-btn">
                                                <button class="btn btn-default" value="bulk_action_subscribe">Áp dụng</button>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <!-- Bulk Action End -->
                                <div class="clearfix"></div>
                                <!-- Danh sách quảng cáo  -->
                                <div class="panel panel-flat">
                                        <div class="panel-body no-padding">
                                            <div class="table-responsive">
                                                <table class="table table-data">
                                                    <thead>
                                                        <tr>
                                                            <th><input type="checkbox" class="styled top-check"></th>
                                                            <th>Họ tên</th>
                                                            <th>Địa chỉ E-mail</th>
                                                            <th>Điện thoại</th>
                                                            <th>Địa chỉ</th>
                                                            <th>Loại KH</th>
                                                            <th></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php if($subscribe != false): foreach ($subscribe as $value): ?>
                                                        <tr>
                                                            <td><input type="checkbox" value="<?php echo $value['id'] ?>" name="id[]" class="styled item-checkbox"></td>
                                                            <td><?php echo $value['fullname'] ?></td>
                                                            <td><?php echo $value['email'] ?></td>
                                                            <td><?php echo $value['phone'] ?></td>
                                                            <td><?php echo $value['address'] ?></td>
                                                            <td><?php echo ($value['type'] == 0)? 'Thành viên' : 'KH đã mua SP' ?></td>
                                                            <td>
                                                                <a class="btn btn-xs btn-icon btn-danger" href="<?php echo base_url('admin/delete_subscribe/'.$value['id']) ?>">
                                                                    <i class="icon-minus2"></i>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                <!-- Bulk Action -->
                                <div class="bulk-action row">
                                    <div class="col-sm-6 col-md-5 col-lg-4">
                                        <div class="input-group input-group-xs">
                                            <select name="bulk_action_subscribe" class="select-bulk-action">
                                                <option value="">-- Bulk Action</option>
                                                <option value="delete">Delete</option>
                                            </select>
                                            <span class="input-group-btn">
                                                <button class="btn btn-default" value="bulk_action_subscribe">Áp dụng</button>
                                            </span>
                                        </div><!-- /input-group -->
                                    </div>
                                    <div class="col-sm-6 col-md-7 col-lg-8">
                                        <div class="pagination pull-right"><?php echo $this->pagination->create_links(); // tạo link phân trang ?></div>
                                    </div>
                                </div>
                                <!-- Bulk Action End -->
                            <?php echo form_close() ?>
                        </div>
                    </div>
                    <!-- /content area -->
                </div>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
        <!-- /page container -->
    </body>
</html>
