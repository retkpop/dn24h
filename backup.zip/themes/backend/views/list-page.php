<?php require_once 'header.php'; ?>
                <!-- Main content -->
                <div class="content-wrapper">
                    <!-- Page header -->
                    <div class="page-header">
                        <div class="page-header-content">
                            <div class="page-title">
                                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                            </div>

                            <div class="heading-elements">
                                <div class="heading-btn-group">
                                    <a href="<?php echo base_url('admin/new_page') ?>" class="btn btn-link btn-float has-text"><i class="icon-plus2 text-primary"></i><span>Thêm trang mới</span></a>
                                </div>
                            </div>
                            <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
                        </div>
                        <div class="breadcrumb-line">
                            <ol class="breadcrumb">
                                <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                                <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                            </ol>
                        </div>
                    </div>
                    <!-- /page header -->
                    <!-- Content area -->
                    <div class="content">
                        <?php echo form_open('admin/bulk_action_page'); ?>
                            <!-- Bulk Action -->
                            <div class="bulk-action row">
                                <div class="col-sm-4 col-md-3 col-lg-2">
                                    <div class="input-group input-group-xs">
                                        <select name="bulk_action_page" class="select select-bulk-action">
                                            <option value="">-- Bulk Action</option>
                                            <option value="delete">Delete</option>
                                        </select>
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" value="bulk_action_page">&Aacute;p dụng</button>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-3 col-lg-2">
                                    <div class="pagination pull-right"><?php echo $this->pagination->create_links(); // tạo link phân trang ?></div>
                                </div>
                            </div>
                            <!-- Bulk Action End -->
                            <div class="panel panel-flat">
                                <div class="panel-body no-padding">
                                    <div class="table-responsive">
                                        <table class="table table-data">
                                            <thead>
                                                <tr>
                                                    <th><input type="checkbox" class="top-check styled"></th>
                                                    <th>Tên bài viết</th>
                                                    <th>Slug</th>
                                                    <th>Tác giả</th>
                                                    <th>Ngày đăng</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(!empty($all_pages)): foreach ($all_pages as $value):  ?>
                                                <tr class="">
                                                    <td>
                                                        <input type="checkbox" name="id[]" value="<?php echo $value['id'] ?>" class="item-checkbox styled">
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo base_url('admin/page_edit/' . $value['id']) ?>"><?php echo $value['title'] ?></a>
                                                    </td>
                                                    <td><?php echo $value['slug'] ?></td>
                                                    <td><?php echo $value['author_name'] ?></td>
                                                    <td><?php echo $value['date_post'] ?></td>
                                                    <td>
                                                        <a class="btn btn-xs btn-default  btn-icon" href="<?php echo base_url('admin/page_edit/' . $value['id']) ?>">
                                                            <i class="icon-pen"></i>
                                                        </a>
                                                        <a class="btn btn-xs btn-danger  btn-icon" id="delete" href="<?php echo base_url('admin/delete_page/' . $value['id']) ?>"><i class="icon-minus2"></i></a>
                                                        <a target="_blank" class="btn btn-icon btn-xs btn-info" href="<?php echo $value['slug'] ?>">
                                                            <i class="icon-eye2"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; endif; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th><input type="checkbox" class="top-check styled"></th>
                                                    <th>Tên bài viết</th>
                                                    <th>Slug</th>
                                                    <th>Tác giả</th>
                                                    <th>Ngày xuất bản</th>
                                                    <th></th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <!-- Bulk Action -->
                            <div class="bulk-action row">
                                <div class="col-sm-4 col-md-3 col-lg-2">
                                    <div class="input-group input-group-xs">
                                        <select name="bulk_action" class="select-bulk-action">
                                            <option value="">-- Bulk Action</option>
                                            <option value="delete">Delete</option>
                                        </select>
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" value="bulk_action">&Aacute;p dụng</button>
                                        </span>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-4 col-md-3 col-lg-2">
                                    <div class="pagination pull-right"><?php echo $this->pagination->create_links(); // tạo link phân trang ?></div>
                                </div>
                            </div>
                            <!-- Bulk Action End -->
                        <?php echo form_close() ?>
                    </div>
                    <!-- /content area -->
                </div>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
        <!-- /page container -->
    </body>
</html>
