<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Posts extends CI_Controller {
		public function __construct() {
	      parent::__construct();
				if ($this->router->fetch_method() != 'login' && $this->router->fetch_method() != 'register') {
            if (!isset($_SESSION['loggedInUser']) || $_SESSION['loggedInUser']['type'] != 1) {
                redirect('admin/login');
            }
        }
	      $this->load->library('session');  //Load the Session
	      $this->template->set_theme('backend');
	      date_default_timezone_set('Asia/Saigon');
	      $method = $this->router->fetch_method();
	      $this->template->set('page', $method)->set_breadcrumb('Posts', base_url('index'));
	      //pagination
	      $this->load->library('pagination');
				$this->load->helper('url');
	      $this->load->helper('text');
				$this->load->model('post_m');
	  }
		public function list_posts() {
        $config = $this->pagination(30, 'list_post');
				$config['uri_segment'] = 3;
        $config['total_rows'] = $this->post_m->count_all_posts();
        $this->pagination->initialize($config);
        $all_posts['posts'] = $this->post_m->list_posts($config['per_page'],$this->uri->segment(3));
        $this->template->title('Danh sách sản phẩm')->build('list-post', $all_posts);
    }
		public function post_edit($id) {
        if($_POST) {
            $this->session->set_flashdata('post', $_POST);
        }
				$data['post'] = $this->post_m->post($id);
        $val = $this->validation_post();
        if($val != false && $data['post'] != false) {
            $button = $_POST['button'];
            unset($_POST['button']);
						if(empty($_POST['status'])) {
                $_POST['status'] = 0;
            }
            if(isset($_FILES['thumbnail_post']['name']) && $_FILES['thumbnail_post']['name'] != ''){
                if(isset($_POST['old_thumb']) && $_POST['old_thumb'] != '') {
                    $old_thumb = $_POST['old_thumb'];
                } else {
                    $old_thumb = false;
                }
								$date = date_create($data['post']['date_post']);
		            $name_sl = date_format($date,"Y/m");

                $_POST['thumbnail'] = $this->thumb_edit('thumbnail_post/'. $name_sl, 'thumbnail_post', $old_thumb);
            }
						unset($_POST['old_thumb']);
						$post_update = $this->post_m->post_edit($this->input->post(), $id);
						if($button == 'save_and_exists') {
								redirect('admin/post_edit/'.$id);
						} else {
								redirect('admin/list-post.html');
						}
        } else {
            $cat_id = array(
                'cat_id' => $data['post']['cat_id']['id']
            );
            $this->session->set_flashdata('post', $cat_id);
            $data['cat_post'] = $this->get_cat_post();
            $this->template->title('Chỉnh sửa bài viết')->build('edit-post', $data);
        }
    }
		public function fillter_post() {
        $posts = $this->post_m->fillter_post($_POST['valueSearch']);
        if($posts != false) {
            $data = array(
                'code' => "0",
                'message' => 'Success search',
                'Data' => $posts
            );
        } else {
            $data = array(
                'code' => "1001",
                'message' => 'No search results found',
            );
        }
        $json = json_encode($data, JSON_UNESCAPED_UNICODE);
        echo $json;
    }
		public function new_post() {
				if($_POST) {
		        $this->session->set_flashdata('post', $_POST);
		    }
		    $val = $this->validation_post();
		    if($val != false) {
						if(isset($_FILES['thumbnail_post']['name']) && $_FILES['thumbnail_post']['name'] != ''){
								$name_sl = 'thumbnail_post/' . date("Y") . '/' . date("m");
				        $_POST['thumbnail'] = $this->file_upload($name_sl, 'thumbnail_post');
						}
		        $_POST['author_id'] = $_SESSION['loggedInUser']['id'];
		        $_POST['date_post'] = date("Y-m-d");
		        $button = $_POST['button'];
		        unset($_POST['button']);
						if(empty($_POST['status'])) {
                $_POST['status'] = 0;
            }
		        $id = $this->post_m->insert_post($this->input->post());
		        if($id != false){
		            if($button == 'save_and_exists') {
		                redirect('admin/post_edit/'.$id);
		            } else {
		                redirect('admin/list_posts');
		            }
		        } else {
		            redirect('admin/add_post');
		        }
		    } else {
		        $cat['cat_post'] = $this->get_cat_post();
		        $this->template->title('Thêm sản phẩm mới')->build('new-post', $cat);
		    }
		}
		public function thumb_edit($name_sl, $name_file_n, $old_thumb = false) {
        $path = dirname(BASEPATH) . '/uploads/'. $name_sl .'/';
        $tmp_name = $_FILES[$name_file_n]['tmp_name'];
        $name = $_FILES[$name_file_n]['name'];
        $array = explode('.', $name);
        $n = count($array);
        $name_file = md5(microtime() . rand(1, 1000));
        $new_name = $name_file . '.' . $array[$n - 1];
        if($old_thumb != false) {
            $path_old = dirname(BASEPATH) . '/uploads/' . $name_sl . '/' . $old_thumb;
            unlink($path_old);
        }
        move_uploaded_file($tmp_name, $path . $new_name);
        return $new_name;
    }
		public function delete_post($id) {
        $this->post_m->delete_post($id);
        redirect('admin/list_posts');
    }
    public function bulk_action() {
        if(!empty($_POST['bulk_action'])) {
            if(isset($_POST['id'])) {
                if($_POST['bulk_action'] == 'delete') {
                    foreach ($_POST['id'] as $value) {
                        $this->post_m->delete_post($value);
                    }
                }
            }
        }
        redirect('admin/list_posts');
    }
		public function file_upload($name_sl, $name_file) {
				if (!is_dir('uploads/'. $name_sl .'/')) {
						mkdir('uploads/'. $name_sl .'', 0777, true);
				}
				$path = dirname(BASEPATH) . '/uploads/'. $name_sl .'/';
        $tmp_name = $_FILES[$name_file]['tmp_name'];
        $name = $_FILES[$name_file]['name'];
        $array = explode('.', $name);
        $n = count($array);
        $name_file = md5(microtime() . rand(1, 1000));
        if($_FILES[$name_file]['error']==0){
            $new_name = $name_file . '.' . $array[$n - 1];
            move_uploaded_file($tmp_name, $path . $new_name);
            return $new_name;
        } else {
            $new_name = '';
            return $new_name;
        }
    }
		public function categories() {
        $rules = array(
            array (
                'field' => 'title',
                'label' => 'Tên danh mục sản phẩm',
                'rules' => 'trim|required'
            ),
						array (
                'field' => 'title_seo',
                'label' => 'Tên danh mục SEO sản phẩm',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'slug',
                'label' => 'Đường dẫn danh mục',
                'rules' => 'trim|required'
            ),
						array (
                'field' => 'description',
                'label' => 'Mô tả danh mục',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'parent',
                'label' => 'Danh mục cha',
                'rules' => 'trim'
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run($this)) {
            $this->post_m->insert_cat($this->input->post());
            redirect('admin/post-categories.html');
        } else {
            $data['categorys'] = $this->cat_post();
            $data['all_cat'] = $this->get_cat_post();
            $this->template->title('Danh mục sản phẩm')->build('category-post', $data);
        }
    }
		public function cat_post() {
        $str = "";
        $cat_post  =   $this->post_m->get_cat(0);
				if(!empty($cat_post)) {
						foreach ($cat_post as $cat) {
								$str .= '<tr>
										<td><input name="id[]" value="'. $cat->id .'" class="styled item-checkbox" type="checkbox"></td>
										<td>
												<a href="">'. $cat->title .'</a>
										</td>
										<td>' . $cat->description . '</td>
										<td>
												<a class="btn btn-xs btn-icon btn-default" href="'. base_url('admin/edit_cat?id=' . $cat->id) .'">
														<i class="icon-pen"></i>
												</a>
												<a class="btn btn-xs btn-icon btn-danger" id="delete_cat" href="'. base_url('admin/delete_category?id='. $cat->id) .'">
														<i class="icon-minus2"></i>
												</a>
												<a target="_blank" class="btn btn-icon btn-xs btn-info" href="'. base_url('danh-muc/' . $cat->slug . '.html') .'">
														<i class="icon-eye2"></i>
												</a>
										</td>
								</tr>';
								$str .= $this->subcat_post($cat->id,$i = 0);
						}
				}
        return $str;
    }
		function subcat_post($category_ids,$i = 0) {
        $str = "";
        $sub_categorys = $this->post_m->get_subcat($category_ids);
        //kiem tra get subcategory co ton ai hay
        if($sub_categorys) {
            foreach ($sub_categorys as $sub_category) {
                //kiem tra con parent hay ko
                $str .= '<tr>
                    <td><input name="id[]" value="'. $sub_category->id .'" class="styled item-checkbox" type="checkbox"></td>
                    <td>
                        <a href="" class="' .$this->check_parent_menu($sub_category->id). '">' . $sub_category->title .'</a>
                    </td>
                    <td>' . $sub_category->description . '</td>
                    <td>
                        <a class="btn btn-xs btn-icon btn-default" href="'. base_url('admin/edit_cat?categorys_post=' . $sub_category->id) .'">
                            <i class="icon-pen"></i>
                        </a>
                        <a class="btn btn-xs btn-icon btn-danger" id="delete_cat" href="'. base_url('admin/delete_category?categorys_post='. $sub_category->id) .'">
                            <i class="icon-minus2"></i>
                        </a>
                        <a target="_blank" class="btn btn-icon btn-xs btn-info" href="'. base_url('danh-muc/' . $sub_category->slug . '.html') .'">
                            <i class="icon-eye2"></i>
                        </a>
                    </td>
                </tr>';
                if($sub_category->id) {
                    $str .= $this->subcat_post($sub_category->id,$i++);
                }
                $i++;
            }
        }
        return $str;
    }
		public function get_cat_post() {
        $str = "";
        $cat_product = $this->post_m->get_cat(0);
				if(!empty($cat_product)) {
		        foreach ($cat_product as $cat) {
		            if(isset($_SESSION['post']['cat_id']) && $_SESSION['post']['cat_id'] == $cat->id){
		                $select = 'selected';
		            } else {
		                $select = '';
		            }
		            $str .= "<option " . $select . " value='" . $cat->id . "' class='goc'>";
		            $str .= $cat->title;
		            $str .= "</option>";
		            $str .= $this->get_subcat_post($cat->id,$i = 0);

		        }
				}
        return $str;
    }
    function get_subcat_post($category_ids,$i = 0) {
        $str = "";
        $sub_categorys  =   $this->post_m->get_subcat($category_ids);
        //kiem tra get subcategory co ton ai hay
        if($sub_categorys) {
            if(!isset($_SESSION['tab_parent'])) {
                $this->session->set_flashdata('tab_parent', 1);
            } else {
                $_SESSION['tab_parent']++;
            }
            foreach ($sub_categorys as $sub_category) {
                if(isset($_SESSION['post']['cat_id']) && $_SESSION['post']['cat_id'] == $sub_category->id) {
                    $select = 'selected';
                } else {
                    $select = '';
                }
                //kiem tra con parent hay ko
                $str .= "<option " . $select . " value='" . $sub_category->id . "' class='".$this->check_parent_menu($sub_category->id)."'>";
                $str .= str_repeat('&nbsp;_', $_SESSION['tab_parent']) . $sub_category->title;
                $str .= "</option>";
                if($sub_category->id) {
                    $str .= $this->get_subcat_post($sub_category->id,$i++);
                }
                $i++;
            }
        }
        return $str;
    }
		public function edit_cat() {
				if(empty($this->input->get('id'))) {
						redirect('admin/post-categories.html');
				}
				$id = $this->input->get('id');
				$rules = array(
            array (
                'field' => 'title',
                'label' => 'Tên danh mục sản phẩm',
                'rules' => 'trim|required'
            ),
						array (
                'field' => 'title_seo',
                'label' => 'Tên danh mục SEO sản phẩm',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'slug',
                'label' => 'Đường dẫn danh mục',
                'rules' => 'trim|required'
            ),
						array (
                'field' => 'description',
                'label' => 'Mô tả danh mục',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'parent',
                'label' => 'Danh mục cha',
                'rules' => 'trim'
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run($this)) {
            $this->post_m->edit_cat($this->input->post(),$id);
            redirect('admin/edit_cat?id=' .$id);
        } else {
            $data['category'] = $this->post_m->get_category_edit($id);
            $this->template->title('Chỉnh sửa danh mục')->build('category-edit', $data);
        }
    }
		public function validation_post() {
        $rules = array(
            array(
                'field' => 'title',
                'label' => 'Tên bài viết',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'title_seo',
                'label' => 'Tiêu đề SEO',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'slug',
                'label' => 'Đường dẫn tới bài viết',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'content',
                'label' => 'Nội dung bài viết',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'description',
                'label' => 'Description',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'cat_id',
                'label' => 'Danh mục bài viết',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'thumbnail',
                'label' => 'Hình đại diện',
                'rules' => 'trim'
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run($this)) {
            return true;
        } else {
            return false;
        }
    }
    public function pagination($number = 30, $name) {
        $config['per_page'] = $number;
        $config['full_tag_open'] = '<ul class="pagination"><li class="page-item">';
        $config['full_tag_close'] = '</li></ul>';
        $config['attributes'] = array('class' => 'page-link');
        $config['first_link'] = 'Trang đầu';
        $config['last_link'] = 'Trang cuối';
        $config['next_link'] = '<i class="fa fa-angle-double-right"></i>';
        $config['prev_link'] = '<i class="fa fa-angle-double-left"></i>';
        $config['base_url'] = base_url('admin/'.$name);
        return $config;
    }
}
