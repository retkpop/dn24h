$(function(){function e(){var e=$(window).height()-$("body > .navbar").outerHeight()-$("body > .navbar + .navbar").outerHeight()-$("body > .navbar + .navbar-collapse").outerHeight();$(".page-container").attr("style","min-height:"+e+"px")}$(".panel-heading, .page-header-content, .panel-body").has("> .heading-elements").append('<a class="heading-elements-toggle"><i class="icon-menu"></i></a>'),$(".heading-elements-toggle").on("click",function(){$(this).parent().children(".heading-elements").toggleClass("visible")}),$(".breadcrumb-line").has(".breadcrumb-elements").append('<a class="breadcrumb-elements-toggle"><i class="icon-menu-open"></i></a>'),$(".breadcrumb-elements-toggle").on("click",function(){$(this).parent().children(".breadcrumb-elements").toggleClass("visible")}),$(document).on("click",".dropdown-content",function(e){e.stopPropagation()}),$(".navbar-nav .disabled a").on("click",function(e){e.preventDefault(),e.stopPropagation()}),$('.dropdown-content a[data-toggle="tab"]').on("click",function(e){$(this).tab("show")}),$(".panel [data-action=reload]").click(function(e){e.preventDefault();var a=$(this).parent().parent().parent().parent().parent();$(a).block({message:'<i class="icon-spinner2 spinner"></i>',overlayCSS:{backgroundColor:"#fff",opacity:.8,cursor:"wait","box-shadow":"0 0 0 1px #ddd"},css:{border:0,padding:0,backgroundColor:"none"}}),window.setTimeout(function(){$(a).unblock()},2e3)}),$(".category-title [data-action=reload]").click(function(e){e.preventDefault();var a=$(this).parent().parent().parent().parent();$(a).block({message:'<i class="icon-spinner2 spinner"></i>',overlayCSS:{backgroundColor:"#000",opacity:.5,cursor:"wait","box-shadow":"0 0 0 1px #000"},css:{border:0,padding:0,backgroundColor:"none",color:"#fff"}}),window.setTimeout(function(){$(a).unblock()},2e3)}),$(".sidebar-default .category-title [data-action=reload]").click(function(e){e.preventDefault();var a=$(this).parent().parent().parent().parent();$(a).block({message:'<i class="icon-spinner2 spinner"></i>',overlayCSS:{backgroundColor:"#fff",opacity:.8,cursor:"wait","box-shadow":"0 0 0 1px #ddd"},css:{border:0,padding:0,backgroundColor:"none"}}),window.setTimeout(function(){$(a).unblock()},2e3)}),$(".category-collapsed").children(".category-content").hide(),$(".category-collapsed").find("[data-action=collapse]").addClass("rotate-180"),$(".category-title [data-action=collapse]").click(function(a){a.preventDefault();var i=$(this).parent().parent().parent().nextAll();$(this).parents(".category-title").toggleClass("category-collapsed"),$(this).toggleClass("rotate-180"),e(),i.slideToggle(150)}),$(".panel-collapsed").children(".panel-heading").nextAll().hide(),$(".panel-collapsed").find("[data-action=collapse]").children("i").addClass("rotate-180"),$(".panel [data-action=collapse]").click(function(a){a.preventDefault();var i=$(this).parent().parent().parent().parent().nextAll();$(this).parents(".panel").toggleClass("panel-collapsed"),$(this).toggleClass("rotate-180"),e(),i.slideToggle(150)}),$(".panel [data-action=close]").click(function(a){a.preventDefault();var i=$(this).parent().parent().parent().parent().parent();e(),i.slideUp(150,function(){$(this).remove()})}),$(".category-title [data-action=close]").click(function(a){a.preventDefault();var i=$(this).parent().parent().parent().parent();e(),i.slideUp(150,function(){$(this).remove()})}),$(".navigation").find("li.active").parents("li").addClass("active"),$(".navigation").find("li").not(".active, .category-title").has("ul").children("ul").addClass("hidden-ul"),$(".navigation").find("li").has("ul").children("a").addClass("has-ul"),$(".dropdown-menu:not(.dropdown-content), .dropdown-menu:not(.dropdown-content) .dropdown-submenu").has("li.active").addClass("active").parents(".navbar-nav .dropdown:not(.language-switch), .navbar-nav .dropup:not(.language-switch)").addClass("active"),$(".navigation-main > .navigation-header > i").tooltip({placement:"right",container:"body"}),$(".navigation-main").find("li").has("ul").children("a").on("click",function(e){e.preventDefault(),$(this).parent("li").not(".disabled").not($(".sidebar-xs").not(".sidebar-xs-indicator").find(".navigation-main").children("li")).toggleClass("active").children("ul").slideToggle(250),$(".navigation-main").hasClass("navigation-accordion")&&$(this).parent("li").not(".disabled").not($(".sidebar-xs").not(".sidebar-xs-indicator").find(".navigation-main").children("li")).siblings(":has(.has-ul)").removeClass("active").children("ul").slideUp(250)}),$(".navigation-alt").find("li").has("ul").children("a").on("click",function(e){e.preventDefault(),$(this).parent("li").not(".disabled").toggleClass("active").children("ul").slideToggle(200),$(".navigation-alt").hasClass("navigation-accordion")&&$(this).parent("li").not(".disabled").siblings(":has(.has-ul)").removeClass("active").children("ul").slideUp(200)}),$(".sidebar-main-toggle").on("click",function(e){e.preventDefault(),$("body").toggleClass("sidebar-xs")}),$(document).on("click",".navigation .disabled a",function(e){e.preventDefault()}),$(document).on("click",".sidebar-control",function(a){e()}),$(document).on("click",".sidebar-main-hide",function(e){e.preventDefault(),$("body").toggleClass("sidebar-main-hidden")}),$(document).on("click",".sidebar-secondary-hide",function(e){e.preventDefault(),$("body").toggleClass("sidebar-secondary-hidden")}),$(document).on("click",".sidebar-detached-hide",function(e){e.preventDefault(),$("body").toggleClass("sidebar-detached-hidden")}),$(document).on("click",".sidebar-all-hide",function(e){e.preventDefault(),$("body").toggleClass("sidebar-all-hidden")}),$(document).on("click",".sidebar-opposite-toggle",function(e){e.preventDefault(),$("body").toggleClass("sidebar-opposite-visible"),$("body").hasClass("sidebar-opposite-visible")?($("body").addClass("sidebar-xs"),$(".navigation-main").children("li").children("ul").css("display","")):$("body").removeClass("sidebar-xs")}),$(document).on("click",".sidebar-opposite-main-hide",function(e){e.preventDefault(),$("body").toggleClass("sidebar-opposite-visible"),$("body").hasClass("sidebar-opposite-visible")?$("body").addClass("sidebar-main-hidden"):$("body").removeClass("sidebar-main-hidden")}),$(document).on("click",".sidebar-opposite-secondary-hide",function(e){e.preventDefault(),$("body").toggleClass("sidebar-opposite-visible"),$("body").hasClass("sidebar-opposite-visible")?$("body").addClass("sidebar-secondary-hidden"):$("body").removeClass("sidebar-secondary-hidden")}),$(document).on("click",".sidebar-opposite-hide",function(e){e.preventDefault(),$("body").toggleClass("sidebar-all-hidden"),$("body").hasClass("sidebar-all-hidden")?($("body").addClass("sidebar-opposite-visible"),$(".navigation-main").children("li").children("ul").css("display","")):$("body").removeClass("sidebar-opposite-visible")}),$(document).on("click",".sidebar-opposite-fix",function(e){e.preventDefault(),$("body").toggleClass("sidebar-opposite-visible")}),$(".sidebar-mobile-main-toggle").on("click",function(e){e.preventDefault(),$("body").toggleClass("sidebar-mobile-main").removeClass("sidebar-mobile-secondary sidebar-mobile-opposite sidebar-mobile-detached")}),$(".sidebar-mobile-secondary-toggle").on("click",function(e){e.preventDefault(),$("body").toggleClass("sidebar-mobile-secondary").removeClass("sidebar-mobile-main sidebar-mobile-opposite sidebar-mobile-detached")}),$(".sidebar-mobile-opposite-toggle").on("click",function(e){e.preventDefault(),$("body").toggleClass("sidebar-mobile-opposite").removeClass("sidebar-mobile-main sidebar-mobile-secondary sidebar-mobile-detached")}),$(".sidebar-mobile-detached-toggle").on("click",function(e){e.preventDefault(),$("body").toggleClass("sidebar-mobile-detached").removeClass("sidebar-mobile-main sidebar-mobile-secondary sidebar-mobile-opposite")}),$(window).on("resize",function(){setTimeout(function(){e(),$(window).width()<=768?($("body").addClass("sidebar-xs-indicator"),$(".sidebar-opposite").insertBefore(".content-wrapper"),$(".sidebar-detached").insertBefore(".content-wrapper")):($("body").removeClass("sidebar-xs-indicator"),$(".sidebar-opposite").insertAfter(".content-wrapper"),$("body").removeClass("sidebar-mobile-main sidebar-mobile-secondary sidebar-mobile-detached sidebar-mobile-opposite"),$("body").hasClass("has-detached-left")?$(".sidebar-detached").insertBefore(".container-detached"):$("body").hasClass("has-detached-right")&&$(".sidebar-detached").insertAfter(".container-detached"))},100)}).resize(),$('[data-popup="popover"]').popover(),$('[data-popup="tooltip"]').tooltip()});

$(document).ready(function () {
    var ns = $('ol.sortable').nestedSortable({
        forcePlaceholderSize: true,
        handle: '.menu-wrap',
        helper: 'clone',
        items: 'li',
        opacity: .6,
        placeholder: 'placeholder',
        revert: 250,
        tabSize: 25,
        tolerance: 'pointer',
        toleranceElement: '> .menu-wrap',
        maxLevels: 1,
        isTree: true,
        expandOnHover: 700,
        startCollapsed: false,
        change: function () {
        }
    });
    $(".btnAddVideo").on("click", function(){
        var exId = $(this).closest(".groupFormEx").attr("id");
        $(this).closest(".groupFormEx").find(".formAddVideo").append('<li class="item">'
            + '<div class="row menu-wrap">'
                + '<input type="hidden" name="change[]" value="1" class="changeVideo" />'
                + '<input type="hidden" value="'+exId+'" name="exVal[]" />'
                + '<div class="col-md-4">'
                    + '<div class="form-group">'
                        + '<div class="formVideo">'
                            + '<label>Title</label>'
                            + '<input type="text" class="form-control form-text" name="title_ex[]" required />'
                        + '</div>'
                    + '</div>'
                + '</div>'
                + '<div class="col-md-3">'
                    + '<div class="form-group">'
                        + '<div class="formVideo selectVideo">'
                            + '<label>File gallery</label>'
                            + '<input type="file" name="file_gallery[]" accept="image/*" class="form-control" required />'
                        + '</div>'
                    + '</div>'
                + '</div>'
                + '<div class="col-md-5 formExcerpt">'
                    + '<div class="form-group">'
                        + '<div class="excerpt_Video">'
                            + '<label>Chú thích</label>'
                            + '<input type="text" class="form-control form-text" name="excerpt_ex[]" />'
                        + '</div>'
                    + '</div>'
                + '</div>'
            + '</div>'
            + '<div class="removeItem"><i class="fa fa-times" aria-hidden="true"></i></div>'
        + '</li>');
        $("div.removeItem").on("click", function(){
            $(this).parent().remove();
        });
    });
    $(".editProductForm div.removeItem").on("click", function(){
        var exPrID = $(this).parent().attr("exPrID");
        $(this).closest(".formAddVideo").append('<input type="hidden" value="'+exPrID+'" name="ex_remove[]"/>');
        $(this).parent().remove();
    });
    $('.videoUpload .changeVideo').on("click", function(){
        $(this).closest('.menu-wrap').find(".changeVideo").val("1");
        $(this).closest('.grUpload').find(".oldVideo").html('');
        $(this).closest('.menu-wrap').find(".selectVideo").html('<label>File gallery</label>'
        + '<input type="file" name="file_gallery[]" accept="image/*" class="form-control" required />');
    });
    $("a#delete").click(function(e){
        if(!confirm('Bạn có muốn xóa bài này? \n - Bài viết sẽ không khôi phục được \n - Ảnh đại diện sẽ bị xóa \n - Toàn bộ hình ảnh trong bài sẽ bị xóa')){
            e.preventDefault();
            return false;
        }
        return true;
    });
    $("a#delete_order").click(function(e){
        if(!confirm('Bạn có muốn xóa đơn hàng này? \n')){
            e.preventDefault();
            return false;
        }
        return true;
    });
    $("a#delete_cat").click(function(e){
        if(!confirm('Bạn muốn xóa danh mục này?')){
            e.preventDefault();
            return false;
        }
        return true;
    });
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip(); 
    });
    var base = $('base').attr('href');

    $('.select2').select2();
    $('.alert .close').click(function(){
        $(this).closest('.alert').remove();
    })
    $('.bootstrap-select').selectpicker();
    $('.top-check').change(function () {

        if(this.checked){
            $('.item-checkbox').prop('checked', true);
            $('.item-checkbox, .top-check').parent('span').removeClass('checked').addClass('checked');
        }else{
            $('.item-checkbox').prop('checked', false);
            $('.item-checkbox').parent('span').removeClass('checked');
            $('.item-checkbox, .top-check').parent('span').removeClass('checked');
        }
    })

    $('.select-bulk-action').on('change', function(){
        $('.select-bulk-action').val($(this).val());
    })
    
    $('#filecount').filestyle({
        input : false,
        buttonName : 'btn-danger',
        iconName : 'glyphicon glyphicon-folder-close',
    });
    $('#filecount').change(function () {
        var ext = this.value.match(/\.(.+)$/)[1];
        switch (ext) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
                $('#uploadButton').attr('disabled', false);
                break;
            default:
                alert('Định dạng file upload hình ảnh không hợp lệ');
                top.location.href = '';
        }
    });
})
