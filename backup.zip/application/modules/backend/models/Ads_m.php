<?php

Class Ads_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function all_ads() {
        $query = $this->db->get('ads');
        if($query->num_rows()>0) {
            return $query->result_array();
        } else {
            return false;
        }
    }
    public function delete_ads($id) {
        $this->db->where('id', $id)->delete('ads');
        if($this->db->affected_rows()) {
          $adss = $this->db->where('ads_id', $id)->get('ads_detail');
          if($adss->num_row()>0) {
              foreach($ads->result_array() as $ads) {
                if(!empty($ads['img'])) {
                    $img_dir = dirname(BASEPATH) . '/uploads/ads/' . $ads['img'];
                    unlink($img_dir);
                }
              }
              $this->db->where('ads_id', $id)->delete('ads_detail');
          }
        } else {
            return false;
        }
    }
    public function add_ads($input) {
        $query = $this->db->where('slug', $input['slug'])->get('ads');
        if($query->num_rows()>0) {
            $this->session->set_flashdata('return_add', false);
        } else {
            $this->db->insert('ads', $input);
            $this->session->set_flashdata('return_add', $this->db->insert_id());
        }
    }
    public function add_ads_detail($input) {
        $this->db->insert('ads_detail', $input);
        $this->session->set_flashdata('return_add', $this->db->insert_id());
    }
    public function get_ads_detail($id) {
        $ads = $this->db->order_by('arrange', 'asc')->where('ads_id', $id)->get('ads_detail');
        if($ads->num_rows()>0) {
            return $ads->result_array();
        } else {
            return false;
        }
    }
    public function delete_ads_detail($id, $ads_id) {
        $ads = $this->db->where('id', $id)->where('ads_id', $ads_id)->get('ads_detail');
        if($ads->num_row()>0) {
          $ads = $ads->row_array();
          $this->db->where('id', $id)->where('ads_id', $ads_id)->delete('ads_detail');
          if($this->db->affected_rows()) {
              if(!empty($ads['img'])) {
                  $img_dir = dirname(BASEPATH) . '/uploads/ads/' . $ads['img'];
                  unlink($img_dir);
              }
              return true;
          }
        }
        return false;
    }
    public function update_arrange_ads($input, $ads_id) {
        $data = array (
            'arrange' => $input['arrange']
        );
        $this->db->where('id', $input['id'])->where('ads_id', $ads_id)->update('ads_detail', $data);
    }
}
?>
