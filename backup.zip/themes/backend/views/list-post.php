<?php require_once 'header.php'; ?>
                <!-- Main content -->
                <div class="content-wrapper">
                    <!-- Page header -->
                    <div class="page-header">
                        <div class="page-header-content">
                            <div class="page-title">
                                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                            </div>

                            <div class="heading-elements">
                                <div class="heading-btn-group">
                                    <a href="<?php echo base_url('admin/new_post') ?>" class="btn btn-link btn-float has-text"><i class="icon-plus2 text-primary"></i><span>Thêm bài viết</span></a>
                                </div>
                            </div>
                            <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
                        </div>
                        <div class="breadcrumb-line">
                            <ol class="breadcrumb">
                                <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                                <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                            </ol>
                        </div>
                    </div>
                    <!-- /page header -->
                    <!-- Content area -->
                    <div class="content">
                        <?php echo form_open('admin/bulk_action'); ?>
                            <!-- Bulk Action -->
                            <div class="bulk-action row">
                                <div class="col-md-2">
                                    <div class="input-group input-group-xs">
                                        <select name="bulk_action" class="select select-bulk-action">
                                            <option value="-1">-- Bulk Action</option>
                                            <option value="delete">Delete</option>
                                        </select>
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" value="bulk_action">&Aacute;p dụng</button>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="pagination pull-right"><?php echo $this->pagination->create_links(); // tạo link phân trang ?></div>
                                </div>
                                <div class="col-md-offset-4 col-md-3">
                                    <div class="filter">
                                        <input type="text" placeholder="Nhập thông tin tìm kiếm" class="form-control form-searchUser" />
                                        <button type="button" class="btnSearchUser btn bg-teal btn-ladda btn-ladda-progress" data-style="expand-right" data-spinner-size="20">
                                            <span class="ladda-label">Search</span>
                                        </button>
                                    </div>
                                </div>
                                <script type="text/javascript">
                                    Number.prototype.format = function(n, x, s, c) {
                                        var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
                                            num = this.toFixed(Math.max(0, ~~n));
                                        return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
                                    };
                                    $(".form-searchUser").on('keyup keypress', function(e) {
                                        var keyCode = e.keyCode || e.which;
                                        if (keyCode === 13) {
                                            e.preventDefault();
                                            $(".btnSearchUser").click();
                                        }
                                    });
                                    $(".btnSearchUser").on("click", function(){
                                        var valueSearch = $(".form-searchUser").val();
                                        var baseUrl = "<?php echo base_url() ?>";
                                        if(valueSearch.trim() == "") {
                                            window.location.replace("<?php echo current_url() ?>");
                                        } else {
                                            $.ajax({
                                                type: "POST",
                                                url: baseUrl + "admin/fillter_post",
                                                cache: false,
                                                dataType: 'json',
                                                data: {"valueSearch": valueSearch},
                                                success: function(data) {
                                                    if(data.code == "0") {
                                                        $('.listPosts table tbody').html('');
                                                        data.Data.forEach(function(detailProduct) {
                                                            var tinhtrang = (parseFloat(detailProduct.number) - parseFloat(detailProduct.check_order) > 0)? '<div class="conhang">Còn hàng</div>' : '<div class="hethang">Hết hàng</div>';
                                                            $('.listPosts table tbody').append('<tr><td><input type="checkbox" value="'+detailProduct.id+'" name="id[]" class="styled item-checkbox"></td>'
                                                                + '<td>'
                                                                    + '<a href="'+baseUrl+'admin/product_edit/'+detailProduct.id+'"><img src="'+detailProduct.thumbnail+'" width="80" class="img-responsive"></a>'
                                                                + '</td>'
                                                                + '<td>'
                                                                    + '<a href="'+baseUrl+'admin/product_edit/'+detailProduct.id+'">'+detailProduct.title+'</a>'
                                                                + '</td>'
                                                                + '<td>'+detailProduct.slug+'</td>'
                                                                + '<td>'+detailProduct.cat.title+'</td>'
                                                                + '<td>'+detailProduct.author_id.fullname+'</td>'
                                                                + '<td>'+detailProduct.date_post+'</td>'
                                                                + '<td>'
                                                                    + '<a class="btn btn-xs btn-icon btn-default" href="'+baseUrl+'admin/post_edit/'+detailProduct.id+'">'
                                                                        + '<i class="icon-pen"></i>'
                                                                    + '</a>'
                                                                    + '<a class="btn btn-xs btn-icon btn-danger" href="'+baseUrl+'admin/delete_post/'+detailProduct.id+'">'
                                                                        + '<i class="icon-minus2"></i>'
                                                                    + '</a>'
                                                                    + '<a target="_blank" class="btn btn-icon btn-xs btn-info" href="'+detailProduct.url+'">'
                                                                        + '<i class="icon-eye2"></i>'
                                                                    + '</a>'
                                                                + '</td>'
                                                            + '</tr>');
                                                        });
                                                    } else {
                                                        $('.listPosts table tbody').html('<tr><td colspan="8" style="text-align: left; color: red">Không tìm thấy kết quả tìm kiếm</td></tr>');
                                                    }
                                                }
                                            })
                                        }
                                    });
                                </script>

                            </div>
                            <!-- Bulk Action End -->
                            <div class="panel panel-flat">
                                <div class="panel-body no-padding">
                                    <div class="table-responsive listPosts">
                                        <table class="table table-data">
                                            <thead>
                                                <tr>
                                                    <th><input type="checkbox" class="top-check styled"></th>
                                                    <th>Thumbnail</th>
                                                    <th>Tên bài viết</th>
                                                    <th>Slug</th>
                                                    <th>Danh mục</th>
                                                    <th>Tác giả</th>
                                                    <th>Ngày đăng</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(!empty($posts)): foreach ($posts as $value):  ?>
                                                <tr class="">
                                                    <td>
                                                        <input type="checkbox" name="id[]" value="<?php echo $value['id'] ?>" class="item-checkbox styled">
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo base_url('admin/post_edit/' . $value['id']) ?>">
                                                            <img src="<?php echo $value['thumbnail'] ?>" alt="<?php echo $value['title'] ?>" width="80" class="img-responsive">
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo base_url('admin/post_edit/' . $value['id']) ?>"><?php echo $value['title'] ?></a>
                                                    </td>
                                                    <td><?php echo $value['slug'] ?></td>
                                                    <td><?php echo $value['cat']['title'] ?></td>
                                                    <td><?php echo $value['author_id']['fullname'] ?></td>
                                                    <td><?php echo $value['date_post'] ?></td>
                                                    <td>
                                                        <a class="btn btn-xs btn-default  btn-icon" href="<?php echo base_url('admin/post_edit/' . $value['id']) ?>">
                                                            <i class="icon-pen"></i>
                                                        </a>
                                                        <a class="btn btn-xs btn-danger  btn-icon" id="delete" href="<?php echo base_url('admin/delete_post/' . $value['id']) ?>"><i class="icon-minus2"></i></a>
                                                        <a target="_blank" class="btn btn-icon btn-xs btn-info" href="<?php echo $value['url'] ?>">
                                                            <i class="icon-eye2"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; endif; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th><input type="checkbox" class="top-check styled"></th>
                                                    <th>Thumbnail</th>
                                                    <th>Tên bài viết</th>
                                                    <th>Slug</th>
                                                    <th>Danh mục</th>
                                                    <th>Tác giả</th>
                                                    <th>Ngày xuất bản</th>
                                                    <th></th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <!-- Bulk Action -->
                            <div class="bulk-action row">
                                <div class="col-sm-4 col-md-3 col-lg-2">
                                    <div class="input-group input-group-xs">
                                        <select name="bulk_action" class="select-bulk-action">
                                            <option value="">-- Bulk Action</option>
                                            <option value="delete">Delete</option>
                                        </select>
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" value="bulk_action">&Aacute;p dụng</button>
                                        </span>
                                    </div><!-- /input-group -->
                                </div>
                                <div class="col-sm-4 col-md-3 col-lg-2">
                                    <div class="pagination pull-right"><?php echo $this->pagination->create_links(); // tạo link phân trang ?></div>
                                </div>
                            </div>
                            <!-- Bulk Action End -->
                        <?php echo form_close() ?>
                    </div>
                    <!-- /content area -->
                </div>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
        <!-- /page container -->
    </body>
</html>
