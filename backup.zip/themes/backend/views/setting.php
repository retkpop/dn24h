<?php require_once 'header.php'; ?>
                <div class="content-wrapper">
                    <!-- Page header -->
                    <div class="page-header">
                        <div class="page-header-content">
                            <div class="page-title">
                                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                            </div>
                        </div>
                        <div class="breadcrumb-line">
                            <ol class="breadcrumb">
                                <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                                <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                            </ol>
                        </div>
                    </div>
                    <!-- /page header -->


                    <!-- Content area -->
                    <div class="content">
                        <!-- Panel _start -->
                        <div class="panel panel-flat">
                            <div class="panel-heading">
                                <h5>Cài đặt</h5>
                                <div class="heading-elements">
                                    <ul class="icons-list">
                                        <li><a data-action="collapse"></a></li>
                                        <li><a data-action="reload"></a></li>
                                        <li><a data-action="close"></a></li>
                                    </ul>
                                </div>
                            </div>
                            <?php if(validation_errors() != false): ?>
                            <div class="panel-heading">
                                <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <strong>Có lỗi xảy ra!</strong>
                                    <ul>
                                        <?php echo validation_errors('<li>' , '</li>'); ?>
                                    </ul>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="panel-body">
                                <?php echo form_open_multipart(); ?>
                                <!-- Setting Item -->
                                <div class="form-group">
                                    <label for="name_shop" class="control-label col-md-2">Tên cửa hàng</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('name_shop', $options['name_shop'], 'class="form-control" id="shop_name"') ?>
                                        <div class="help-block">Đặt tên cửa hàng của bạn</div>
                                    </div>
                                </div>
                                <!-- Setting Item End -->
                                <!-- Setting Item -->
                                <div class="form-group">
                                    <label for="description" class="control-label col-md-2">Giới thiệu ngắn gọn</label>
                                    <div class="col-md-10">
                                        <textarea class="form-control" name="description" cols="50" rows="3" id="short_description"><?php echo $options['description'] ?></textarea>
                                        <div class="help-block">Giới thiệu ngắn gọn về cửa hàng (150 ký tự trở lại)</div>
                                    </div>
                                </div>
                                <!-- Setting Item End -->
                                <div class="form-group">
                                    <label for="favicon" class="control-label col-md-2">Favicon</label>
                                    <div class="col-md-10">
                                        <input type="file" class="form-control" id="favicon" name="favicon" />
                                        <div class="help-block"></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="title_about" class="control-label col-md-2">Title About</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('title_about', $options['title_about'], 'class="form-control" id="title_about"') ?>
                                        <div class="help-block">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="excerpt_about" class="control-label col-md-2">Excerpt About</label>
                                    <div class="col-md-10">
                                        <?php echo form_textarea('excerpt_about', $options['excerpt_about'], 'class="form-control" id="excerpt_about"') ?>
                                        <div class="help-block">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="link_about" class="control-label col-md-2">Link About</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('link_about', $options['link_about'], 'class="form-control" id="link_about"') ?>
                                        <div class="help-block">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="banner_about" class="control-label col-md-2">Banner About Home</label>
                                    <div class="col-md-10">
                                        <input type="file" class="form-control" id="favicon" name="banner_about" />
                                        <div class="help-block"></div>
                                    </div>
                                </div>

                                <!-- Setting Item -->
                                <div class="form-group">
                                    <label for="phone" class="control-label col-md-2">Điện thoại</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('phone', $options['phone'], 'class="form-control" id="phone"') ?>
                                        <div class="help-block">Số điện thoại liên lạc chính</div>
                                    </div>
                                </div>
                                <!-- Setting Item End -->
                                <!-- Setting Item -->
                                <div class="form-group">
                                    <label for="phone2" class="control-label col-md-2">Điện thoại 2</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('phone2', $options['phone2'], 'class="form-control" id="phone2"') ?>
                                        <div class="help-block">Số điện thoại</div>
                                    </div>
                                </div>
                                <!-- Setting Item End -->
                                <div class="form-group">
                                    <label for="address" class="control-label col-md-2">Địa chỉ</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('address', $options['address'], 'class="form-control" id="address"') ?>
                                        <div class="help-block">Địa chỉ</div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="link_map" class="control-label col-md-2">Maps</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('link_map', $options['link_map'], 'class="form-control" id="link_map"') ?>
                                        <div class="help-block">Link tới map dẫn đường</div>
                                    </div>
                                </div>
                                <!-- Setting Item -->
                                <div class="form-group">
                                    <label for="email" class="control-label col-md-2">Địa chỉ email</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('email', $options['email'], 'class="form-control" id="email"') ?>
                                        <div class="help-block">Email liên lạc</div>
                                    </div>
                                </div>
                                <!-- Setting Item End -->
                                <!-- Setting Item -->
                                <div class="form-group">
                                    <label for="numb_show" class="control-label col-md-2">Số lượng bài viết hiển thị</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('numb_show', $options['numb_show'], 'class="form-control" id="numb_show"') ?>
                                        <div class="help-block">Số bài viết hiển thị ngoài trang chủ và trang danh sách sản phẩm</div>
                                    </div>
                                </div>
                                <!-- Setting Item End -->

                                <!-- Setting Item -->
                                <div class="form-group">
                                    <label for="facebook_page" class="control-label col-md-2">Link trang Facebook</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('facebook_page', $options['facebook_page'], 'class="form-control" id="facebook_page"') ?>
                                        <div class="help-block">Điền link trang facebook</div>
                                    </div>
                                </div>
                                <!-- Setting Item End -->

                                <!-- Setting Item -->
                                <div class="form-group">
                                    <label for="google_page" class="control-label col-md-2">Link trang Google</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('google_page', $options['google_page'], 'class="form-control" id="google_page"') ?>
                                        <div class="help-block">Điền link trang Google+</div>
                                    </div>
                                </div>
                                <!-- Setting Item End -->

                                <!-- Setting Item -->
                                <div class="form-group">
                                    <label for="youtube_page" class="control-label col-md-2">Link Youtube Channel</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('youtube_page', $options['youtube_page'], 'class="form-control" id="youtube"') ?>
                                        <div class="help-block">Điền link Youtube Channel</div>
                                    </div>
                                </div>
                                <!-- Setting Item End -->

                                <!-- Setting Item -->
                                <div class="form-group">
                                    <label for="twitter" class="control-label col-md-2">Twitter</label>
                                    <div class="col-md-10">
                                        <?php echo form_input('twitter', $options['twitter'], 'class="form-control" id="twitter"') ?>
                                        <div class="help-block">Điền link Twitter</div>
                                    </div>
                                </div>
                                <!-- Setting Item End -->
                                <div class="form-group">
                                    <div class="col-md-10 col-md-offset-2">
                                        <input class="btn btn-primary" type="submit" value="Lưu lại">
                                        <a href="<?php echo base_url('admin') ?>" class="btn btn-default">Thoát ra</a>
                                    </div>
                                </div>
                                <?php echo form_close() ?>
                            </div>
                        </div>
                    </div>
                    <!-- /content area -->
                </div>
                <script type="text/javascript">
                    CKEDITOR.replace('excerpt_about', {height: 200,});
                </script>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
    </body>
</html>

