<?php require_once 'header.php'; ?>

                <!-- Main content -->
                <div class="content-wrapper">
                    <!-- Page header -->
                    <div class="page-header">
                        <div class="page-header-content">
                            <div class="page-title">
                                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                            </div>
                        </div>
                        <div class="breadcrumb-line">
                            <ol class="breadcrumb">
                                <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                                <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                            </ol>
                        </div>
                    </div>
                    <!-- /page header -->


                    <!-- Content area -->
                    <div class="content">
                        <div class="col-md-12">
                            <?php if(isset($_SESSION['return_add'])): ?>
                            <div class="flash alert <?php echo ($_SESSION['return_add'] == 0)? 'alert-error': 'alert-success' ?> alert-styled-left">
                                <?php if($_SESSION['return_add'] == 0): ?>
                                <span class="text-semibold">Lỗi! Danh mục đã tồn tại</span>
                                <?php else: ?>
                                <span class="text-semibold">Tạo danh mục mới thành công</span>
                                <?php endif; ?>
                                <div class="heading-elements">
                                    <ul class="icons-list">
                                        <li><a class="close" data-action="close"></a></li>
                                    </ul>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(validation_errors() != false): ?>
                            <div class="alert alert-danger">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <strong>Có lỗi xảy ra!</strong>
                                <ul>
                                    <?php echo validation_errors('<li>' , '</li>'); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-5 col-lg-4">
                            <?php echo form_open(); ?>
                                <div class="form-group">
                                    <label for="">Tên danh mục</label>
                                    <?php if(isset($_POST['title'])): $title = $_POST['title']; else: $title = ''; endif; ?>
                                    <?php echo form_input('title', $title, 'class="form-control" id="title" placeholder="Tên danh mục sản phẩm"') ?>
                                    <div class="help-block">Tên danh mục hiển thị trên website</div>
                                </div>
                                <div class="form-group">
                                    <label for="title_seo">Tên danh mục hiện ở title</label>
                                    <?php if(isset($_POST['title_seo'])): $title_seo = $_POST['title_seo']; else: $title_seo = ''; endif; ?>
                                    <?php echo form_input('title_seo', $title_seo, 'class="form-control" id="title_seo" placeholder="Tên danh mục sản phẩm hiện ở title"') ?>
                                </div>
                                <div class="form-group">
                                    <label for="">Slug</label>
                                    <?php if(isset($_POST['slug'])): $slug = $_POST['slug']; else: $slug = ''; endif; ?>
                                    <?php echo form_input('slug', $slug, 'class="form-control" id="slug" placeholder="Đường dẫn tới danh mục"') ?>
                                    <div class="help-block">Đường dẫn tới danh mục: Thường là các ký tự viết thường, số và dấu gạch ngang (Không bao gồm các ký tự đặc biệt) </div>
                                </div>

                                <div class="form-group row">
                                    <label for="" class="col-md-12">Parent</label>
                                    <div class="col-md-8">
                                        <select name="parent" class="form-control select2">
                                            <option value="">-- Chọn danh mục --</option>
                                            <?php echo $all_cat; ?>
                                        </select>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="help-block col-xs-12">
                                        Danh mục cha
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="">Mô tả</label>
                                    <?php if(isset($_POST['description'])): $description = $_POST['description']; else: $description = ''; endif; ?>
                                    <?php echo form_textarea('description', $description, 'class="form-control" rows="3" cols="40" style="height: 100px" id="description"') ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">Thêm danh mục</button>
                                </div>
                            <?php echo form_close() ?>
                        </div>
                        <!-- List Blog Categories Start -->
                        <div class="col-md-7 col-lg-8">
                            <?php echo form_open('admin/bulk_cat?page=' . $page); ?>
                                <!-- Bulk Action -->
                                <div class="bulk-action row">
                                    <div class="col-sm-6 col-md-5 col-lg-4">
                                        <div class="input-group input-group-xs">
                                            <select name="bulk_action" class="select-bulk-action">
                                                <option value="-1">-- Bulk Action</option>
                                                <option value="delete">Delete</option>
                                            </select>
                                            <span class="input-group-btn">
                                                <button class="btn btn-default" value="bulk_action">&Aacute;p dụng</button>
                                            </span>
                                        </div><!-- /input-group -->
                                    </div>
                                </div>
                                <!-- Bulk Action End -->
                                <div class="clearfix"></div>
                                <div class="panel panel-flat">
                                    <div class="panel-body no-padding">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th><input class="styled top-check" type="checkbox"></th>
                                                        <th>Tên danh mục</th>
                                                        <th width="300">Mô tả</th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php echo $categorys; ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th><input class="styled top-check" type="checkbox"></th>
                                                        <th>Tên danh mục</th>
                                                        <th width="300">Mô tả</th>
                                                        <th></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                                <!-- Bulk Action -->
                                <div class="bulk-action row">
                                    <div class="col-sm-6 col-md-5 col-lg-4">
                                        <div class="input-group input-group-xs">
                                            <select name="bulk_action" class="select-bulk-action">
                                                <option value="-1">-- Bulk Action</option>
                                                <option value="delete">Delete</option>
                                            </select>
                                            <span class="input-group-btn">
                                                <button class="btn btn-default" value="bulk_action">&Aacute;p dụng</button>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <!-- Bulk Action End -->
                            <?php echo form_close(); ?>
                        </div>
                        <!-- List Blog Categories End -->
                    </div>
                    <!-- /content area -->
                </div>
                <script>
                    $(document).ready(function () {
                        $('#title').on('change, keyup', function () {
                            var value = $(this).val();
                            var uri;
                            if (value == '') {
                                uri =  ' ';
                            } else {
                                uri = value;
                            }
                            $.ajax({
                                url: encodeURI('<?php echo base_url('admin/createSlug/') ?>' + uri),
                                success: function (data) {
                                    $('#slug').val(data);
                                }
                            });
                            $('#description, #title_seo').val(value);
                        });
                    })
                </script>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
        <script>
            $(document).ready(function () {
                $('.select2').select2();
            })
        </script>

    </body>
</html>
