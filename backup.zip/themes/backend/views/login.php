<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Đăng nhập</title>
        <!-- Global stylesheets -->
        <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
        <link href="<?php echo $this->template->dir(); ?>views/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo $this->template->dir(); ?>views/css/bootstrap.css" rel="stylesheet" type="text/css">
        <link href="<?php echo $this->template->dir(); ?>views/css/core.css" rel="stylesheet" type="text/css">
        <link href="<?php echo $this->template->dir(); ?>views/css/components.css" rel="stylesheet" type="text/css">
        <link href="<?php echo $this->template->dir(); ?>views/css/colors.css" rel="stylesheet" type="text/css">
        <!-- /global stylesheets -->
        <!-- Core JS files -->
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/pace.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/blockui.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/app.js"></script>
    </head>
    <body>
        <!-- Page container -->
        <div class="page-container login-container">
            <div class="page-content">
                <div class="content-wrapper">
                    <div class="content">
                        <?php echo form_open(); ?>
                            <div class="panel panel-body login-form">
                                <div class="text-center">
                                    <div class="icon-object border-slate-300 text-slate-300"><i class="icon-reading"></i></div>
                                    <h5 class="content-group">Đăng nhập hệ thống
                                        <small class="display-block">Nhập thông tin của bạn</small>
                                    </h5>
                                </div>
                                <div class="form-group has-feedback has-feedback-left">
                                    <?php echo form_input('email', '', 'class="form-control" placeholder="Nhập email của bạn"') ?>
                                    <div class="form-control-feedback">
                                        <i class="icon-user text-muted"></i>
                                    </div>
                                    <?php echo form_error('email', '<div class="clearfix"></div><p style="color: #777;"><small>', '</small></p>'); ?>
                                </div>
                                <div class="form-group has-feedback has-feedback-left">
                                    <?php echo form_password('password', '', 'class="form-control" placeholder="Nhập mật khẩu"') ?>
                                    <div class="form-control-feedback">
                                        <i class="icon-lock2 text-muted"></i>
                                    </div>
                                    <?php echo form_error('password', '<div class="clearfix"></div><p style="color: #777;"><small>', '</small></p>'); ?>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block">Đăng nhập <i class="icon-circle-right2 position-right"></i> </button>
                                </div>
                                <div class="alert alert-success" role="alert">
                                    <?php if(isset($notification)): echo $notification; else: ?>
                                    Trang dành riêng cho quản trị website, nếu không liên quan vui lòng thoát ra!
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php echo form_close(); ?>
                        <!-- /simple login form -->
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
