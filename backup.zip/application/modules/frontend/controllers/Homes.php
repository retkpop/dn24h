<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Homes extends CI_Controller {
	public function __construct() {
      parent::__construct();
      $this->load->library('session');  //Load the Session
      $this->template->set_theme('frontend');
      date_default_timezone_set('Asia/Saigon');
      $method = $this->router->fetch_method();
      //pagination
      $this->load->library('pagination');
      $this->load->helper('url');
			$this->load->model('system_m');
			$this->load->model('home_m');
			$options = $this->system_m->get_options();
			$this->template->set('page', $method)->set('options', $options)->set_breadcrumb('Home page', base_url('index'));
  }
	public function index() {
			$options = $this->system_m->get_options();
      $data['info'] = array (
          'title' => $options['site_name'],
          'description' => $options['description'],
      );
			$data['posts_hot'] = $this->home_m->posts_hot(5);
			$data['communities'] = $this->home_m->communities(5);
			$data['post_news'] = $this->home_m->list_post_news(10);
			$this->template->title('Website')->build('index', $data);
	}
}
