<?php require_once 'header.php'; ?>
                <div class="content-wrapper">
                    <!-- Page header -->
                    <div class="page-header">
                        <div class="page-header-content">
                            <div class="page-title">
                                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                            </div>
                        </div>
                        <div class="breadcrumb-line">
                            <ol class="breadcrumb">
                                <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                                <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                            </ol>
                        </div>
                    </div>
                    <!-- /page header -->


                    <!-- Content area -->
                    <div class="content">

                        <div class="row">
                            <div class="col-md-5">
                                <h5><?php echo $template['title'] ?></h5>
                                <hr>
                                <div class="inner">
                                    <?php if(isset($_SESSION['return_add'])): ?>
                                    <div class="flash alert <?php echo ($_SESSION['return_add'] == false)? 'alert-error': 'alert-success' ?> alert-styled-left">
                                        <?php if($_SESSION['return_add'] == false): ?>
                                        <span class="text-semibold">Lỗi! <?php echo $template['title'] ?> đã tồn tại</span>
                                        <?php else: ?>
                                        <span class="text-semibold">Tạo <?php echo $template['title'] ?> mới thành công</span>
                                        <?php endif; ?>
                                        <div class="heading-elements">
                                            <ul class="icons-list">
                                                <li><a class="close" data-action="close"></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(validation_errors() != false): ?>
                                    <div class="alert alert-danger">
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        <strong>Có lỗi xảy ra!</strong>
                                        <ul>
                                            <?php echo validation_errors('<li>' , '</li>'); ?>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="clearfix"></div>
                                <?php echo form_open_multipart() ?>
                                    <div class="form-group">
                                        <label for="name">Tên cộng đồng</label>
                                        <?php echo form_input('name', '', 'class="form-control" id="name"') ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="name_seo">Tên cộng đồng SEO</label>
                                        <?php echo form_input('name_seo', '', 'class="form-control" id="name_seo"') ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="slug">Slug</label>
                                        <?php echo form_input('slug', '', 'class="form-control" id="slug"') ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <?php echo form_textarea('description', '', 'class="form-control" id="description" style="height: 100px"') ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="thumbnail">Thumbnail</label>
                                        <input type="file" name="thumbnail_community" class="form-control"/>
                                    </div>
                                    <button class="btn btn-primary">Thêm cộng đồng</button>
                                <?php echo form_close() ?>
                                <script>
                                    $(document).ready(function () {
                                        $('#name').on('change, keyup', function () {
                                            var value = $(this).val();
                                            var uri;
                                            if (value == '') {
                                                uri =  ' ';
                                            } else {
                                                uri = value;
                                            }
                                            $('#name_seo, #description').val(value);
                                            $.ajax({
                                                url: encodeURI('<?php echo base_url('admin/createSlug/') ?>/' + uri),
                                                success: function (data) {
                                                    $('#slug').val(data);
                                                }
                                            });
                                        });
                                    })
                                </script>
                            </div>
                            <div class="col-md-7">
                                <h5>Danh sách cộng đồng</h5>
                                <hr>
                                <div class="panel panel-flat">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Tên cộng đồng</th>
                                                    <th>Slug</th>
                                                    <th style="width: 150px;" class="text-center">Tùy chọn</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(!empty($communities)): foreach ($communities as $community): ?>
                                                <tr id="<?php echo $community['id'] ?>">
                                                    <td>
                                                        <a href="<?php echo base_url('congdong/' . $community['slug']); ?>"><?php echo $community['name'] ?></a>
                                                    </td>
                                                    <td><?php echo $community['slug'] ?></td>
                                                    <td>
                                                        <a target="_blank" class="btn btn-icon btn-xs btn-info" href="<?php echo base_url('congdong/' . $community['slug']); ?>">
                                                            <i class="icon-eye2"></i>
                                                        </a>
                                                        <a class="btn btn-xs btn-default" href="<?php echo base_url('admin/community/edit?id=' . $community['id']); ?>">
                                                            <i class="icon-pen"></i>
                                                        </a>
                                                        <a class="btn btn-xs btn-icon btn-danger remo_ads" idAds="<?php echo $community['id'] ?>">
                                                            <i class="icon-minus2"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; endif; ?>
                                            </tbody>
                                        </table>
                                        <script>
                                            $("a.remo_ads").click(function(e){
                                                if(!confirm('Xóa cộng đồng này?')){
                                                    e.preventDefault();
                                                    return false;
                                                }
                                                var id = $(this).parent().find('a.remo_ads').attr('idAds');
                                                $.ajax({
                                                    type: "POST",
                                                    url: "<?php echo base_url('admin/community/delete_community/') ?>",
                                                    cache: false,
                                                    dataType: 'json',
                                                    data: {"id":id},
                                                    success: function(data) {
                                                        if(data == 1) {
                                                            window.location.replace("<?php echo base_url('admin/community/add') ?>");
                                                        }
                                                    }
                                                });
                                            });
                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <!-- /content area -->
                </div>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
    </body>
</html>
