<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Category extends CI_Controller {
	public function __construct() {
      parent::__construct();
      $this->load->library('session');  //Load the Session
      $this->template->set_theme('frontend');
      date_default_timezone_set('Asia/Saigon');
      $method = $this->router->fetch_method();
      //pagination
      $this->load->library('pagination');
      $this->load->helper('url');
			$this->load->model('system_m');
			$this->load->model('category_m');
			$options = $this->system_m->get_options();
			$this->template->set('page', $method)->set('options', $options)->set_breadcrumb('Home page', base_url('index'));
  }
	public function posts($slug) {
      $config['base_url'] = base_url().'danhmuc/'.$slug;
      $config['total_rows'] = $this->category_m->count_all_post($slug);
      $config['per_page'] = 18;
      $config['uri_segment'] = 3;
      $config['full_tag_open'] = '<ul class="pagination"><li class="page-item">';
      $config['full_tag_close'] = '</li></ul>';
      $config['attributes'] = array('class' => 'page-link');
      $config['first_link'] = 'Trang đầu';
      $config['last_link'] = 'Trang cuối';
      $config['next_link'] = '<i class="fa fa-angle-double-right"></i>';
      $config['prev_link'] = '<i class="fa fa-angle-double-left"></i>';
      $this->pagination->initialize($config);
      $data['post'] = $this->category_m->category_post($config['per_page'],$this->uri->segment(3), $slug);
      $data['info'] = array (
          'title' => $data['post']['cat_name'],
          'description' => $data['post']['cat_description'],
      );
      $this->template->title($data['post']['cat_name'])->build('category', $data);
	}
}
