<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Autopost extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('pagination');
        $this->load->helper('url');
        $this->load->library('session');  //Load the Session
        $this->template->set_theme('backend');
        $this->load->model('autopost_m');
        $this->load->model('post_m');
        $this->load->helper('text');
        date_default_timezone_set('Asia/Saigon');
        if ($this->router->fetch_method() != 'login' && $this->router->fetch_method() != 'register') {
            if (!isset($_SESSION['loggedInUser']) || $_SESSION['loggedInUser']['type'] != 1) {
                redirect('admin/login');
            }
        }
        $method = $this->router->fetch_method();
        $this->template->set('page', $method)->set_breadcrumb('Auto post', base_url('index'));
        //pagination

    }
    public function add_site() {
        $rules = array(
            array (
                'field' => 'url',
                'label' => 'Dường dẫn',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'name_site',
                'label' => 'Tên website',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'class_cat',
                'label' => 'Class trang danh mục',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'class_single',
                'label' => 'Class trang single',
                'rules' => 'trim|required'
            )
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run($this)) {
            $insert = $this->autopost_m->add_site($this->input->post());
            $this->session->set_flashdata("return_add", $insert);
            redirect('admin/add_site');
        } else {
            $data['site_auto_post'] =  $this->autopost_m->site_auto_post();
            $this->template->title('Thêm trang auto post')->build('add-site-auto-post', $data);
        }
    }
    public function auto_post() {
        $rules = array(
            array (
                'field' => 'url',
                'label' => 'Đường dẫn tới trang cần lấy bài viết',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'slug_cat',
                'label' => 'Slug danh mục',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'cat_id',
                'label' => 'Danh mục bài viết',
                'rules' => 'trim|required'
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run($this)) {
            require_once APPPATH . '/libraries/simple_html_dom.php';
            $articles = array();
            $url = $_POST['url'];
            $this->session->set_flashdata("select_url", $url);
            $this->session->set_flashdata("cat_id", $_POST['cat_id']);
            $post['listPost'] = $this->getArticles($url, $_POST['slug_cat']);
            $post['cat_id'] = $_POST['cat_id'];
            $post['urlSite'] = $url;
            $post['listSite'] = $this->autopost_m->get_listSite();
            $post['cat_post'] = $this->get_cat_post();
            $this->template->title('Tư động post bài')->build('auto-post', $post);
        } else {
            $data['cat_post'] = $this->get_cat_post();
            $data['listSite'] = $this->autopost_m->get_listSite();
            $this->template->title('Tư động post bài')->build('auto-post', $data);
        }
    }
    public function get_cat_post() {
        $str = "";
        $cat_product = $this->post_m->get_cat(0);
        foreach ($cat_product as $cat) {
            if(isset($_SESSION['cat_id']) && $_SESSION['cat_id'] == $cat->id){
                $select = 'selected';
            } else {
                $select = '';
            }
            $str .= "<option " . $select . " value='" . $cat->id . "' class='goc'>";
            $str .= $cat->title;
            $str .= "</option>";
            $str .= $this->get_subcat_post($cat->id,$i = 0);

        }
        return $str;
    }
    function get_subcat_post($category_ids,$i = 0) {
        $str = "";
        $sub_categorys  =   $this->post_m->get_subcat($category_ids);
        //kiem tra get subcategory co ton ai hay
        if($sub_categorys) {
            if(!isset($_SESSION['tab_parent'])) {
                $this->session->set_flashdata('tab_parent', 1);
            } else {
                $_SESSION['tab_parent']++;
            }
            foreach ($sub_categorys as $sub_category) {
                if(isset($_SESSION['cat_id']) && $_SESSION['cat_id'] == $sub_category->id) {
                    $select = 'selected';
                } else {
                    $select = '';
                }
                //kiem tra con parent hay ko
                $str .= "<option " . $select . " value='" . $sub_category->id . "' class='".$this->check_parent_menu($sub_category->id)."'>";
                $str .= str_repeat('&nbsp;_', $_SESSION['tab_parent']) . $sub_category->title;
                $str .= "</option>";
                if($sub_category->id) {
                    $str .= $this->get_subcat_post($sub_category->id,$i++);
                }
                $i++;
            }
        }
        return $str;
    }
    public function getArticles($url, $page) {
        $info_site = $this->autopost_m->get_site_auto_post($url);
        $info = array();
        global $articles;
        $html = new simple_html_dom();
        try {
            $html->load_file($url . $page);
            $info = array();
            $getThumbnail = $html->find($info_site['class_cat']);
            foreach($getThumbnail as $key=>$thumbnails) {
                $slug = $this->creatSlug($thumbnails->attr['alt']);
                $checkPost = $this->autopost_m->check_post($slug);
                $data = array(
                    'title' => $thumbnails->attr['alt'],
                    'url' => $thumbnails->parent->attr['href'],
                    'thumbnail' => $thumbnails->attr['src'],
                    'type' => $checkPost,
                );

                $info[] = $data;
            }
            return $info;
        } catch (Exception $exc) {
            return $info;
        }
    }

    public function getContentAutoPost() {
        $rules = array(
            array (
                'field' => 'urlSite',
                'label' => 'Đường dẫn website',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'urlPost',
                'label' => 'Dường dẫn bài viết',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'title',
                'label' => 'Tiêu đề',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'cat_id',
                'label' => 'ID danh mục',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'thumbnail',
                'label' => 'Đường dẫn tới hình ảnh',
                'rules' => 'trim|required'
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run($this)) {
            require_once APPPATH . '/libraries/simple_html_dom.php';
            $info_site = $this->autopost_m->get_site_auto_post($_POST['urlSite']);
            global $articles;
            $checkLink =  explode('://', $_POST['urlPost']);
            if($checkLink[0] == "http" || $checkLink[0] == "https") {
                $html = file_get_html($_POST['urlPost']);
            } else {
                $html = file_get_html($_POST['urlSite'] . '/' . $_POST['urlPost']);
            }
            $noidung = $html->find($info_site['class_single'],0);
            $m = date("m");
            $y = date("Y");
            if(!empty($noidung)) {
              foreach ($noidung->find('a') as $href) {
                  $href->href = '#';
              }
              foreach($noidung->find('img') as $img)
              {
                  if (!file_exists(dirname(BASEPATH) . "/uploads/posts/".$y."/".$m."/")) {
                      mkdir(dirname(BASEPATH) . "/uploads/posts/".$y."/".$m."/", 0777, true);
                  }
                  $checkLink =  explode('://', $img->src);
                  if($checkLink[0] == "http" || $checkLink[0] == "https") {
                      $old_img = $img->src;
                      $link =  explode('/', $img->src);
                      $link = array_pop($link);
                      $img->src = base_url()."uploads/posts/".$y."/".$m."/".$link;
                      $save_path = dirname(BASEPATH) . "/uploads/posts/".$y."/".$m."/";
                      if(is_writable($save_path)) {
                          file_put_contents($save_path .$link,file_get_contents($old_img));
                      }
                  } else {
                      $old_img = $_POST['urlSite'] . '/'.$img->src;
                      $link =  explode('/', $img->src);
                      $link = array_pop($link);
                      $img->src = base_url()."uploads/posts/".$y."/".$m."/".$link;
                      $save_path = dirname(BASEPATH) . "/uploads/posts/".$y."/".$m."/";
                      if(is_writable($save_path)) {
                          file_put_contents($save_path .$link,file_get_contents($old_img));
                      }
                  }
              }
              $html->save();

              if (!file_exists(dirname(BASEPATH) . "/uploads/thumbnail_post/".$y."/".$m."/")) {
                  mkdir(dirname(BASEPATH) . "/uploads/thumbnail_post/".$y."/".$m."/", 0777, true);
              }

              $link =  explode('/', $_POST['thumbnail']);
              $link = array_pop($link);
              $save_path = dirname(BASEPATH) . "/uploads/thumbnail_post/".$y."/".$m."/";
              if(is_writable($save_path)) {
                  file_put_contents($save_path .$link,file_get_contents($_POST['thumbnail']));
              }
              $data = array(
                  'title' => $_POST['title'],
                  'title_seo' => $_POST['title'],
                  'slug' => $this->creatSlug($_POST['title']),
                  'content' => $noidung->outertext,
                  'excerpt' => $_POST['title'],
                  'description' => $_POST['title'],
                  'thumbnail' => $link,
                  'date_post' => date("Y-m-d"),
                  'cat_id' => $_POST['cat_id'],
                  'author_id' => $_SESSION['loggedInUser']['id']
              );
              $insert = $this->autopost_m->insert_auto_post($data);
              if($insert == false) {
                  $dataJson = array(
                      'code' => "002",
                      'message' => 'Article written already exists!'
                  );
              } else {
                  $dataJson = array(
                      'code' => 0,
                      'message' => 'Update post success!'
                  );
              }
            } else {
              $dataJson = array(
                  'code' => "003",
                  'message' => 'Error request link!'
              );
            }
            echo json_encode($dataJson, JSON_UNESCAPED_UNICODE);
        } else {
            $dataJson = array(
                'code' => "001",
                'message' => 'Error auto get content!'
            );
            echo json_encode($dataJson, JSON_UNESCAPED_UNICODE);
        }

    }
    public function get_content($url, $slug) {
        global $articles;
        $html = file_get_html($url);
        $noidung = $html->find('.maincontent',0);
        $m = date("m");
        $y = date("Y");
        foreach($noidung->find('img') as $img)
        {
            $old_img = 'http://www.truyenngan.com.vn/'.$img->src;
            $link =  explode('/', $img->src);
            $link = array_pop($link);
            $img->src =  base_url()."uploads/".$y."/".$m."/".$link;
            $save_path = dirname(BASEPATH) . "/uploads/".$y."/".$m."/";
            if(is_writable($save_path)) {
                file_put_contents($save_path .$link,file_get_contents($old_img));
            } else {
                exit('sdasdsa');
            }
        }
        $html->save();
        return $noidung->outertext;
    }
    public function creatSlug($str) {
        if ((bool) $str == false) {
            exit('');
        }
        $str = mb_strtolower(urldecode($str));
        return url_title(removesign($str), '-');
    }
}
