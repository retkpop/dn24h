<?php require_once 'header.php'; ?>
                <div class="content-wrapper">
                    <!-- Page header -->
                    <div class="page-header">
                        <div class="page-header-content">
                            <div class="page-title">
                                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                            </div>
                        </div>
                        <div class="breadcrumb-line">
                            <ol class="breadcrumb">
                                <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                                <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                            </ol>
                        </div>
                    </div>
                    <!-- /page header -->


                    <!-- Content area -->
                    <div class="content">

                        <div class="row">
                            <div class="col-md-3">
                                <h5>Thêm trang auto post</h5>
                                <hr>
                                <div class="inner">
                                    <?php if(isset($_SESSION['return_add'])): ?>
                                    <div class="flash alert <?php echo ($_SESSION['return_add'] == false)? 'alert-error': 'alert-success' ?> alert-styled-left">
                                        <?php if($_SESSION['return_add'] == false): ?>
                                        <span class="text-semibold">Lỗi! tên trang đã tồn tại</span>
                                        <?php else: ?>
                                        <span class="text-semibold">Tạo trang auto post thành công!</span>
                                        <?php endif; ?>
                                        <div class="heading-elements">
                                            <ul class="icons-list">
                                                <li><a class="close" data-action="close"></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(validation_errors() != false): ?>
                                    <div class="alert alert-danger">
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        <strong>Có lỗi xảy ra!</strong>
                                        <ul>
                                            <?php echo validation_errors('<li>' , '</li>'); ?>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="clearfix"></div>
                                <?php echo form_open() ?>
                                    <div class="form-group">
                                        <label for="name_site">Tên site | Danh mục:</label>
                                        <?php echo form_input('name_site', '', 'class="form-control" id="name_site"') ?>
                                        <div class="help-block">Tên website | danh mục bạn muốn get bài viết</div>
                                    </div>
                                    <div class="form-group">
                                        <label for="url">URL</label>
                                        <?php echo form_input('url', '', 'class="form-control" id="url"') ?>
                                        <div class="help-block">Đường dẫn tới danh mục cần lấy bài viết (<strong>Lưu ý:</strong> Xem video hướng dẫn thêm URL <a>Tại đây</a> để tránh phát sinh lỗi do hệ thống không xác minh được URL)</div>
                                    </div>
                                    <div class="form-group">
                                        <label for="class_item">Class item</label>
                                        <?php echo form_input('class_item', '', 'class="form-control" id="class_item"') ?>
                                        <div class="help-block">Ghi tên class từng item trong list bài viết <small>.main .listpost .item</small></div>
                                    </div>
                                    <div class="form-group">
                                        <label for="class_title">Class title</label>
                                        <?php echo form_input('class_title', '', 'class="form-control" id="class_title"') ?>
                                        <div class="help-block">Ghi tên class title bài viết ở trang danh mục. Ví dụ: <small>.main .listpost .item .title</small></div>
                                    </div>
                                    <div class="form-group">
                                        <label for="class_thumb">Class thumbnail</label>
                                        <?php echo form_input('class_thumb', '', 'class="form-control" id="class_thumb"') ?>
                                        <div class="help-block">Ghi tên class thumbnail bài viết ở trang danh mục. Ví dụ: <small>.main .listpost .item img.thumbnail</small></div>
                                    </div>
                                    <div class="form-group">
                                        <label for="class_link">Class Link</label>
                                          <?php echo form_input('class_link', '', 'class="form-control" id="class_link"') ?>
                                        <div class="help-block">Ghi tên class đường dẫn tới chi tiết bài viết. Ví dụ: <small>.main .listpost .item a</small></div>
                                    </div>
                                    <div class="form-group">
                                        <label for="class_excerpt">Class excerpt single</label>
                                        <?php echo form_input('class_excerpt', '', 'class="form-control" id="class_excerpt"') ?>
                                        <div class="help-block">Ghi tên class description của bài viết nếu có. Ví dụ: <small>.main .excerpt</small></div>
                                    </div>
                                    <div class="form-group">
                                        <label for="class_single">Class content single</label>
                                        <?php echo form_input('class_single', '', 'class="form-control" id="class_single"') ?>
                                        <div class="help-block">Ghi tên class trang chi tiết chung của mỗi bài viết. Ví dụ: <small>.main .content</small></div>
                                    </div>

                                    <button class="btn btn-primary">Thêm site</button>
                                <?php echo form_close() ?>
                            </div>
                            <div class="col-md-9">
                                <h5>Danh sách website auto post</h5>
                                <hr>
                                <div class="panel panel-flat">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Tên website</th>
                                                    <th>URL</th>
                                                    <th class="text-center">Class trang danh mục</th>
                                                    <th class="text-center">Class trang single</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(!empty($site_auto_post)): foreach ($site_auto_post as $value): ?>
                                                <tr id="<?php echo $value['id'] ?>">
                                                    <td>
                                                        <?php echo $value['name_site'] ?>
                                                    </td>
                                                    <td><?php echo $value['url'] ?></td>
                                                    <td><?php echo $value['class_cat'] ?></td>
                                                    <td><?php echo $value['class_single'] ?></td>
                                                    <td>
                                                        <a class="btn btn-xs btn-icon btn-danger" id="remo_menu" idMenu="<?php echo $value['id'] ?>">
                                                            <i class="icon-minus2"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; endif; ?>
                                            </tbody>
                                        </table>
                                        <script>
                                            $("a#remo_menu").click(function(e){
                                                if(!confirm('Xóa menu này?')){
                                                    e.preventDefault();
                                                    return false;
                                                }
                                                var id = $(this).parent().find('a#remo_menu').attr('idMenu');
                                                $.ajax({
                                                    type: "POST",
                                                    url: "<?php echo base_url('admin/delete_site/') ?>",
                                                    cache: false,
                                                    dataType: 'json',
                                                    data: {"id":id},
                                                    success: function(data) {
                                                        if(data == 1) {
                                                            window.location.replace("<?php echo base_url('admin/add_site') ?>");
                                                        }
                                                    }
                                                });
                                            });
                                        </script>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Footer -->
                        <div class="footer text-muted">
                            © 2015. <a href="http://cma.vn/">Cloudcass CMS &amp; eCommerce System</a> by <a href="http://cma.vn/" target="_blank">Tâm Kiều</a>
                            <p>Sản phẩm đã được đăng ký tại Cục sở hữu trí tuệ. Mọi vi phạm bản quyền đều bị xử lý theo pháp luật.</p>
                        </div>
                    </div>
                    <!-- /content area -->
                </div>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
    </body>
</html>
