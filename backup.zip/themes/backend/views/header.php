<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $template['title'] ?></title>
        <link href="<?php echo $this->template->dir(); ?>views/css/bootstrap.css" rel="stylesheet" type="text/css">
        <link href="<?php echo $this->template->dir(); ?>views/css/core.css" rel="stylesheet" type="text/css">
        <link href="<?php echo $this->template->dir(); ?>views/css/components.css" rel="stylesheet" type="text/css">
        <link href="<?php echo $this->template->dir(); ?>views/css/colors.css" rel="stylesheet" type="text/css">
        <link href="<?php echo $this->template->dir(); ?>views/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo $this->template->dir(); ?>views/css/custom.css" rel="stylesheet" type="text/css">
        <link href="<?php echo $this->template->dir(); ?>views/css/fileinput.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo $this->template->dir(); ?>views/styles.css" rel="stylesheet" type="text/css">
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/pace.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/bootstrap.min.js"></script>
        <script src="<?php echo $this->template->dir(); ?>views/js/bootstrap-filestyle.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/blockui.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/uniform.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/form_checkboxes_radios.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/bootstrap_select.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/components_popups.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/address.js"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/select2.min.js"></script>
        <script src="//code.jquery.com/ui/1.10.4/jquery-ui.min.js"></script>
        <script src="<?php echo $this->template->dir(); ?>views/js/jquery.mjs.nestedSortable.js" type="text/javascript"></script>
        <script src="<?php echo $this->template->dir(); ?>asset/ckeditors/ckeditor.js" type="text/javascript"></script>
        <script src="<?php echo $this->template->dir(); ?>views/js/fileinput.min.js" type="text/javascript"></script>
        <script src="<?php echo $this->template->dir(); ?>views/plugin/tags/tokenfield.min.js" type="text/javascript"></script>
        <script src="<?php echo $this->template->dir(); ?>views/plugin/tags/tagsinput.min.js" type="text/javascript"></script>
        <script src="<?php echo $this->template->dir(); ?>views/plugin/pickers/anytime.min.js" type="text/javascript"></script>
        <script src="<?php echo $this->template->dir(); ?>views/plugin/all/pnotify.min.js" type="text/javascript"></script>
        <script src="<?php echo $this->template->dir(); ?>views/plugin/all/bootstrap_multiselect.js" type="text/javascript"></script>
        <script type="text/javascript" src="<?php echo $this->template->dir(); ?>views/js/app.js"></script>

    </head>
    <body class="pace-done">
        <div class="pace  pace-inactive"><div class="pace-progress" data-progress-text="100%" data-progress="99" style="transform: translate3d(100%, 0px, 0px);">
                <div class="pace-progress-inner"></div>
            </div>
            <div class="pace-activity"></div></div>

        <!-- Main navbar -->
        <div class="navbar navbar-inverse">
            <div class="navbar-header">
                <a class="navbar-brand" href="<?php echo base_url() ?>" target="_blank"><img src="<?php echo $this->template->dir(); ?>views/images/logo_light.png" alt=""></a>

                <ul class="nav navbar-nav visible-xs-block">
                    <li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
                    <li><a class="sidebar-mobile-main-toggle"><i class="icon-paragraph-justify3"></i></a></li>
                </ul>
            </div>
            <div class="navbar-collapse collapse" id="navbar-mobile">
                <ul class="nav navbar-nav">
                    <li><a class="sidebar-control sidebar-main-toggle hidden-xs"><i class="icon-paragraph-justify3"></i></a></li>
                </ul>
                <p class="navbar-text"><span class="label bg-success-400">Online</span></p>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown dropdown-user">
                        <a class="dropdown-toggle" data-toggle="dropdown">
                            <img src="<?php echo $this->template->dir(); ?>views/images/face11.jpg" alt=""> <span><?php echo $_SESSION['loggedInUser']['fullname'] ?></span>
                            <i class="caret"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-right">
                            <li><a href=""><i class="icon-user-plus"></i> Tài khoản của tôi</a></li>
                            <li><a href=""><i class="icon-switch2"></i> Thoát</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div><!-- /main navbar -->
        <!-- Page container -->
        <div class="page-container" style="min-height:899px">
            <!-- Page content -->
            <div class="page-content">
                <div class="sidebar sidebar-main">
                    <div class="sidebar-content">
                        <!-- Main navigation -->
                        <div class="sidebar-category sidebar-category-visible">
                            <div class="category-content no-padding">
                                <ul class="navigation navigation-main navigation-accordion">
                                    <!-- Main -->
                                    <li class="navigation-header"><span>Nội dung</span> <i class="icon-menu" title="" data-original-title="Main pages"></i></li>
                                    <li <?php echo ($page == 'list_posts' || $page == 'new_post' || $page == 'categories' || $page == 'post_edit')? 'class="active"' : '' ?>>
                                        <a href="" class="has-ul"><i class="icon-copy"></i> <span>Bài viết</span></a>
                                        <ul>
                                            <li <?php echo ($page == 'list_posts')? 'class="active"' : '' ?>><a href="<?php echo base_url('admin/list_posts') ?>">Tất cả bài viết</a></li>
                                            <li <?php echo ($page == 'new_post')? 'class="active"' : '' ?>><a href="<?php echo base_url('admin/new_post') ?>">Thêm bài mới</a></li>
                                            <li <?php echo ($page == 'categories')? 'class="active"' : '' ?>><a href="<?php echo base_url('admin/post-categories.html') ?>">Danh mục</a></li>
                                        </ul>
                                    </li>
                                    <li <?php echo ($page == 'auto_post' || $page == 'add_site' )? 'class="active"' : '' ?>>
                                        <a href="" class="has-ul"><i class="icon-copy"></i> <span>Auto post</span></a>
                                        <ul>
                                            <li <?php echo ($page == 'auto_post')? 'class="active"' : '' ?>><a href="<?php echo base_url('admin/auto_post') ?>">Auto post</a></li>
                                            <li <?php echo ($page == 'add_site')? 'class="active"' : '' ?>><a href="<?php echo base_url('admin/add_site') ?>">Add site</a></li>
                                        </ul>
                                    </li>
                                    <li <?php echo ($page == 'list_page' || $page == 'new_page' || $page == 'page_edit')? 'class="active"' : '' ?>>
                                        <a href="" class="has-ul"><i class="icon-copy"></i> <span>Trang</span></a>
                                        <ul>
                                            <li <?php echo ($page == 'list_page')? 'class="active"' : '' ?>><a href="<?php echo base_url('admin/list_page') ?>">Tất cả trang</a></li>
                                            <li <?php echo ($page == 'add_page')? 'class="active"' : '' ?>><a href="<?php echo base_url('admin/new_page') ?>">Thêm trang mới</a></li>
                                        </ul>
                                    </li>
                                    <li <?php echo ($page == 'list_discuss' || $page == 'community_post' || $page == 'add_community' || $page == 'edit_community')? 'class="active"' : '' ?>>
                                        <a href="" class="has-ul"><i class="icon-copy"></i> <span>Cộng đồng</span></a>
                                        <ul>
                                            <li <?php echo ($page == 'list_discuss')? 'class="active"' : '' ?>><a href="<?php echo base_url('admin/communities') ?>">Bài viết cộng đồng</a></li>
                                            <li <?php echo ($page == 'add_community')? 'class="active"' : '' ?>><a href="<?php echo base_url('admin/community/add') ?>">Thêm cộng đồng mới</a></li>
                                        </ul>
                                    </li>
                                    <!-- Giao diện -->
                                    <li class="navigation-header"><span>Giao diện</span> <i class="icon-menu" title="" data-original-title="Giao diện"></i></li>
                                    <li <?php echo ($page == 'list_menu' || $page == 'addmenu')? 'class="active"' : '' ?>>
                                        <a href="<?php echo base_url('admin/list_menu') ?>"><i class="icon-paragraph-justify3"></i>
                                            <span>Trình đơn</span>
                                        </a>
                                    </li>
                                    <li <?php echo ($page == 'ads_detail' || $page == 'ads')? 'class="active"' : '' ?>>
                                        <a href="<?php echo base_url('admin/ads') ?>"><i class="icon-bookmark"></i>
                                            <span>Quản lý tùy chọn</span>
                                        </a>
                                    </li>
                                    <!-- End Giao diện -->
                                    <li class="navigation-header"><span>Thống kê</span> <i class="icon-menu" title="" data-original-title="Gallery"></i></li>
                                    <li <?php echo ($page == 'users')? 'class="active"' : '' ?>>
                                        <a href="<?php echo base_url('admin/users') ?>"><i class="icon-user"></i>
                                            <span>Thành viên</span>
                                        </a>
                                    </li>
                                    <li <?php echo ($page == 'subscribe')? 'class="active"' : '' ?>>
                                        <a href="<?php echo base_url('admin/subscribe') ?>"><i class="icon-user"></i>
                                            <span>Subscribe</span>
                                        </a>
                                    </li>
                                    <li <?php echo ($page == 'comments')? 'class="active"' : '' ?>>
                                        <a href="<?php echo base_url('admin/comments') ?>"><i class="icon-bubbles2"></i>
                                            <span>Comments</span>
                                        </a>
                                    </li>
                                    <!-- Forms -->
                                    <li class="navigation-header"><span>Công cụ</span> <i class="icon-menu" title="" data-original-title="Forms"></i></li>
                                    <li <?php echo ($page == 'setting')? 'class="active"' : '' ?>>
                                        <a href="<?php echo base_url('admin/setting') ?>"><i class="icon-setting"></i>
                                            <span>Cài đặt</span>
                                        </a>
                                    </li>
                                    <!-- /forms -->
                                    <li <?php echo ($page == 'list_email' || $page == 'send_email' || $page == 'email_edit')? 'class="active"' : '' ?>>
                                        <a href="<?php echo base_url('admin/list-email.html') ?>" class="has-ul"><i class="icon-file-text2"></i> <span>Email</span></a>
                                        <ul>
                                            <li <?php echo ($page == 'list_email')? 'class="active"' : '' ?>><a href="<?php echo base_url('admin/list-email.html') ?>">Tất cả email</a></li>
                                            <li <?php echo ($page == 'send_email')? 'class="active"' : '' ?>><a href="<?php echo base_url('admin/send_email') ?>">Thêm email mới</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- /main navigation -->
                    </div>
                </div><!-- /main sidebar -->
