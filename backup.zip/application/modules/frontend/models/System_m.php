<?php

Class System_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function get_options() {
        $options = $this->db->get('options');
        $row = $options->num_rows();
        foreach ($options->result_array() as $key => $value) {
            $data[] = array(
                $value['option_name'] => $value['option_value']
            );
        }
        $option = $data[0];
        for($i=0; $i<$row-1; $i++) {
            $option = array_merge($option, $data[$i+1]);
        }
        return $option;
    }
    public function get_all_provinces() {
      $provinces = $this->db->order_by('id', 'asc')->get('provinces');
      if($provinces->num_rows()>0) {
        return $provinces->result_array();
      }
      return false;
    }
}
?>
