<?php

Class Community_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function insert_community($input) {
      $query = $this->db->where('slug', $input['slug'])->get('communities');
      if($query->num_rows()>0) {
          $query = $query->row_array();
          $this->session->set_flashdata('return_add', 0);
          return false;
      } else {
          $this->db->insert('communities', $input);
          $this->session->set_flashdata('return_add', 1);
      }
    }
    public function count_all_discuss(){
      return $this->db->count_all('community_posts');
    }
    public function delete_discuss($id) {
      $this->db->where('id', $id)->delete('community_posts');
    }
    public function edit_community($input, $id) {
      $communities = $this->db->get('communities');
      if($communities->num_rows()>0) {
        foreach ($communities->result_array() as $value) {
          if(($value['slug'] == $input['slug']) && $value['id'] != $id) {
            $this->session->set_flashdata('return_add', 0);
            redirect('admin/community/edit?id=' . $id);
          } else {
            $this->db->where('id', $id)->update('communities',$input);
            $this->session->set_flashdata('return_add', 1);
          }
        }
      }
    }
    public function delete_community($id) {
      $this->db->where('id', $id)->delete('communities');
      if($this->db->affected_rows()) {
        $this->db->where('community_id', $id)->delete('community_posts');
      }
    }
    public function get_community_by_id($id) {
      $community = $this->db->where('id', $id)->get('communities');
      if($community->num_rows()>0) {
        return $community->row_array();
      }
      return false;
    }
    public function all_discussion($number, $offset){
      $communities = $this->db->order_by('id', 'desc')->get('community_posts',$number,$offset);
      if($communities->num_rows() > 0) {
          foreach ($communities->result_array() as $community) {
            $community['author'] = $this->db->where('id', $community['author_id'])->get('users')->row_array();
            $community['cat'] = $this->db->where('id', $community['community_id'])->get('communities')->row_array();
            $community['url'] = base_url('thao-luan/post-'.$community['id']);
            $community['content'] = character_limiter($this->stripHTMLtags($community['content']), 200);
            $author = $this->db->where('id', $community['author_id'])->get('users')->row_array();
            $author['fullname'] = $author['last_name'] . ' ' . $author['first_name'];
            $author['avatar'] = (!empty($author['avatar']))? base_url('uploads/avatar/'. $author['avatar']) : $this->template->dir() .'views/images/no-avatar.png';
            unset($author['password']);
            $community['author'] = $author;
            $cd = $this->db->where('id', $community['community_id'])->get('communities');
            if($cd->num_rows()>0) {
              $cd = $cd->row_array();
              $community['cat'] = $cd;
            }
            $datas[] = $community;
          }
          return $datas;
      } else {
          return false;
      }
    }
    public function communities(){
      $communities = $this->db->get('communities');
      if($communities->num_rows()>0) {
        foreach ($communities->result_array() as  $community) {
          $community['thumbnail'] = (!empty($community['thumbnail']))? base_url() .'uploads/community/thumbnail_community/' . $community['thumbnail'] : $this->template->dir() . 'views/images/no-thumbnail.jpg';
          $datas[] = $community;
        }
        return $datas;
      }
      return false;
    }
    private function stripHTMLtags($str) {
        $t = preg_replace('/<[^<|>]+?>/', '', htmlspecialchars_decode($str));
        $t = htmlentities($t, ENT_QUOTES, "UTF-8");
        return $t;
    }
}
?>
