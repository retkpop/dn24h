<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User extends CI_Controller {
	public function __construct() {
      parent::__construct();
      $this->load->library('session');  //Load the Session
      $this->load->library('user_agent');
      $this->template->set_theme('frontend');
      date_default_timezone_set('Asia/Saigon');
      $method = $this->router->fetch_method();
      //pagination
      $this->load->library('pagination');
      $this->load->helper('url');
			$this->load->model('system_m');
			$this->load->model('user_m');
			$this->load->model('community_m');
			$options = $this->system_m->get_options();
			$this->template->set('page', $method)->set('options', $options)->set_breadcrumb('Home page', base_url('index'));
  }
	public function profile_user($username) {
		$data['user'] = $this->user_m->get_user_by_username($username);
		$data['communities'] = $this->community_m->list_community();
		$config = $this->tk_system->pagination(15, 'user/'.$username);
		$config['total_rows'] = $this->community_m->count_discuss_by_id_user($data['user']['id']);
		$config['uri_segment'] = 3;
		$this->pagination->initialize($config);
		$data['discussions'] = $this->community_m->get_discuss_by_id_user($data['user']['id'], $config['per_page'], $this->uri->segment(3));
		$data['new_posts'] = $this->community_m->post_qt(5);
		if($data['user'] != false) {
			$data['info'] = array (
					'title' => 'User',
					'description' => 'User',
			);
			$this->template->title('User profile')->build('profile', $data);
		} else {
			$this->load->view('404');
		}
	}
	public function change_avatar($username){
		print_r($_FILES['avatar']['name']);
		if (!empty($_FILES['avatar']['name'])) {
			$this->form_validation->set_rules('product_image','Product Image','callback_validate_image');
	    if($this->form_validation->run()==FALSE){
				$old_avatar = (!empty($this->input->post('old_avatar')))? $this->input->post('old_avatar') : false;
	      $_POST['avatar'] = $this->tk_system->file_edit('avatar', 'avatar', $old_avatar);
				unset($_POST['old_avatar']);
				$this->user_m->edit_user_by_username($this->input->post(), $username);
				redirect(base_url('user/'.$username.'/profile'));
			} else {
				exit('Định dạng file không được phép.');
			}
    }
	}
	public function validate_image() {
    $config = array(
      'allowed_types'=>'jpg|png|jpge|gif',
      'max_size'=>1
    );
    $this->load->library('upload', $config);
    if (!$this->upload->do_upload('product_image')) {
      $this->form_validation->set_message('validate_image',$this->upload->display_errors());
      return false;
    } else {
      return true;
    }
  }
	public function edit_profile($username) {
		if (!isset($_SESSION['loggedInUser']) || $_SESSION['loggedInUser']['username'] != $username) {
        redirect(base_url('user/'.$username));
    }
		$rules = array(
      array(
          'field' => 'last_name',
          'label' => 'Họ',
          'rules' => 'trim|required|min_length[3]|max_length[100]'
      ),
			array(
          'field' => 'first_name',
          'label' => 'Tên đệm và tên',
          'rules' => 'trim|required|min_length[3]|max_length[100]'
      ),
      array(
          'field' => 'address',
          'label' => 'Địa chỉ',
          'rules' => 'trim'
      ),
			array(
          'field' => 'living_place',
          'label' => 'Địa chỉ đang sống',
          'rules' => 'trim|numeric|is_natural'
      ),
      array(
          'field' => 'phone',
          'label' => 'Số điện thoại',
          'rules' => 'trim|min_length[9]|max_length[15]|numeric|is_natural'
      ),
      array(
          'field' => 'facebook',
          'label' => 'Link Facebook',
          'rules' => 'trim'
      ),
			array(
					'field' => 'password',
					'label' => 'Mật khẩu mới',
					'rules' => 'trim|min_length[6]|md5'
			),
			array(
					'field' => 'passcf',
					'label' => 'Nhập lại mật khẩu mới',
					'rules' => 'trim|md5|matches[password]'
			),
	  );
	  $this->form_validation->set_rules($rules);
	  if ($this->form_validation->run($this)) {
			if(!empty($_POST['email'])) {
				unset($_POST['email']);
			}
			if(!empty($_POST['username'])) {
				unset($_POST['username']);
			}
			if(empty($_POST['password'])) {
				unset($_POST['password']);
        unset($_POST['passcf']);
      } else {
				unset($_POST['passcf']);
			}
			$this->user_m->edit_user_by_username($this->input->post(), $username);
			redirect(base_url('user/'.$username.'/profile'));
		} else {
			$data['communities'] = $this->community_m->list_community();
			$data['user'] = $this->user_m->get_user_by_username($username);
			$data['provinces'] = $this->system_m->get_all_provinces();
			$data['discussions'] = $this->community_m->get_discuss_by_id_user($data['user']['id'], 0,20);
			$data['new_posts'] = $this->community_m->post_qt(5);
			if($data['user'] != false) {
				$data['info'] = array (
						'title' => 'User',
						'description' => 'User',
				);
				$this->template->title('Edit profile')->build('edit-profile', $data);
			} else {
				$this->load->view('404');
			}
		}
	}
	public function register() {
      $rules = array(
          array(
              'field' => 'last_name',
              'label' => 'Họ',
              'rules' => 'trim|required|max_length[50]'
          ),
          array(
              'field' => 'first_name',
              'label' => 'Tên đệm và tên',
              'rules' => 'trim|required|max_length[50]'
          ),
          array(
              'field' => 'username',
              'label' => 'Tên đăng nhập',
              'rules' => 'trim|required|alpha_dash|max_length[50]'
          ),
          array(
              'field' => 'email',
              'label' => 'Email',
              'rules' => 'trim|required|valid_email|max_length[50]'
          ),
          array(
              'field' => 'phone',
              'label' => 'Số điện thoại',
              'rules' => 'trim|min_length[9]|max_length[15]|numeric|is_natural'
          ),
          array(
              'field' => 'password',
              'label' => 'Mật khẩu',
              'rules' => 'trim|required|min_length[6]|md5'
          ),
          array(
              'field' => 'passcf',
              'label' => 'Nhập lại mật khẩu',
              'rules' => 'trim|required|md5|matches[password]'
          ),
      );
      $this->form_validation->set_rules($rules);
      if ($this->form_validation->run($this)) {
        unset($_POST['passcf']);
        $data = $this->user_m->register($this->input->post());
      } else {
        $data = array(
          'code' => 1003,
          'message' => validation_errors('<p>' , '</p>')
        );
      }
      $json = json_encode($data, JSON_UNESCAPED_UNICODE);
      echo $json;
	}
	public function logout(){
		$this->session->unset_userdata('loggedInUser');
		if(!empty($this->input->get('url_redirect'))) {
			redirect($this->input->get('url_redirect'));
		}
		redirect('');
	}
	public function login(){
		$rules = array(
	      array(
	          'field' => 'username',
	          'label' => 'Email hoặc Username',
	          'rules' => 'trim|required|max_length[200]'
	      ),
	      array(
	          'field' => 'password',
	          'label' => 'Mật khẩu',
	          'rules' => 'trim|required|md5'
	      )
	  );
	  $this->form_validation->set_rules($rules);
	  if ($this->form_validation->run($this)) {
	      $login = $this->user_m->login($this->input->post());
	      if($login != false) {
	          $this->session->set_userdata('loggedInUser', $login);
	          $data = array(
							'code' => 200,
							'message' => 'Đăng nhập thành công'
						);
	      } else {
						$data = array(
							'code' => 1001,
							'message' => 'Email, Username hoặc mật khẩu không đúng'
						);
	      }
	  } else {
			$data = array(
				'code' => 1003,
				'message' => validation_errors('<p>' , '</p>')
			);
	  }
		$json = json_encode($data, JSON_UNESCAPED_UNICODE);
		echo $json;
	}
}
