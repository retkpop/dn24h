<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Ads extends CI_Controller {
		public function __construct() {
	      parent::__construct();
				if ($this->router->fetch_method() != 'login' && $this->router->fetch_method() != 'register') {
            if (!isset($_SESSION['loggedInUser']) || $_SESSION['loggedInUser']['type'] != 1) {
                redirect('admin/login');
            }
        }
	      $this->load->library('session');  //Load the Session
	      $this->template->set_theme('backend');
	      date_default_timezone_set('Asia/Saigon');
	      $method = $this->router->fetch_method();
	      $this->template->set('page', $method)->set_breadcrumb('Ads', base_url('index'));
	      //pagination
				$this->load->helper('url');
	      $this->load->helper('text');
				$this->load->model('ads_m');
	  }
    public function ads() {
        $rules = array(
            array (
                'field' => 'name',
                'label' => 'Tên trình đơn',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'slug',
                'label' => 'Slug',
                'rules' => 'trim|required'
            )
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run($this)) {
            $this->ads_m->add_ads($this->input->post());
            redirect('admin/ads');
        } else {
            $data['ads'] = $this->ads_m->all_ads();
            $this->template->title('List ADS')->build('ads', $data);
        }
    }

    public function delete_ads() {
        if(!empty($_POST)) {
            if ($this->input->is_ajax_request()) {
                $this->ads_m->delete_ads($this->input->post('id'));
                echo 1;
            }
        } else {
            redirect('admin');
        }
    }

    public function ads_detail() {
        if(empty($_GET['id'])) {
            redirect('admin/ads');
        } else {
            $rules = array(
                array (
                    'field' => 'title',
                    'label' => 'Tiêu đề hình ảnh',
                    'rules' => 'trim|required'
                ),
                array (
                    'field' => 'link',
                    'label' => 'Đường dẫn tới bài viết',
                    'rules' => 'trim'
                ),
            );
            $this->form_validation->set_rules($rules);
            if($this->form_validation->run($this)) {
                $img = $this->file_upload('ads', 'media_ads');
                $_POST['img'] = base_url('uploads/ads/'. $img);
                $_POST['ads_id'] = $_GET['id'];
                $this->ads_m->add_ads_detail($this->input->post());
                redirect('admin/ads_detail?id=' . $_GET['id']);
            } else {
                $data['ads_detail'] = $this->ads_m->get_ads_detail($_GET['id']);
                $this->template->title('ADS Detail')->build('ads-detail', $data);
            }
        }
    }
    public function bulk_action_ads() {
        if(!empty($_POST['bulk_action_ads'])) {
            if(isset($_POST['id'])) {
                if($_POST['bulk_action_ads'] == 'delete') {
                    foreach ($_POST['id'] as $value) {
                        $this->ads_m->delete_ads_detail($value, $_POST['ads_id']);
                    }
                    redirect('admin/ads_detail?id=' . $_POST['ads_id']);
                }
            }
            if($_POST['bulk_action_ads'] == 'update_arrange') {
                foreach ($_POST['arrange'] as $key => $value) {
                    $data = array(
                        'id' => $key,
                        'arrange' => $value
                    );
                    $this->ads_m->update_arrange_ads($data, $_POST['ads_id']);
                }
                redirect('admin/ads_detail?id=' . $_POST['ads_id']);
            }
        } else {
            redirect('admin/ads_detail?id=' . $_POST['ads_id']);
        }
    }
    public function update_arrange_ads() {
        if(!empty($_GET['id']) && !empty($_POST['id'])) {
            if ($this->input->is_ajax_request()) {
                $this->ads_m->update_arrange_ads($this->input->post(), $_GET['id']);
                echo $_GET['id'];
            }
        }
    }
    public function file_upload($name_sl, $name_file) {
				if (!is_dir('uploads/'. $name_sl .'/')) {
						mkdir('uploads/'. $name_sl .'', 0777, true);
				}
				$path = dirname(BASEPATH) . '/uploads/'. $name_sl .'/';
        $tmp_name = $_FILES[$name_file]['tmp_name'];
        $name = $_FILES[$name_file]['name'];
        $array = explode('.', $name);
        $n = count($array);
        $name_file = md5(microtime() . rand(1, 1000));
        if($_FILES[$name_file]['error']==0){
            $new_name = $name_file . '.' . $array[$n - 1];
            move_uploaded_file($tmp_name, $path . $new_name);
            return $new_name;
        } else {
            $new_name = '';
            return $new_name;
        }
    }
}
?>
