<?php

Class Post_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function insert_post($input) {
        $query = $this->db->where('slug', $input['slug'])->get('posts');
        if($query->num_rows()>0) {
            $input['slug'] = $input['slug'] . '-1';
        }
        if($input['tags']) {
            $tags = explode(',', $input['tags']);
        }
        unset($input['tags']);
        //Chèn post
        $this->db->insert('posts', $input);
        $post_id = $this->db->insert_id();
        //Nếu chèn thành công sẽ có id của post
        if($post_id > 0) {
            if(isset($tags)) {
                $this->update_tags($tags, $post_id, 0);
            }
            return $post_id;
        }
        return false;
    }
    public function delete_post($id) {
        $query = $this->db->where('id', $id)->get('posts');
        if($query->num_rows()>0) {
            $query = $query->row_array();
            $date = date_create($query['date_post']);
            $name_sl = date_format($date,"Y/m");
            $thumbnail = $query['thumbnail'];
        }
        $this->db->where('id', $id)->delete('posts');
        if($this->db->affected_rows()) {
            if(!empty($thumbnail)) {
                $thumb_old = dirname(BASEPATH) . '/uploads/thumbnail_post/' . $name_sl .'/'. $thumbnail;
                unlink($thumb_old);
            }
            $this->db->where('post_id', $id)->where('type', 0)->delete('relationships');
        } else {
            return false;
        }
    }
    public function fillter_post($keyword) {
        $productsQ = $this->db->order_by('id', 'desc')->like('title',$keyword)->get('posts');
        if($productsQ->num_rows()>0) {
            $products = array();
            foreach ($productsQ->result_array() as $value) {
                $author = $this->db->where('id', $value['author_id'])->get('users')->row_array();
                $author['fullname'] = $author['last_name'] . ' ' . $author['first_name'];
                unset($author['password']);
                $value['author_id'] = $author;
                $cat = $this->db->where('id', $value['cat_id'])->get('categories_post')->row_array();
                $value['cat'] = $cat;

                $date = date_create($value['date_post']);
                $name_sl = date_format($date,"Y/m");
                $value['date_post'] = date_format($date,"d/m/Y");
                if(!empty($value['thumbnail'])) {
                    $value['thumbnail'] = base_url() .'uploads/thumbnail_post/' . $name_sl . '/' . $value['thumbnail'];
                } else {
                    $value['thumbnail'] = $this->template->dir() . 'views/images/no-thumbnail.jpg';
                }
                $value['url'] = base_url($value['slug']. '-' . $value['id'] . '.html');
                $products[] = $value;
            }
            return $products;
        } else {
            return false;
        }
    }
    public function post_edit($input, $id) {
        $query = $this->db->where('slug', $input['slug'])->get('posts');
        if($query->num_rows()> 0) {
            foreach ($query->result_array() as $value) {
                if($value['id'] != $id) {
                    $input['slug'] = $input['slug'] . '-1';
                }
            }
        }
        if($input['tags']) {
            $tags = explode(',', $input['tags']);
        }
        unset($input['tags']);
        $update = $this->db->where('id', $id)->update('posts', $input);
        if($this->db->affected_rows() >= 0) {
            if(isset($tags)) {
                $this->update_tags($tags, $id, 0);
            }
            return true;
        } else {
            return false;
        }
    }
    public function post($id) {
        $query = $this->db->where('id', $id)->get('posts');
        if($query->num_rows()>0) {
            $query = $query->row_array();
            $date = date_create($query['date_post']);
            $name_sl = date_format($date,"Y/m");
            $query['thumbnail_url'] = base_url() .'uploads/thumbnail_post/' . $name_sl . '/' . $query['thumbnail'];
            $query['cat_id'] = $this->db->where('id', $query['cat_id'])->get('categories_post')->row_array();
            $queryTag = $this->db->select('*')->from('tags')->join('relationships', 'tags.id = relationships.tag_id')
                ->where('relationships.post_id', $id)
                ->where('relationships.type', 0)->get();
            if($queryTag->num_rows()>0) {
                foreach ($queryTag->result_array() as $value) {
                    $data[] = trim($value['title']);
                }
                $query['tag'] = implode(',',$data);
                $query['fulltags'] = $queryTag->result_array();
            }
            return $query;
        } else {
          return false;
        }
    }
    public function list_posts($number, $offset) {
        $query = $this->db->order_by('id', 'desc')->get('posts',$number,$offset);
        if($query->num_rows()>0) {
            $posts = array();
            foreach ($query->result_array() as $value) {
                $author = $this->db->where('id', $value['author_id'])->get('users')->row_array();
                $author['fullname'] = $author['last_name'] . ' ' . $author['first_name'];
                unset($author['password']);
                $value['author_id'] = $author;
                $cat = $this->db->where('id', $value['cat_id'])->get('categories_post')->row_array();
                $value['cat'] = $cat;

                $date = date_create($value['date_post']);
                $name_sl = date_format($date,"Y/m");
                $value['date_post'] = date_format($date,"d/m/Y");
                if(!empty($value['thumbnail'])) {
                    $value['thumbnail'] = base_url() .'uploads/thumbnail_post/' . $name_sl . '/' . $value['thumbnail'];
                } else {
                    $value['thumbnail'] = $this->template->dir() . 'views/images/no-thumbnail.jpg';
                }
                $value['url'] = base_url() . $value['slug'] . '-' . $value['id'] . '.html';
                $posts[] = $value;
            }
            return $posts;
        } else {
            return false;
        }
    }
    public function count_all_posts(){
        return $this->db->count_all('posts');
    }
    public function update_tags($tags, $post_id, $type = 1) {
        $insertTags = array();
        foreach ($tags as $item) {
            $insertTags[] = array(
                'title'  => $item,
                'slug'  => create_slug($item)
            );
        }
        //Chèn vào table tags
        $checkTag = $this->db->where('post_id', $post_id)->where('type', $type)->get('relationships');
        if($checkTag->num_rows()>0) {
            foreach ($checkTag->result_array() as $item) {
                $tagfind = $this->db->where('id', $item['tag_id'])->get('tags');
                if($tagfind->num_rows() > 0) {
                    $tagfind = $tagfind->row_array();
                    foreach ($insertTags as $insertTag) {
                        if($insertTag['slug'] != $tagfind['slug']) {
                            $this->db->where('post_id', $post_id)->where('tag_id', $tagfind['id'])->delete('relationships');
                        }
                    }
                }
            }
        }
        foreach ($insertTags as $tagArray) {
            $tagQuery = $this->db->where('slug', $tagArray['slug'])->get('tags');
            if($tagQuery->num_rows() == 0){
                $this->db->insert('tags', $tagArray);
                $tag_id = $this->db->insert_id();
            } else{
                $tag_id = $tagQuery->row()->id;
            }
            //Tạo record quan hệ
            $relationArray = array(
                'post_id'   => $post_id,
                'tag_id'   => $tag_id,
                'type'      => $type //type 1 là production. type 0 là posts
            );
            $check = $this->db->where('tag_id', $tag_id)->where('post_id', $post_id)->get('relationships');
            if($check->num_rows() == 0) {
                $this->db->insert('relationships', $relationArray);
            }
        }
    }
    public function get_cat($parent = 0) {
        $query = $this->db->where('parent', $parent)->get('categories_post');
        if($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    function get_subcat($parent) {
        $query = $this->db->where('parent', $parent)->get('categories_post');
        if($query->num_rows()>0) {
            return $query->result();
        } else {
            return false;
        }
    }
    public function insert_cat($input) {
        $query = $this->db->where('slug', $input['slug'])->get('categories_post');
        if($query->num_rows()>0) {
            $query = $query->row_array();
            $this->session->set_flashdata('return_add', 0);
            return false;
        } else {
            $this->db->insert('categories_post', $input);
            $this->session->set_flashdata('return_add', 1);
        }
    }
    public function get_category_edit($id) {
        $query = $this->db->where('id', $id)->get('categories_post');
        if($query->num_rows()>0) {
            return $query->row_array();
        } else {
            return false;
        }
    }
    public function edit_cat($input, $id) {
        $query = $this->db->get('categories_post');
        if($query->num_rows()>0) {
            foreach ($query->result_array() as $value) {
                if(($value['slug'] == $input['slug']) && $value['id'] != $id) {
                    $this->session->set_flashdata('return_add', 0);
                    redirect('admin/edit_cat?id=' . $id);
                } else {
                    $this->db->where('id', $id)->update('categories_post',$input);
                    $this->session->set_flashdata('return_add', 1);
                }
            }
        }
    }
}
