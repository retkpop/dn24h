<?php require_once 'header.php'; ?>

            <!-- Main content -->
            <div class="content-wrapper">
                <!-- Page header -->
                <div class="page-header">
                    <div class="page-header-content">
                        <div class="page-title">
                            <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                        </div>
                    </div>
                    <div class="breadcrumb-line">
                        <ol class="breadcrumb">
                            <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                            <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                        </ol>
                    </div>
                </div>
                <!-- /page header -->
                <!-- Content area -->
                <div class="content">
                    <?php echo form_open(); ?>
                        <div class="row blogs-form">
                            <div class="col-md-9">
                                <div class="panel panel-flat">
                                    <div class="panel-body">
                                        <?php if(validation_errors() != false): ?>
                                        <div class="alert alert-danger">
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <strong>Có lỗi xảy ra!</strong>
                                            <ul>
                                                <?php echo validation_errors('<li>' , '</li>'); ?>
                                            </ul>
                                        </div>
                                        <?php endif; ?>
                                        <div class="form-post">
                                            <div class="tab-pane active" id="general">
                                                <!-- Tiêu đề Start -->
                                                <div class="form-group">
                                                    <label for="title">Tiêu đề email</label>
                                                    <?php if(isset($_SESSION['post']['title'])): $title = $_SESSION['post']['title']; else: $title = $get_email['title']; endif; ?>
                                                    <?php echo form_input('title', $title, 'class="form-control post-title" id="postTitle" placeholder="Tiêu đề email"') ?>
                                                </div>
                                                <!-- Tiêu đề END -->
                                                <div class="row">
                                                    <div class="col-sm-3">
                                                        <div class="form-group">
                                                            <label for="select_type">Danh sách</label>
                                                            <select id="select_type" name="select_type" class="form-control select2">
                                                                <option value="">-- Lựa chọn danh sách gửi --</option>
                                                                <option value="0" <?php echo ($get_email['select_type']== 0)? 'selected' : '' ?>>Tất cả khách hàng</option>
                                                                <option value="1" <?php echo ($get_email['select_type']== 1)? 'selected' : '' ?>>KH đã mua SP</option>
                                                                <option value="2" <?php echo ($get_email['select_type']== 2)? 'selected' : '' ?>>Thành viên</option>
                                                                <option value="3" <?php echo ($get_email['select_type']== 3)? 'selected' : '' ?>>Tùy chọn</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-9">
                                                        <div class="form-group custom-email" <?php echo ($get_email['select_type']== 3)? 'style="display:block"' : '' ?>>
                                                            <label for="list_email">Email nhận (<small>Mỗi email cách nhau bằng dấu phẩy</small>):</label>
                                                            <?php if(isset($_SESSION['post']['list_email'])): $email = $_SESSION['post']['list_email']; else: $email = $get_email['list_email']; endif; ?>
                                                            <?php echo form_input('list_email', $email, 'class="form-control post-email" id="postEmail"') ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <script type="text/javascript">
                                                    $(document).ready(function () {
                                                        $("#select_type").on('change', function() {
                                                            var type = $("#select_type option:selected" ).val();
                                                            if(type == "3") {
                                                                $(".custom-email").show();
                                                            } else {
                                                                $(".custom-email").hide();
                                                            }
                                                        });
                                                    });
                                                </script>
                                                <!-- Body Start -->
                                                <div class="form-group">
                                                    <?php if(isset($_SESSION['post']['message'])): $contents = $_SESSION['post']['message']; else: $contents = $get_email['message']; endif; ?>
                                                    <?php echo form_textarea('message', $contents, 'class="form-control" rows="5" cols="50" id="content"') ?>
                                                </div>
                                                <!-- Body End -->
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <!-- Submit -->
                                                <button name="button" type="submit" value="save_and_edit" class="btn btn-primary">Lưu lại</button>
                                                <button name="button" type="submit" value="save" class="btn btn-info">Lưu & Gửi</button>
                                                <a href="<?php echo base_url('admin/list-email.html') ?>" class="btn btn-default">Hủy</a>
                                            <!-- Submit End -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php echo form_close(); ?>
                    </div>
                    <!-- /content area -->
                </div>
                <!-- /main content -->
            </div>
        </div>
        <!-- /page container -->
        <script>
            CKEDITOR.replace('content', {
                height: 400,
            });
            $('#ButtonCreationDemoButton').click(function (e) {
                $('#ButtonCreationDemoInput').AnyTime_noPicker().AnyTime_picker().focus();
                e.preventDefault();
            });
            $('#postEmail').tokenfield({
                
            });
        </script>
    </body>
</html>
