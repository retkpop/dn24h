<?php require_once 'header.php'; ?>

                <!-- Main content -->
                <div class="content-wrapper">
                    <!-- Page header -->
                    <div class="page-header">
                        <div class="page-header-content">
                            <div class="page-title">
                                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                            </div>
                            <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
                        </div>
                        <div class="breadcrumb-line">
                            <ol class="breadcrumb">
                                <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                                <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                            </ol>
                        </div>
                    </div>
                    <!-- /page header -->


                    <!-- Content area -->
                    <div class="content">
                        <div class="col-md-12">
                            <?php if(isset($_SESSION['return_add'])): ?>
                            <div class="flash alert <?php echo ($_SESSION['return_add'] == 0)? 'alert-error': 'alert-success' ?> alert-styled-left">
                                <?php if($_SESSION['return_add'] == 0): ?>
                                <span class="text-semibold">Lỗi! </span> Danh mục đã tồn tại
                                <?php else: ?>
                                <span class="text-semibold">Thành công </span> Chỉnh sửa danh mục thành công
                                <?php endif; ?>
                                <div class="heading-elements">
                                    <ul class="icons-list">
                                        <li><a class="close" data-action="close"></a></li>
                                    </ul>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(validation_errors() != false): ?>
                            <div class="alert alert-danger">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <strong>Có lỗi xảy ra!</strong>
                                <ul>
                                    <?php echo validation_errors('<li>' , '</li>'); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="clearfix"></div>
                        <?php echo form_open_multipart('admin/community/edit?id=' .$community['id']) ?>
                            <!-- Panel _start -->
                            <div class="panel panel-flat">
                                <div class="panel-heading">
                                    <h5>Thêm danh mục</h5>
                                    <div class="heading-elements">
                                        <ul class="icons-list">
                                            <li><a data-action="collapse"></a></li>
                                            <li><a data-action="reload"></a></li>
                                            <li><a data-action="close"></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="panel-body">
                                  <div class="row">
                                    <div class="col-md-4">
                                      <div class="form-group">
                                        <label for="">Thumbnail</label>
                                          <div class="panel-body thumbnail">
                                              <?php if($community['thumbnail'] != '') { $thumbnail = base_url('uploads/community/thumbnail_community/'.$community['thumbnail']);} else { $thumbnail = $this->template->dir() . 'views/images/no-thumbnail.jpg';} ?>
                                              <?php if($community['thumbnail']): ?>
                                                  <input type="hidden" name="old_thumb" value="<?php echo $community['thumbnail']; ?>">
                                              <?php endif; ?>

                                              <div id="kvt-thumbnail-errors" class="center-block" style="display:none"></div>
                                              <div class="kvt-thumbnail center-block" style="width:100%">
                                                  <input type="file" id="thumbnail" name="thumbnail" class="file-loading file-styled">
                                              </div>
                                          </div>
                                          <script>
                                            $("#thumbnail").fileinput({
                                                overwriteInitial: true,
                                                maxFileSize: 1500,
                                                showClose: false,
                                                showCaption: false,
                                                browseLabel: '',
                                                removeLabel: '',
                                                browseIcon: '<i class="glyphicon glyphicon-folder-open"></i>',
                                                removeIcon: '<i class="glyphicon glyphicon-remove"></i>',
                                                removeTitle: 'Cancel or reset changes',
                                                elErrorContainer: '#kvt-thumbnail-errors',
                                                msgErrorClass: 'alert alert-block alert-danger',
                                                defaultPreviewContent: '<img src="<?php echo $thumbnail ?>" alt="Hình thumbnail" style="width:100%">',
                                                layoutTemplates: {main2: '{preview} ' + ' {remove} {browse}'},
                                                allowedFileExtensions: ["jpg", "png", "gif"]
                                            });
                                        </script>
                                      </div>
                                    </div>
                                    <div class="col-md-8">
                                      <div class="form-group">
                                          <label for="name">Tên danh mục</label>
                                          <?php if(isset($_POST['name'])): $name = $_POST['name']; else: $name = $community['name']; endif; ?>
                                          <?php echo form_input('name', $name, 'class="form-control" id="title" placeholder="Tên danh mục sản phẩm"') ?>
                                      </div>
                                      <div class="form-group">
                                          <label for="name_seo">Tên danh mục hiện ở title</label>
                                          <?php if(isset($_POST['name_seo'])): $name_seo = $_POST['name_seo']; else: $name_seo = $community['name_seo']; endif; ?>
                                          <?php echo form_input('name_seo', $name_seo, 'class="form-control" id="name_seo" placeholder="Tên danh mục sản phẩm hiện ở title"') ?>
                                      </div>
                                      <!-- Tiêu đề END -->

                                      <!-- URI Start -->
                                      <div class="form-group">
                                          <label for="slug">Slug</label>
                                          <?php if(isset($_POST['slug'])): $slug = $_POST['slug']; else: $slug = $community['slug']; endif; ?>
                                          <?php echo form_input('slug', $slug, 'class="form-control" id="slug" placeholder="Đường dẫn tới danh mục"') ?>
                                      </div>
                                      <!-- URI END -->
                                      <!-- URI Start -->
                                      <div class="form-group">
                                          <label for="">Mô tả</label>
                                          <?php if(isset($_POST['description'])): $description = $_POST['description']; else: $description = $community['description']; endif; ?>
                                          <?php echo form_textarea('description', $description, 'class="form-control" rows="3" cols="40" style="height: 100px" id="description"') ?>
                                      </div>
                                      <button type="submit" class="btn btn-primary">Lưu lại</button>
                                    </div>

                                  </div>
                                </div>
                            </div><!-- Panel End -->
                        <?php echo form_close(); ?>
                    </div>
                </div>
                <script>
                    $(document).ready(function () {
                        $('#title').on('change, keyup', function () {
                            var value = $(this).val();
                            var uri;
                            if (value == '') {
                                uri =  ' ';
                            } else {
                                uri = value;
                            }
                            $.ajax({
                                url: encodeURI('<?php echo base_url('admin/createSlug/') ?>/' + uri),
                                success: function (data) {
                                    $('#slug').val(data);
                                }
                            });
                        });
                    })
                </script>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
    </body>
</html>
