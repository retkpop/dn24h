<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CodeIgniter Template Class
 *
 * Build your CodeIgniter pages much easier with partials, breadcrumbs, layouts and themes
 *
 * @package			CodeIgniter
 * @subpackage		Libraries
 * @category		Libraries
 * @author			Tam Kieu
 * @license			http://tamkieu.com
 * @link			http://tamkieu.com
 */
class Timesystems {
  function __construct($config = array()) {
      $this->_ci = & get_instance();

      if (!empty($config)) {
          $this->initialize($config);
      }

      log_message('debug', 'Template Class Initialized');
  }
  public function nicetime($time) {
      // Validate
    if( !isset($time) && !strtotime($time) ) {
        return "Improper Parameter.";
    } else {}

    // Variables
    $now = time();
    $time = strtotime($time);

    $periods = array(
        array("giây", 1),
        array("phút", 60),
        array("giờ", 60),
        array("ngày", 24),
        array("tuần", 7),
        array("tháng", 4.35),
        array("năm", 12)
    );

    // Future or Past
    if( $now > $time ) {
        $difference = $now - $time;
        $tense = "trước";
    } else {
        $difference = $time - $now;
        $tense = "tới";
    }

    // Present
    if( $difference < 60 ) { return $difference . ' giây ' .$tense; }

    // Debug / Testing
    //echo "Difference: ".$difference." ".$periods[0][0]."s<br/>";

    // Safe Variable to Calculate
    $figure = $difference;

    // Calculate
    for( $index = 1; ($figure >= 1 && ($figure / $periods[$index][1]) >= 1) && $index < count($periods); $index++ ) {
        // Debug / Testing
        //echo "Figuring ".$figure." / ".$periods[$index][1];
        // Figure
        $figure /= $periods[$index][1];

        // Plurality Check
        if( $figure != 1) { $periods[$index][0].=""; }

        // Debug / Testing
        //echo " = ".round($figure)." ".$periods[$index][0]."<br/>";
    }

    // Result
    return round($figure)." ".$periods[$index-1][0]." ".$tense;
  }
}
