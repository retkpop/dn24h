<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/

//FRONTEND
  $route['default_controller'] = 'frontend/homes';
  $route['404_override'] = '';
  $route['translate_uri_dashes'] = FALSE;

  $route['(:any)-(:num).html'] = 'frontend/single_post/single/$1/$2';
  $route['congdong.html'] = 'frontend/community';
  $route['danhmuc/(:any)'] = 'frontend/category/posts/$1';
  $route['user/register'] = 'frontend/user/register';
  $route['user/login'] = 'frontend/user/login';
  $route['user/logout'] = 'frontend/user/logout';
  $route['user/add_post'] = 'frontend/community/add_post';
  $route['user/add_post_form'] = 'frontend/community/add_post_action';
  $route['thao-luan/post-(:num)'] = 'frontend/community/single_community/$1';
  $route['discussion/comment'] = 'frontend/community/comment';
  $route['discussion/delete_comment'] = 'frontend/community/delete_comment';
  $route['discussion/like_post'] = 'frontend/community/like_post';
  $route['discussion/dislike_post'] = 'frontend/community/dislike_post';
  $route['congdong/(:any)'] = 'frontend/community/community_cat/$1';
  $route['discussion/next_paging'] = 'frontend/community/next_paging';
  $route['discussion/comment/see-more-comments'] = 'frontend/community/see_more_comments';

  //User
  $route['user/(:any)'] = 'frontend/user/profile_user/$1';
  $route['user/(:any)/profile'] = 'frontend/user/edit_profile/$1';
  $route['user/(:any)/change-avatar'] = 'frontend/user/change_avatar/$1';
  $route['user/(:any)/(:num)'] = 'frontend/user/profile_user/$1';
  //End user


//END FRONTEND





//BACKEND ROUTER
  $route['admin/createSlug'] = 'backend/systems/createSlug';
  $route['admin/fillter_post'] = 'backend/posts/fillter_post';
  $route['admin/createSlug/(:any)'] = 'backend/systems/createSlug/$1';
  $route['admin/new_post'] = 'backend/posts/new_post';
  $route['admin/delete_post/(:num)'] = 'backend/posts/delete_post/$1';
  $route['admin/bulk_action'] = 'backend/posts/bulk_action';
  $route['admin/post-categories.html'] = 'backend/posts/categories/';
  $route['admin/edit_cat'] = 'backend/posts/edit_cat/';
  $route['admin/list_posts'] = 'backend/posts/list_posts';
  $route['admin/list_post/(:num)'] = 'backend/posts/index/$1';
  $route['admin/post_edit/(:num)'] = 'backend/posts/post_edit/$1';
  $route['admin/list_page'] = 'backend/pages/list_page';
  $route['admin/list_page/(:num)'] = 'backend/pages/list_page/$1';
  $route['admin/new_page'] = 'backend/pages/new_page';
  $route['admin/page_edit/(:num)'] = 'backend/pages/page_edit/$1';
  $route['admin/delete_page/(:num)'] = 'backend/pages/delete_page/$1';
  $route['admin/bulk_action_page'] = 'backend/pages/bulk_action_page';
  $route['admin/login'] = 'backend/users/login';
  $route['admin/logout'] = 'backend/users/logout';

  //Menu
  $route['admin/list_menu'] = 'backend/menus/list_menu';
  $route['admin/addmenu'] = 'backend/menus/addmenu';
  $route['admin/delete_menu'] = 'backend/menus/delete_menu';
  $route['admin/save_menu/(:num)'] = 'backend/menus/save_menu/$1';
  $route['admin/save_menu_change/(:num)'] = 'backend/menus/save_menu_change/$1';
  $route['admin/remove_list_menu/(:num)'] = 'backend/menus/remove_list_menu/$1';
  //End Menu

  //ads
  $route['admin/ads'] = 'backend/ads/ads';
  $route['admin/ads_detail'] = 'backend/ads/ads_detail';
  $route['admin/delete_ads'] = 'backend/ads/delete_ads';
  $route['admin/bulk_action_ads'] = 'backend/ads/bulk_action_ads';
  $route['admin/update_arrange_ads'] = 'backend/ads/update_arrange_ads';
  //End ads

  //Users
  $route['admin/users'] = 'backend/users/users';
  $route['admin/users/edit/(:num)'] = 'backend/users/user_edit/$1';
  $route['admin/users/delete/(:num)'] = 'backend/users/delete_user/$1';
  $route['admin/bulk_action_user'] = 'backend/users/bulk_action_user';
  //End Users

  //Auto post
  $route['admin/auto_post'] = 'backend/autopost/auto_post';
  $route['admin/add_site'] = 'backend/autopost/add_site';
  $route['admin/delete_site'] = 'backend/autopost/delete_site';
  $route['admin/getContentAutoPost'] = 'backend/autopost/getContentAutoPost';

  //End Auto post

  //Conommunity
  $route['admin/communities'] = 'backend/community/list_discuss';
  $route['admin/communities/(:num)'] = 'backend/community/list_discuss/$1';
  $route['admin/community/add'] = 'backend/community/add_community';
  $route['admin/community/bulk_action_community'] = 'backend/community/bulk_action_community';
  $route['admin/community/delete_discuss/(:num)'] = 'backend/community/delete_discuss/$1';
  $route['admin/community/edit'] = 'backend/community/edit_community';
  $route['admin/community/delete_community'] = 'backend/community/delete_community';
  //End community

//END BACKEND ROUTER
