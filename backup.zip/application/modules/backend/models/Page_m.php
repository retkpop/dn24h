<?php

Class Page_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function count_all_pages(){
        return $this->db->count_all('pages');
    }
    public function all_pages($number, $offset) {
        $query = $this->db->order_by('id', 'desc')->get('pages',$number,$offset);
        if($query->num_rows() > 0) {
            foreach ($query->result_array() as $value) {
                $author = $this->db->where('id', $value['author_id'])->get('users')->row_array();
                $author['fullname'] = $author['last_name'] . ' ' . $author['first_name'];
                $datepost = date_create($value['date_post']);
                $datepost = date_format($datepost,"d/m/Y");
                $value['date_post'] = $datepost;
                $value['slug'] = base_url() . $value['slug'] . '.html';
                $value['author_name'] = $author['fullname'];
                $data[] = $value;
            }
            return $data;
        } else {
            return false;
        }
    }
    public function data_page($id) {
        $query_post = $this->db->where('id', $id)->get('pages');
        if($query_post->num_rows() > 0){
            return $query_post->row_array();
        }
        return false;
    }
    public function page_edit($input,$id) {
        $this->db->where('id', $id)->update('pages', $input);
    }
    public function delete_page($id) {
        $query = $this->db->where('id', $id)->get('pages');
        if($query->num_rows() > 0) {
            $this->db->where('id', $id)->delete('pages');
        } else {
            return false;
        }
    }
    public function insert_page($input) {
        $this->db->insert('pages', $input);
        $page_id = $this->db->insert_id();
        //Nếu chèn thành công sẽ có id của post
        if($page_id > 0){
            return $page_id;
        }
        return false;
    }
}
