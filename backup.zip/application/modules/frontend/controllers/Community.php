<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Community extends CI_Controller {
	public function __construct() {
      parent::__construct();
      $this->load->library('session');  //Load the Session
      $this->template->set_theme('frontend');
      date_default_timezone_set('Asia/Saigon');
      $method = $this->router->fetch_method();
			$this->load->helper('text');
      //pagination
      $this->load->library('pagination');
      $this->load->helper('url');
			$this->load->model('system_m');
			$this->load->model('community_m');
			$options = $this->system_m->get_options();
			$this->template->set('page', $method)->set('options', $options)->set_breadcrumb('Home page', base_url('index'));
  }
	public function see_more_comments() {
		$rules = array(
      array(
          'field' => 'post_id',
          'label' => 'Post ID',
          'rules' => 'trim|required'
      ),
			array(
          'field' => 'parent',
          'label' => 'Parent',
          'rules' => 'trim|required'
      ),
			array(
          'field' => 'numbComment',
          'label' => 'numbComment',
          'rules' => 'trim|required'
      ),
    );
		$this->form_validation->set_rules($rules);
    if ($this->form_validation->run($this)) {
			$comments = $this->community_m->see_more_comments($this->input->post(), 3);
			if($comments == false) {
				$result = array(
					'code' => 1001,
					'message' => 'Data null',
					'Data' => null
				);
			} else {
				$result = array(
					'code' => 200,
					'message' => 'Get data success',
					'Data' => $comments
				);
			}
		} else {
			$result = array(
				'code' => 1003,
				'message' => validation_errors(' ', ' '),
				'Data' => ''
			);
		}
		$json = json_encode($result, JSON_UNESCAPED_UNICODE);
    echo $json;
	}
	public function index() {
			$data['communities'] = $this->community_m->list_post_community(32);
      $data['info'] = array (
          'title' => 'Cộng đồng Đắk Nông',
          'description' => 'Trang thông tin thảo luận, chia sẽ liên quan đến các đề tài về Đắk Nông, giới trẻ Đắk Nông',
      );
			$this->template->title('Website')->build('discuss', $data);
	}
	public function community_cat($slug) {
		$data['communities'] = $this->community_m->list_post_community_cat(32, $slug);
		if($data['communities'] != false) {
			$data['info'] = array (
					'title' => $data['communities']['name'],
					'description' => $data['communities']['description'],
			);
			$this->template->title('Website')->build('discuss', $data);
		} else {
			$this->load->view('404');
		}
	}
	public function next_paging() {
		$rules = array(
      array(
          'field' => 'numberShow',
          'label' => 'numberShow',
          'rules' => 'trim|required'
      ),
			array(
          'field' => 'catId',
          'label' => 'catId',
          'rules' => 'trim'
      ),
    );
		$this->form_validation->set_rules($rules);
    if ($this->form_validation->run($this)) {
			$communities = $this->community_m->next_paging($this->input->post(), 24);
			if($communities == false || $communities['posts'] == null) {
				$result = array(
					'code' => 1001,
					'message' => 'Data null',
					'Data' => null
				);
			} else {
				$result = array(
					'code' => 200,
					'message' => 'Get data success',
					'Data' => $communities
				);
			}
		} else {
			$result = array(
				'code' => 1003,
				'message' => validation_errors(' ', ' '),
				'Data' => ''
			);
		}
		$json = json_encode($result, JSON_UNESCAPED_UNICODE);
    echo $json;
	}
	public function like_post(){
		$rules = array(
      array(
          'field' => 'idDiscussion',
          'label' => 'Id discussion',
          'rules' => 'trim|required'
      ),
    );
    $this->form_validation->set_rules($rules);
    if ($this->form_validation->run($this)) {
			if(isset($_SESSION['loggedInUser'])) {
				$id = $this->input->post('idDiscussion');
	      $result = $this->community_m->like_discussion($id);
			} else {
				$result = array(
					'code' => 1002,
					'codeRT' => 3001,
					'message' => 'Bạn chưa đăng nhập'
				);
			}
		} else {
			$result = array(
				'code' => 1003,
				'codeRT' => 3003,
				'message' => validation_errors(' ', ' ')
			);
		}
		$json = json_encode($result, JSON_UNESCAPED_UNICODE);
    echo $json;
	}
	public function comment() {
    $rules = array(
      array(
          'field' => 'post_id',
          'label' => 'post_id',
          'rules' => 'trim|required'
      ),
      array(
          'field' => 'user_id',
          'label' => 'user_id',
          'rules' => 'trim|required'
      ),
      array(
          'field' => 'message',
          'label' => 'message',
          'rules' => 'trim|required'
      ),
			array(
          'field' => 'images',
          'label' => 'Hình ảnh',
          'rules' => 'trim'
      ),
    );
    $this->form_validation->set_rules($rules);
    if ($this->form_validation->run($this)) {
      $_POST['date_create'] = date("Y-m-d H:i:s");
      $comment = $this->community_m->add_comment($this->input->post());
      $return = array(
          'code' => '200',
          'message' => 'add success',
          'Data' => $comment
      );
    } else {
      $return = array(
				'code' => '1003',
				'message' => validation_errors(' ', ' ')
      );
    }
    $json = json_encode($return, JSON_UNESCAPED_UNICODE);
    echo $json;
	}
	public function delete_comment() {
    $getCommnet = $this->community_m->getCommentById($this->input->post('commentID'));
    if($getCommnet != false) {
      if(isset($_SESSION['loggedInUser'])) {
        if($_SESSION['loggedInUser']['type'] == 1 || $_SESSION['loggedInUser']['id'] == $getCommnet['user_id']) {
          $this->community_m->deleteComment($this->input->post('commentID'));
          $return = array(
            'code' => '200',
            'message' => 'Delete success'
          );
        } else {
          $return = array(
            'code' => '1001',
            'message' => 'Bạn không có quyền thực hiện'
          );
        }
      }
      $json = json_encode($return, JSON_UNESCAPED_UNICODE);
      echo $json;
    }
  }
	public function single_community($id) {
		$data['communities'] = $this->community_m->list_community();
		$data['single_community'] = $this->community_m->single_community($id);
		$data['new_posts'] = $this->community_m->post_qt(5);
		$data['comments'] = $this->community_m->comments($id, 0, 5);
		$data['info'] = array (
				'title' => 'Cộng đồng Đắk Nông',
				'ogType' => 'article',
				'description' => 'Trang thông tin thảo luận, chia sẽ liên quan đến các đề tài về Đắk Nông, giới trẻ Đắk Nông',
		);
		$this->template->title('Website')->build('single-community', $data);
	}
	public function add_post() {
		if (!isset($_SESSION['loggedInUser']) || $_SESSION['loggedInUser']['type'] == 2) {
				redirect('');
		}
		$data['info'] = array (
				'title' => 'Đăng bài cộng đồng',
				'description' => 'Đăng bài chia sẽ thông tin, hỏi đáp cộng đồng',
		);
		$data['communities'] = $this->community_m->list_community();
		$this->template->title('Website')->build('add-post', $data);
	}
	public function add_post_action() {
		if (!isset($_SESSION['loggedInUser']) || $_SESSION['loggedInUser']['type'] == 2) {
				return false;
		}
		$rules = array(
				array (
						'field' => 'community_id',
						'label' => 'Danh mục cộng đồng',
						'rules' => 'trim|required|integer'
				),
				array (
						'field' => 'content',
						'label' => 'Nội dung bài viết',
						'rules' => 'trim|required|min_length[30]'
				)
		);
		$this->form_validation->set_rules($rules);
		if($this->form_validation->run($this)) {
			$result = $this->community_m->insert_post($this->input->post());
		} else {
			$result = array(
				'code' => '1004',
				'message' => validation_errors('<p>' , '</p>'),
				'data' => ''
			);
		}
		$json = json_encode($result, JSON_UNESCAPED_UNICODE);
		echo $json;
	}
}
