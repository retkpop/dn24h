<?php require_once 'header.php'; ?>
                <!-- Main content -->
                <div class="content-wrapper">
                    <!-- Page header -->
                    <div class="page-header">
                        <div class="page-header-content">
                            <div class="page-title">
                                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                            </div>
                            <a class="heading-elements-toggle"><i class="icon-menu"></i></a>
                        </div>
                        <div class="breadcrumb-line">
                            <ol class="breadcrumb">
                                <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                                <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                            </ol>
                        </div>
                    </div>
                    <!-- /page header -->
                    <!-- Content area -->
                    <div class="content">
                        <div class="row">
                            <div class="col-md-3">
                                <h5>Thêm thành viên</h5>
                                <hr>
                                <div class="inner">
                                    <?php if(isset($_SESSION['return_register'])): ?>
                                    <div class="flash alert <?php echo ($_SESSION['return_register'] == false)? 'alert-error': 'alert-success' ?> alert-styled-left">
                                        <?php if($_SESSION['return_register'] == false): ?>
                                        <span class="text-semibold">Lỗi! Email đã tồn tại</span>
                                        <?php else: ?>
                                        <span class="text-semibold">Thêm thành viên mới thành công</span>
                                        <?php endif; ?>
                                        <div class="heading-elements">
                                            <ul class="icons-list">
                                                <li><a class="close" data-action="close"></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(validation_errors() != false): ?>
                                    <div class="alert alert-danger">
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                        <strong>Có lỗi xảy ra!</strong>
                                        <ul>
                                            <?php echo validation_errors('<li>' , '</li>'); ?>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="clearfix"></div>
                                <?php echo form_open_multipart() ?>
                                    <div class="form-group">
                                        <label for="last_name">Last name</label>
                                        <?php echo form_input('last_name', '', 'class="form-control" id="last_name"') ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="first_name">First name</label>
                                        <?php echo form_input('first_name', '', 'class="form-control" id="first_name"') ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <?php echo form_input('email', '', 'class="form-control" id="email đăng nhập hệ thống"') ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="phone">Số điện thoại</label>
                                        <?php echo form_input('phone', '', 'class="form-control" id="phone"') ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Mật khẩu</label>
                                        <?php echo form_input('password', '', 'class="form-control" id="password"') ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="type">Loại thành viên</label>
                                        <select name="type" class="form-control">
                                            <option value="1" selected>Admin</option>
                                            <option value="0" >Member</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Thêm thành viên</button>
                                <?php echo form_close() ?>
                            </div>
                            <div class="col-md-9">
                                <?php echo form_open('admin/bulk_action_user'); ?>
                                    <!-- Bulk Action -->
                                    <div class="bulk-action row">
                                        <div class="col-sm-4 col-md-3 col-lg-2">
                                            <div class="input-group input-group-xs">
                                                <select name="bulk_action_user" class="select select-bulk-action">
                                                    <option value="">-- Bulk Action</option>
                                                    <option value="delete">Delete</option>
                                                </select>
                                                <span class="input-group-btn">
                                                    <button class="btn btn-default" value="bulk_action">&Aacute;p dụng</button>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-sm-4 col-md-3 col-lg-2">
                                            <div class="pagination pull-right"><?php echo $this->pagination->create_links(); // tạo link phân trang ?></div>
                                        </div>
                                    </div>
                                    <!-- Bulk Action End -->
                                    <div class="panel panel-flat">
                                        <div class="panel-body no-padding">
                                            <div class="table-responsive">
                                                <table class="table table-data">
                                                    <thead>
                                                        <tr>
                                                            <th><input type="checkbox" class="styled top-check"></th>
                                                            <th>Họ và tên</th>
                                                            <th>Địa chỉ E-mail</th>
                                                            <th>Điện thoại</th>
                                                            <th>Địa chỉ</th>
                                                            <th></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php if($users != false): foreach ($users as $value): ?>
                                                        <tr>
                                                            <td><input type="checkbox" value="<?php echo $value['id'] ?>" name="id[]" <?php echo ($value['id'] == 1)? 'disabled' : '' ?> class="styled item-checkbox"></td>
                                                            <td>
                                                                <a href="<?php echo base_url('admin/users/edit/'.$value['id']) ?>"><?php echo $value['last_name'] . ' ' . $value['first_name'] ?></a>
                                                            </td>
                                                            <td><?php echo $value['email'] ?></td>
                                                            <td><?php echo $value['phone'] ?></td>
                                                            <td><?php echo $value['address'] ?></td>
                                                            <td>
                                                                <a class="btn btn-xs btn-icon btn-default" href="<?php echo base_url('admin/users/edit/'.$value['id']) ?>">
                                                                    <i class="icon-pen"></i>
                                                                </a>
                                                                <?php if($value['id'] != 1): ?>
                                                                <a class="btn btn-xs btn-icon btn-danger" href="<?php echo base_url('admin/users/delete/'.$value['id']) ?>">
                                                                    <i class="icon-minus2"></i>
                                                                </a>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Bulk Action -->
                                    <div class="bulk-action row">
                                        <div class="col-sm-4 col-md-3 col-lg-2">
                                            <div class="input-group input-group-xs">
                                                <select name="bulk_action" class="select-bulk-action">
                                                    <option value="">-- Bulk Action</option>
                                                    <option value="delete">Delete</option>
                                                </select>
                                                <span class="input-group-btn">
                                                    <button class="btn btn-default" value="bulk_action">&Aacute;p dụng</button>
                                                </span>
                                            </div><!-- /input-group -->
                                        </div>
                                        <div class="col-sm-4 col-md-3 col-lg-2">
                                            <div class="pagination pull-right"><?php echo $this->pagination->create_links(); // tạo link phân trang ?></div>
                                        </div>
                                    </div>
                                    <!-- Bulk Action End -->
                                <?php echo form_close() ?>
                            </div>
                        </div>

                    </div>
                    <!-- /content area -->
                </div>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
        <!-- /page container -->
    </body>
</html>
