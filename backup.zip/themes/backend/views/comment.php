<?php require_once 'header.php'; ?>
                <!-- Main content -->
                <div class="content-wrapper">
                    <!-- Page header -->
                    <div class="page-header">
                        <div class="page-header-content">
                            <div class="page-title">
                                <h4><i class="icon-arrow-left52 position-left"></i><span class="text-semibold"><?php echo $template['title'] ?></span></h4>
                            </div>
                        </div>
                        <div class="breadcrumb-line">
                            <ol class="breadcrumb">
                                <li itemprop="itemListElement"><a itemprop="item" href=""><span itemprop="name">Admin</span></a><meta itemprop="position" content="1"></li>
                                <li itemprop="itemListElement" class="active"><span itemprop="item"><span itemprop="name"><?php echo $template['title'] ?></span></span><meta itemprop="position" content="2"></li>
                            </ol>
                        </div>
                    </div>
                    <!-- /page header -->

                    <div class="content">
                        <?php echo form_open('admin/bulk_action_comment'); ?>
                            <!-- Bulk Action -->
                            <div class="bulk-action row">
                                <div class="col-md-3">
                                    <div class="input-group input-group-xs">
                                        <select name="bulk_action_comment" class="select select-bulk-action">
                                            <option value="">-- Bulk Action</option>
                                            <option value="delete">Xóa comment</option>
                                        </select>
                                        <span class="input-group-btn">
                                            <button class="btn btn-default" value="bulk_action_comment">&Aacute;p dụng</button>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="pagination pull-right"><?php echo $this->pagination->create_links(); // tạo link phân trang ?></div>
                                </div>
                                <div class="col-md-offset-3 col-md-3">
                                    <div class="filter">
                                        <input type="text" placeholder="Nhập thông tin tìm kiếm" class="form-control form-searchUser" />
                                        <button type="button" class="btnSearchUser btn bg-teal btn-ladda btn-ladda-progress" data-style="expand-right" data-spinner-size="20">
                                            <span class="ladda-label">Search</span>
                                        </button>
                                    </div>
                                </div>
                                
                            </div>
                            <!-- Bulk Action End -->
                            <div class="panel panel-flat">
                                <div class="panel-body no-padding">
                                    <div class="table-responsive listComments">
                                        <table class="table table-data">
                                            <tr>
                                                <th><input type="checkbox" class="top-check styled"></th>
                                                <th>User</th>
                                                <th>Description</th>
                                                <th>Message</th>
                                                <th></th>
                                            </tr>
                                        </table>
                                        <table class="table table-data tableData">
                                            <tbody>
                                                <?php if(!empty($comments)): foreach ($comments as $key => $comment): if(!empty($comment['id'])): ?>
                                                <tr  id="list<?php echo $comment['id'] ?>">
                                                    <td>
                                                        <input type="checkbox" id="idOrder" name="id[]" value="<?php echo $comment['id'] ?>" class="item-checkbox styled">
                                                    </td>
                                                    <td style="width: 15%">

                                                        <div class="media-body">
                                                            <a href="<?php echo $comment['product']['url_post'] ?>#listRatingProduct" target="_blank" class="display-inline-block text-default text-semibold letter-icon-title"><?php echo $comment['fullname'] ?></a>
                                                            <div class="text-muted text-size-small"><span class="status-mark border-blue position-left"></span> <?php echo $comment['date_rating'] ?></div>
                                                        </div>
                                                    </td>
                                                    <td style="width: 35%">
                                                        <a href="<?php echo $comment['product']['url_post'] ?>#listRatingProduct" target="_blank" class="text-default display-inline-block">
                                                            <span class="text-semibold">Bình luận trong: <?php echo $comment['product']['title_post'] ?></span>
                                                            <span class="display-block text-muted"><?php echo $comment['fullname'] ?> đã thêm bình luận mới</span>
                                                        </a>
                                                    </td>
                                                    <td style="width: 30%">
                                                        <div class="media-left media-middle">
                                                            <span class="display-block text-muted"><?php echo $comment['message'] ?></span>
                                                        </div>
                                                    </td>
                                                    <td style="width:">
                                                        <a class="btn btn-xs btn-danger  btn-icon" id="delete_order" href="<?php echo base_url('admin/delete_comment/' . $comment['id']) ?>"><i class="icon-minus2"></i></a>
                                                        <a target="_blank" class="btn btn-icon btn-xs btn-info" href="<?php echo $comment['product']['url_post'] ?>#listRatingProduct"><i class="icon-eye2"></i></a>
                                                    </td>
                                                </tr>
                                                <?php endif; endforeach; endif; ?>
                                            </tbody>
                                        </table>
                                        <table class="table table-data">
                                            <tr>
                                                <th><input type="checkbox" class="top-check styled"></th>
                                                <th>User</th>
                                                <th>Description</th>
                                                <th>Message</th>
                                                <th></th>
                                            </tr>
                                         </table>
                                    </div>
                                </div>
                            </div>
                            <script type="text/javascript">
                                $(".form-searchUser").on('keyup keypress', function(e) {
                                    var keyCode = e.keyCode || e.which;
                                    if (keyCode === 13) {
                                        e.preventDefault();
                                        $(".btnSearchUser").click();
                                    }
                                });
                                $(".btnSearchUser").on("click", function(){
                                    var valueSearch = $(".form-searchUser").val();
                                    var baseUrl = "<?php echo base_url() ?>";
                                    if(valueSearch.trim() == "") {
                                        window.location.replace("<?php echo current_url() ?>");
                                    } else {
                                        $.ajax({
                                            type: "POST",
                                            url: baseUrl + "admin/fillter_comment",
                                            cache: false,
                                            dataType: 'json',
                                            data: {"valueSearch": valueSearch},
                                            success: function(data) {
                                                if(data.code == "0") {
                                                    $('.listComments table.tableData tbody').html("");
                                                    data.Data.forEach(function(detailComment) {
                                                        $('.listComments table.tableData tbody').append('<tr><td><input type="checkbox" value="'+detailComment.id+'" name="id[]" class="item-checkbox styled"></td>'
                                                            + '<td style="width: 15%">'
                                                                + '<div class="media-body">'
                                                                    + '<a href="' + detailComment.product.url_post + '#listRatingProduct" target="_blank" class="display-inline-block text-default text-semibold letter-icon-title">' + detailComment.fullname + '</a>'
                                                                    + '<div class="text-muted text-size-small"><span class="status-mark border-blue position-left"></span> ' + detailComment.date_rating + '</div>'
                                                                + '</div>'
                                                            + '</td>'
                                                            + '<td style="width: 35%">'
                                                                + '<a href="' + detailComment.product.url_post + '#listRatingProduct" target="_blank" class="text-default display-inline-block">'
                                                                    + '<span class="text-semibold">Bình luận trong: '+ detailComment.product.title_post + '</span>'
                                                                    + '<span class="display-block text-muted">' + detailComment.fullname + ' đã thêm bình luận mới</span>'
                                                                + '</a>'
                                                            + '</td>'
                                                            + '<td style="width: 30%">'
                                                                + '<div class="media-left media-middle">'
                                                                    + '<span class="display-block text-muted">' + detailComment.message + '</span>'
                                                                + '</div>'
                                                            + '</td>'
                                                            + '<td style="width:">'
                                                                + '<a class="btn btn-xs btn-danger  btn-icon" id="delete_order" href="'+ baseUrl + 'admin/delete_comment/'+detailComment.id +'"><i class="icon-minus2"></i></a>'
                                                                + '<a target="_blank" class="btn btn-icon btn-xs btn-info" href="' + detailComment.product.url_post + '#listRatingProduct"><i class="icon-eye2"></i></a>'
                                                            + '</td>'
                                                        + '</tr>');
                                                    });
                                                } else {
                                                    $('.listComments table.tableData tbody').html('<tr><td colspan="8" style="text-align: left; color: red">Không tìm thấy kết quả tìm kiếm</td></tr>');
                                                }
                                            },
                                            error: function (request, status, error) {
                                                alert(request.responseText);
                                            }
                                        })
                                    }
                                });
                            </script>
                            
                        <?php echo form_close() ?>
                    </div>
                    <!-- Content area -->
                   
                </div>
                <!-- /main content -->
            </div>
            <!-- /page content -->
        </div>
    </body>
</html>