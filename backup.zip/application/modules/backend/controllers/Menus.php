<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Menus extends CI_Controller {
		public function __construct() {
	      parent::__construct();
				if ($this->router->fetch_method() != 'login' && $this->router->fetch_method() != 'register') {
            if (!isset($_SESSION['loggedInUser']) || $_SESSION['loggedInUser']['type'] != 1) {
                redirect('admin/login');
            }
        }
	      $this->load->library('session');  //Load the Session
	      $this->template->set_theme('backend');
	      date_default_timezone_set('Asia/Saigon');
	      $method = $this->router->fetch_method();
	      $this->template->set('page', $method)->set_breadcrumb('Menus', base_url('index'));
	      //pagination
				$this->load->helper('url');
	      $this->load->helper('text');
				$this->load->model('menu_m');
	  }
    public function addmenu() {
        if(empty($_GET['id'])) {
            redirect('admin/list_menu');
        } else {
            $check_menu = $this->menu_m->check_menu($_GET['id']);
            if($check_menu != false) {
                if(!empty($_POST)) {
                    if(!empty($_FILES['icon_menu']['name'])) {
                        $_POST['link_icon'] = $this->file_upload('icon_menu', 'icon_menu');
                    } else {
                        $_POST['link_icon'] = '';
                    }
                    $this->menu_m->update_menu($this->input->post(), $_GET['id']);
                    redirect('admin/addmenu?id=' . $_GET['id']);
                }
                $data['list_menu']   = $this->get_list_menu($_GET['id']);
                $data['data'] = $this->menu_m->get_all_menu();
                $this->template->title('Menu detail')->build('menu-detail',$data);
            } else {
                redirect('admin/list_menu');
            }
        }
    }
    public function file_upload($name_sl, $name_file) {
				if (!is_dir('uploads/'. $name_sl .'/')) {
						mkdir('uploads/'. $name_sl .'', 0777, true);
				}
				$path = dirname(BASEPATH) . '/uploads/'. $name_sl .'/';
        $tmp_name = $_FILES[$name_file]['tmp_name'];
        $name = $_FILES[$name_file]['name'];
        $array = explode('.', $name);
        $n = count($array);
        $name_file = md5(microtime() . rand(1, 1000));
        if($_FILES[$name_file]['error']==0){
            $new_name = $name_file . '.' . $array[$n - 1];
            move_uploaded_file($tmp_name, $path . $new_name);
            return $new_name;
        } else {
            $new_name = '';
            return $new_name;
        }
    }
    public function list_menu() {
        $rules = array(
            array (
                'field' => 'name',
                'label' => 'Tên trình đơn',
                'rules' => 'trim|required'
            ),
            array (
                'field' => 'slug',
                'label' => 'Slug',
                'rules' => 'trim|required'
            )
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run($this)) {
            $this->menu_m->add_menu($this->input->post());
            redirect('admin/list_menu');
        } else {
            $data['menus'] = $this->menu_m->all_menu();
            $this->template->title('List Menu')->build('menu', $data);
        }
    }
    public function delete_menu() {
        if(!empty($_POST)) {
            if ($this->input->is_ajax_request()) {
                $this->menu_m->delete_menu($this->input->post('id'));
                echo 1;
            }
        } else {
            redirect('admin');
        }
    }
    public function remove_list_menu($menu_id) {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
            $this->menu_m->remove_list_menu($id, $menu_id);
            echo $menu_id;
        }
    }
    public function save_menu_change($menu_id) {
        if ($this->input->is_ajax_request()) {
            $update = $this->menu_m->save_menu_change($this->input->post(), $menu_id);
            $data = array(
                'code' => 200,
                'message' => 'Requess Success',
                'Data' => $update
            );
        } else {
            $data = array(
                'code' => 1001,
                'message' => 'Error!',
                'Data' => 'No request'
            );
        }
        $json = json_encode($data, JSON_UNESCAPED_UNICODE);
        echo $json;
    }
    public function check_select($value, $columb) {
        if($columb == $value) {
            return 'selected';
        } else {
            return '';
        }
    }
    public function get_list_menu($menu_id) {
        $str = "";
        $menus  =   $this->menu_m->get_menu($menu_id);
        $str .= "<ol class='sortable'>";
        if(!empty($menus)) {
            foreach ($menus as $menu) {
                $str .= "<li id='menuItem_". $menu->id ."'><div class='menu-wrap'>";
                $str .= "<div class='menu-item'>
                            <div class='item-title'>". $menu->label ."</div>
                            <div class='item-control'>Link</div>
                        </div>";
                $str .= "<div class='menu-item-setting hidden'>
                            <div class='form-group'>
                                <input type='text' name='label[]' class='form-control input-sm' value='".$menu->label."'>
                            </div>
                            <div class='form-group'>
                                <select class='form-control selectColumb'>
                                    <option value='0' ".$this->check_select(0, $menu->columb).">1 columb</option>
                                    <option value='1' ".$this->check_select(1, $menu->columb).">2 columb</option>
                                    <option value='2' ".$this->check_select(2, $menu->columb).">columb lable</option>
                                </select>
                            </div>
                            <div class='returnChange form-group'></div>
                            <div class='menu-setting-functions-wrap'>
                                <span id='save_menu' idMenu='".$menu->id."' class='menu-save text-success'>Save</span> | <button id='remove_menu' idMenu='".$menu->id."' class='menu-delete text-danger'>Remove</button> | <a href='#' class='menu-cancel-setting'>Cancel</a>
                            </div>
                        </div>";
                $str .= "</div>";
                $str .= $this->get_sub_list_menu($menu_id, $menu->id,$i = 0);
                $str .= "</li>";
            }
            $str .= "</ol>";
            return $str;
        }
    }
    function get_sub_list_menu($menu_id, $id, $i = 0) {
        $str = "";
        $sub_menus = $this->menu_m->get_submenu($menu_id, $id);
        //kiem tra get subcategory co ton ai hay
        if($sub_menus) {
            $str .= "<ol>";
            foreach ($sub_menus as $sub_menu) {
                //kiem tra con parent hay ko
                $str .= "<li id='menuItem_". $sub_menu->id ."'><div class='menu-wrap'>";
                $str .= "<div class='menu-item'>
                            <div class='item-title'>". $sub_menu->label ."</div>
                            <div class='item-control'>Link</div>
                        </div>";
                $str .= "<div class='menu-item-setting hidden'>
                            <div class='form-group'>
                                <input type='text' name='label[]' class='form-control input-sm' value='".$sub_menu->label."'>
                            </div>
                            <div class='form-group'>
                                <select class='form-control selectColumb'>
                                    <option value='0' ".$this->check_select(0, $sub_menu->columb).">1 columb</option>
                                    <option value='1' ".$this->check_select(1, $sub_menu->columb).">2/3/4 columb normal</option>
                                    <option value='2' ".$this->check_select(2, $sub_menu->columb).">columb lable</option>
                                </select>
                            </div>
                            <div class='returnChange form-group'></div>
                            <div class='menu-setting-functions-wrap'>
                                <span id='save_menu' idMenu='".$sub_menu->id."' class='menu-save text-success'>Save</span> | <button id='remove_menu' idMenu='".$sub_menu->id."' class='menu-delete text-danger'>Remove</button> | <a href='#' class='menu-cancel-setting'>Cancel</a>
                            </div>
                        </div>";
                $str .= "</div>";
                if($sub_menu->id) {
                    $str .= $this->get_sub_list_menu($menu_id, $sub_menu->id,$i++);
                }
                $str .= "</li>";
            }
            $str .= "</ol>";
        }
        return $str;
    }


    public function save_menu($id) {
        if ($this->input->is_ajax_request()) {
            $data = $this->input->post('id');
            $dl = explode("&", $data);
            $i = 1;
            foreach ($dl as $value) {
                $dl = explode("=", $value);
                $parent = ($dl[1] == 'null')? 0 : $dl[1];
                $list = array(
                    'id' => preg_replace('/[^0-9]/','',$dl[0]),
                    'arrange' => $i++,
                    'parent' => $parent
                );
                $this->menu_m->update_list_menu($list,$id);
            }
            echo $id;
        }
    }
}
