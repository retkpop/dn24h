<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Single_post extends CI_Controller {
	public function __construct() {
      parent::__construct();
      $this->load->library('session');  //Load the Session
      $this->template->set_theme('frontend');
      date_default_timezone_set('Asia/Saigon');
      $method = $this->router->fetch_method();
      //pagination
      $this->load->library('pagination');
      $this->load->helper('url');
			$this->load->model('system_m');
			$this->load->model('single_m');
			$options = $this->system_m->get_options();
			$this->template->set('page', $method)->set('options', $options)->set_breadcrumb('Home page', base_url('index'));
  }
	public function single($slug, $id) {
    if(!isset($_SESSION['views_post'. $id]) || (isset($_SESSION['views_post'. $id]) && $_SESSION['views_post'. $id] != $id)) {
          $this->single_m->add_viewer($id);
          $this->session->set_userdata('views_post'. $id, $id);
      }
      $data['post'] = $this->single_m->single_post($slug,$id);
      $data['info'] = array (
          'title' => $data['post']['title_seo'],
					'ogType' => 'article',
          'description' => $data['post']['description'],
      );
      $data['related_articles'] = $this->single_m->related_articles($id, $data['post']['cat_id'], 6);
      $this->template->title($data['post']['title'])->build('single', $data);
	}
}
