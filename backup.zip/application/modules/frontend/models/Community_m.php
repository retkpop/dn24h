<?php

Class Community_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function list_community() {
      $communities = $this->db->get('communities');
      if($communities->num_rows()>0) {
        return $communities->result_array();
      }
      return false;
    }
    public function count_discuss_by_id_user($id) {
      return $this->db->where('author_id', $id)->get('community_posts')->num_rows();
    }
    public function get_discuss_by_id_user($user_id, $number, $offset) {
      $discussion = $this->db->where('author_id', $user_id)->get('community_posts', $number, $offset);
      if($discussion->num_rows()>0) {
        foreach ($discussion->result_array() as $discuss) {
          $discuss['author'] = $this->db->where('id', $discuss['author_id'])->get('users')->row_array();
          $discuss['cat'] = $this->db->where('id', $discuss['community_id'])->get('communities')->row_array();
          $discuss['url'] = base_url('thao-luan/post-'.$discuss['id']);
          $author = $this->db->where('id', $user_id)->get('users')->row_array();
          $author['fullname'] = $author['last_name'] . ' ' . $author['first_name'];
          $author['avatar'] = (!empty($author['avatar']))? base_url('uploads/avatar/'. $author['avatar']) : $this->template->dir() .'views/images/no-avatar.png';
          unset($author['password']);
          $discuss['author'] = $author;
          $discuss['likes'] = $this->db->where('post_id', $discuss['id'])->where('type', 1)->get('likes')->num_rows();
          if(isset($_SESSION['loggedInUser'])) {
            $discuss['user_like'] = $this->db->where('post_id', $discuss['id'])->where('user_id', $_SESSION['loggedInUser']['id'])->where('type', 1)->get('likes')->num_rows();
          }
          $discuss['comments'] = $this->comments($discuss['id'], 0, 5);
          $discuss['count_comment'] = $this->count_all_comment_by_id($discuss['id']);
          $datas[] = $discuss;
        }
        $result['posts'] = $datas;
        return $result;
      }
    }
    public function count_all_comment_by_id($id) {
      return $this->db->where('post_id', $id)->get('comments')->num_rows();
    }
    public function next_paging($input, $page) {
      if(!empty($input['catId'])) {
        $communities = $this->db->order_by('id', 'desc')->where('community_id', $input['catId'])->get('community_posts', $page, $input['numberShow']);
      } else {
        $communities = $this->db->order_by('id', 'desc')->get('community_posts',  $page, $input['numberShow']);
      }
      $datas = array();
      foreach ($communities->result_array() as $community) {
        $community['author'] = $this->db->where('id', $community['author_id'])->get('users')->row_array();
        $community['cat'] = $this->db->where('id', $community['community_id'])->get('communities')->row_array();
        $community['url'] = base_url('thao-luan/post-'.$community['id']);
        $community['content'] = character_limiter($this->stripHTMLtags($community['content']), 600);
        $author = $this->db->where('id', $community['author_id'])->get('users')->row_array();
        $author['fullname'] = $author['last_name'] . ' ' . $author['first_name'];
        $author['avatar'] = (!empty($author['avatar']))? base_url('uploads/avatar/'. $author['avatar']) : $this->template->dir() .'views/images/no-avatar.png';
        unset($author['password']);
        $community['author'] = $author;
        $datas[] = $community;
      }
      $result['posts'] = $datas;
      return $result;
    }
    public function list_post_community($limit){
      $communities = $this->db->limit($limit)->order_by('id', 'desc')->get('community_posts');
      if($communities->num_rows()>0) {
        foreach ($communities->result_array() as $community) {
          $community['author'] = $this->db->where('id', $community['author_id'])->get('users')->row_array();
          $community['cat'] = $this->db->where('id', $community['community_id'])->get('communities')->row_array();
          $community['url'] = base_url('thao-luan/post-'.$community['id']);
          $community['content'] = $this->stripHTMLtags($community['content']);
          $author = $this->db->where('id', $community['author_id'])->get('users')->row_array();
          $author['fullname'] = $author['last_name'] . ' ' . $author['first_name'];
          $author['avatar'] = (!empty($author['avatar']))? base_url('uploads/avatar/'. $author['avatar']) : $this->template->dir() .'views/images/no-avatar.png';
          unset($author['password']);
          $community['author'] = $author;
          $datas[] = $community;
        }
        $result['posts'] = $datas;
        return $result;
      }
      return false;
    }
    public function list_post_community_cat($limit, $slug){
      $cats = $this->db->where('slug', $slug)->get('communities');
      if($cats->num_rows()>0) {
        $cats = $cats->row_array();
        $communities = $this->db->limit($limit)->order_by('id', 'desc')->where('community_id', $cats['id'])->get('community_posts');
        $datas = array();
        if($communities->num_rows()>0) {
          foreach ($communities->result_array() as $community) {
            $community['author'] = $this->db->where('id', $community['author_id'])->get('users')->row_array();
            $community['cat'] = $this->db->where('id', $community['community_id'])->get('communities')->row_array();
            $community['url'] = base_url('thao-luan/post-'.$community['id']);
            $community['content'] = $this->stripHTMLtags($community['content']);
            $author = $this->db->where('id', $community['author_id'])->get('users')->row_array();
            $author['fullname'] = $author['last_name'] . ' ' . $author['first_name'];
            $author['avatar'] = (!empty($author['avatar']))? base_url('uploads/avatar/'. $author['avatar']) : $this->template->dir() .'views/images/no-avatar.png';
            unset($author['password']);
            $community['author'] = $author;
            $datas[] = $community;
          }
        }
        $cats['posts'] = $datas;
        return $cats;
      }
      return false;
    }
    private function stripHTMLtags($str) {
        $t = preg_replace('/<[^<|>]+?>/', '', htmlspecialchars_decode($str));
        $t = htmlentities($t, ENT_QUOTES, "UTF-8");
        return $t;
    }
    public function post_qt($limit) {
      $posts = $this->db->limit($limit)->order_by('rand()')->get('posts');
      if($posts->num_rows()>0) {
        foreach ($posts->result_array() as $value) {
          $author = $this->db->where('id', $value['author_id'])->get('users')->row_array();
          $author['fullname'] = $author['last_name'] . ' ' . $author['first_name'];
          unset($author['password']);
          $value['author_id'] = $author;
          $cat = $this->db->where('id', $value['cat_id'])->get('categories_post')->row_array();
          $value['cat'] = $cat;

          $date = date_create($value['date_post']);
          $name_sl = date_format($date,"Y/m");
          $value['date_post'] = date_format($date,"d/m/Y");
          if(!empty($value['thumbnail'])) {
              $value['thumbnail'] = base_url() .'uploads/thumbnail_post/' . $name_sl . '/' . $value['thumbnail'];
          } else {
              $value['thumbnail'] = $this->template->dir() . 'views/images/no-thumbnail.jpg';
          }
          $value['url'] = base_url($value['slug']. '-' . $value['id'] . '.html');
          $postDatas[] = $value;
        }
        return $postDatas;
      }
      return false;
    }
    public function like_discussion($id) {
      $discussion = $this->db->where('id', $id)->get('community_posts');
      if($discussion->num_rows()>0) {
        $likes = $this->db->where('post_id', $id)->where('user_id', $_SESSION['loggedInUser']['id'])->where('type', 1)->get('likes');
        if($likes->num_rows()>0) {
          $this->db->where('post_id', $id)->where('user_id', $_SESSION['loggedInUser']['id'])->delete('likes');
          $result = array(
            'code' => 200,
            'codeRT' => 0,
            'message' => 'Dislike success',
          );
        } else {
          $dataIs = array(
            'user_id' => $_SESSION['loggedInUser']['id'],
            'post_id' => $id,
            'date_like' => date('Y-m-d H:i:s'),
            'type' => 1
          );
          $this->db->insert('likes', $dataIs);
          if($this->db->affected_rows() > 0) {
            $result = array(
              'code' => 200,
              'codeRT' => 1,
              'message' => 'Like success',
            );
          }
        }
      } else {
        $result = array(
          'code' => 4104,
          'codeRT' => 2,
          'message' => "Post don't exists!",
        );
      }
      return $result;
    }
    public function dis_like_discussion($id){
      $discussion = $this->db->where('id', $id)->get('community_posts');
      if($discussion->num_rows()>0) {
        $this->db->where('id', $id)->set('like_n', 'like_n-1', FALSE)->update('community_posts'); //tại id cần
        $discussion = $discussion->row_array();
        return $discussion['like_n']-1;
      }
    }
    public function see_more_comments($input, $limit){
      $comments = $this->db->order_by('id', 'desc')->where('post_id', $input['post_id'])->where('parent', $input['parent'])->get('comments', $limit, $input['numbComment']);
      if($comments->num_rows()>0) {
        return $this->getcommentitem($comments);
      } else {
        return false;
      }
    }
    public function comments($post_id, $page, $limit) {
      $comments = $this->db->order_by('id', 'desc')->where('post_id', $post_id)->where('parent', 0)->get('comments', $limit, $page);
      if($comments->num_rows()>0) {
        return $this->getcommentitem($comments);
      } else {
        return false;
      }
    }
    function count_all_comment() {
      return $this->db->get('comments')->num_rows();
    }
    function getcommentitem($comments) {
      foreach ($comments->result_array() as $comment) {
        $user = $this->db->where('id', $comment['user_id'])->get('users')->row_array();
        $comment['fullname'] = $user['last_name'] . ' ' . $user['first_name'];
        $comment['user_id'] = $user['id'];
        $comment['date_time'] = $this->timesystems->nicetime($comment['date_create']);
        $comment['user_avatar'] = (!empty($user['avatar']))? base_url('uploads/avatar/'. $user['avatar']) : $this->template->dir() .'views/images/no-avatar.png';
        $subcommnets = $this->db->order_by('id', 'desc')->limit(3)->where('parent', $comment['id'])->get('comments');
        $comment['subcomments'] = array();
        if($subcommnets->num_rows()>0) {
          $sComment = array();
          foreach ($subcommnets->result_array() as $subcomment) {
            $userS = $this->db->where('id', $subcomment['user_id'])->get('users')->row_array();
            $subcomment['fullname'] = $userS['last_name'] . ' ' . $userS['first_name'];
            $subcomment['user_id'] = $userS['id'];
            $subcomment['date_time'] = $this->timesystems->nicetime($subcomment['date_create']);
            $subcomment['user_avatar'] = (!empty($userS['avatar']))? base_url('uploads/avatar/'. $userS['avatar']) : $this->template->dir() .'views/images/no-avatar.png';
            $user_tag = $this->db->where('id', $subcomment['user_tag'])->get('users');
            if($user_tag->num_rows()>0) {
              $user_tag = $user_tag->row_array();
              $subcomment['user_tag_fullname'] = $user_tag['last_name'] . ' ' . $user_tag['first_name'];
              $subcomment['user_tag_id'] = $user_tag['id'];
            }
            $sComment[] = $subcomment;
          }
          $comment['subcomments'] = $sComment;
        }
        $allComment['lists'][] = $comment;
      }
      return $allComment;
    }
    public function add_comment($input) {
      $this->db->insert('comments', $input);
      if($this->db->insert_id()>0) {
        $comment = $this->db->where('id', $this->db->insert_id())->get('comments')->row_array();
        $user = $this->db->where('id', $comment['user_id'])->get('users')->row_array();
        $comment['fullname'] = $user['last_name'] . ' ' . $user['first_name'];
        $comment['user_id'] = $user['id'];
        $comment['user_avatar'] = (!empty($user['avatar']))? base_url('uploads/avatar/'. $user['avatar']) : $this->template->dir() .'views/images/no-avatar.png';
        $user_tag = $this->db->where('id', $comment['user_tag'])->get('users');
        if($user_tag->num_rows()>0) {
            $user_tag = $user_tag->row_array();
            $comment['user_tag_fullname'] = $user_tag['last_name'] . ' ' . $user_tag['first_name'];
            $comment['user_tag_id'] = $user_tag['id'];
        }
        return $comment;
      } else {
        return false;
      }
    }
    public function deleteComment($id) {
      $this->db->where('id', $id)->delete('comments');
      $this->db->where('parent', $id)->delete('comments');
    }
    public function getCommentById($id) {
      $comment = $this->db->where('id', $id)->get('comments');
      if($comment->num_rows()>0) {
        return $comment->row_array();
      } else {
        return false;
      }
    }
    public function single_community($id) {
      $community = $this->db->where('id', $id)->get('community_posts');
      if($community->num_rows()>0) {
        $community = $community->row_array();
        $community['author'] = $this->db->where('id', $community['author_id'])->get('users')->row_array();
        $community['author']['avatar'] = (!empty($community['author']['avatar']))? base_url('uploads/avatar/'. $community['author']['avatar']): $this->template->dir() . 'views/images/no-avatar.png';
        $community['cat'] = $this->db->where('id', $community['community_id'])->get('communities')->row_array();
        $community['url'] = base_url('thao-luan/post-'.$community['id']);
        $community['likes'] = $this->db->where('post_id', $id)->where('type', 1)->get('likes')->num_rows();
        $community['count_comment'] = $this->count_all_comment();
        if(isset($_SESSION['loggedInUser'])) {
          $community['user_like'] = $this->db->where('post_id', $id)->where('user_id', $_SESSION['loggedInUser']['id'])->where('type', 1)->get('likes')->num_rows();
        }
        return $community;
      } else {
        return false;
      }
    }
    public function insert_post($input) {
      $options = $this->get_options();
      $posts = $this->db->where('date_post', date('Y-m-d'))->where('author_id', $_SESSION['loggedInUser']['id'])->get('community_posts');
      if($posts->num_rows() < $options['limit_user_post']) {
        $input['date_post'] = date('Y-m-d');
        $input['author_id'] = $_SESSION['loggedInUser']['id'];
        $insert = $this->db->insert('community_posts', $input);
        $post_id = $this->db->insert_id();
        if($post_id > 0) {
            $data = array(
              'code' => 0,
              'message' => 'Add post success!',
              'data' => base_url('thao-luan/post-'.$post_id)
            );
        } else {
          $data = array(
            'code' => 1001,
            'message' => 'Connect Database Error!',
            'data' => ''
          );
        }
      } else {
        $data = array(
          'code' => 1002,
          'message' => 'Limit post today!',
          'data' => ''
        );
      }
      return $data;
    }
    function get_options() {
        $options = $this->db->get('options');
        $row = $options->num_rows();
        foreach ($options->result_array() as $key => $value) {
            $data[] = array(
                $value['option_name'] => $value['option_value']
            );
        }
        $option = $data[0];
        for($i=0; $i<$row-1; $i++) {
            $option = array_merge($option, $data[$i+1]);
        }
        return $option;
    }
}
?>
