<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Users extends CI_Controller {
		public function __construct() {
	      parent::__construct();
				if ($this->router->fetch_method() != 'login' && $this->router->fetch_method() != 'register') {
            if (!isset($_SESSION['loggedInUser']) || $_SESSION['loggedInUser']['type'] != 1) {
                redirect('admin/login');
            }
        }
	      $this->load->library('session');  //Load the Session
	      $this->template->set_theme('backend');
	      date_default_timezone_set('Asia/Saigon');
	      $method = $this->router->fetch_method();
	      $this->template->set('page', $method)->set_breadcrumb('Ads', base_url('index'));
	      //pagination
        $this->load->library('pagination');
				$this->load->helper('url');
	      $this->load->helper('text');
				$this->load->model('user_m');
	  }
    public function user_edit($id) {
        $rules = array(
            array(
                'field' => 'last_name',
                'label' => 'Last name',
                'rules' => 'trim|required|min_length[3]|max_length[100]'
            ),
            array(
                'field' => 'first_name',
                'label' => 'First name',
                'rules' => 'trim|required|min_length[3]|max_length[100]'
            ),
            array(
                'field' => 'address',
                'label' => 'Địa chỉ',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'phone',
                'label' => 'Số điện thoại',
                'rules' => 'trim|min_length[9]|max_length[15]|numeric|is_natural'
            ),
            array(
                'field' => 'email',
                'label' => 'Địa chỉ email',
                'rules' => 'trim|valid_email|max_length[50]'
            ),
            array(
                'field' => 'password',
                'label' => 'Mật khẩu mới',
                'rules' => 'trim|min_length[6]|md5'
            )
        );
        $this->form_validation->set_rules($rules);
        if ($this->form_validation->run($this)) {
            $button = $_POST['button'];
            unset($_POST['button']);
            if(empty($_POST['password'])) {
                unset($_POST['password']);
            }
            $this->user_m->edit($this->input->post(), $id);
            if($button == 'save') {
                redirect('admin/users/edit/'.$id);
            } else {
                redirect('admin/users');
            }
        } else {
            $data['user'] = $this->user_m->get_user($id);
            $this->template->title('Chỉnh sửa thành viên')->build('edit-user', $data);
        }
    }
    public function users() {
        $rules = array(
            array(
                'field' => 'last_name',
                'label' => 'Last name',
                'rules' => 'trim|required|min_length[3]|max_length[100]'
            ),
            array(
                'field' => 'first_name',
                'label' => 'First name',
                'rules' => 'trim|required|min_length[3]|max_length[100]'
            ),
            array(
                'field' => 'phone',
                'label' => 'Số điện thoại',
                'rules' => 'trim|min_length[9]|max_length[15]|numeric|is_natural'
            ),
            array(
                'field' => 'email',
                'label' => 'Địa chỉ email',
                'rules' => 'trim|required|valid_email|max_length[50]'
            ),
            array(
                'field' => 'password',
                'label' => 'Mật khẩu mới',
                'rules' => 'trim|required|min_length[6]|md5'
            )
        );
        $this->form_validation->set_rules($rules);
        if ($this->form_validation->run($this)) {
            $register = $this->user_m->register($this->input->post());
            if($register) {
                $this->session->set_flashdata('return_register', 1);
            }
            redirect('admin/users');
        } else {
            $config = $this->pagination(30, 'users');
            $config['uri_segment'] = 3;
            $config['total_rows'] = $this->user_m->count_all_users();
            $this->pagination->initialize($config);
            $data['users'] = $this->user_m->all_user($config['per_page'],$this->uri->segment(3));
            $this->template->title('Danh sách thành viên')->build('user', $data);
        }
    }
		public function login() {
        if (isset($_SESSION['loggedInUser'])) {
            redirect('admin');
        }
        $rules = array(
            array(
                'field' => 'email',
                'label' => 'Email của bạn',
                'rules' => 'trim|required|valid_email|max_length[50]'
            ),
            array(
                'field' => 'password',
                'label' => 'Mật khẩu',
                'rules' => 'trim|required|md5'
            )
        );
        $this->form_validation->set_rules($rules);
        if ($this->form_validation->run($this)) {
            $this->load->model('user_m');
            $login = $this->user_m->login($this->input->post('email'),$this->input->post('password'));
            if($login != false) {
                $this->session->set_userdata('loggedInUser', $login);
                redirect('admin');
            } else {
                $notification = '<small>Tên đăng nhập hoặc mật khẩu không đúng</small>';
                $this->template->set('notification', $notification)->title('Đăng nhập')->build('login');
            }
        } else {
            $this->template->title('Đăng nhập hệ thống')->build('login');
        }
    }
    public function delete_user($id) {
        $this->user_m->delete_user($id);
        redirect('admin/users');
    }
    public function bulk_action_user() {
        if(!empty($_POST['bulk_action_user'])) {
            if(isset($_POST['id'])) {
                if($_POST['bulk_action_user'] == 'delete') {
                    foreach ($_POST['id'] as $value) {
                        $this->user_m->delete_user($value);
                    }
                }
            }
        }
        redirect('admin/users');
    }
    public function pagination($number = 30, $name) {
        $config['per_page'] = $number;
        $config['full_tag_open'] = '<ul class="pagination"><li class="page-item">';
        $config['full_tag_close'] = '</li></ul>';
        $config['attributes'] = array('class' => 'page-link');
        $config['first_link'] = 'Trang đầu';
        $config['last_link'] = 'Trang cuối';
        $config['next_link'] = '<i class="fa fa-angle-double-right"></i>';
        $config['prev_link'] = '<i class="fa fa-angle-double-left"></i>';
        $config['base_url'] = base_url('admin/'.$name);
        return $config;
    }
}
?>
