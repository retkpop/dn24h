<?php

Class Home_m extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function communities() {
      $communities = $this->db->get('communities');
      if($communities->num_rows()>0) {
        foreach ($communities->result_array() as $community) {
          $community['numb_post'] = $this->db->where('community_id', $community['id'])->get('community_posts')->num_rows();
          $community['thumbnail'] = (!empty($community['thumbnail']))? base_url('uploads/community/thumbnail_community/'.$community['thumbnail']) : base_url('uploads/images/no-thumbnail.jpg');
          $community['url'] = base_url('congdong/'.$community['slug']);
          $datas[] = $community;
        }
        return $datas;
      }
      return false;
    }
    public function posts_hot($limit) {
      $posts = $this->db->limit($limit)->order_by('id', 'desc')->where('status', 1)->get('posts');
      if($posts->num_rows()>0) {
          $postData = array();
          foreach ($posts->result_array() as $post) {
              $post['url'] = base_url($post['slug']. '-' . $post['id'] . '.html');
              $date = date_create($post['date_post']);
              $name_sl = date_format($date,"Y/m");
              $post['date_post'] = date_format($date,"d/m/Y");
              $post['thumbnail'] = (!empty($post['thumbnail']))? base_url('uploads/thumbnail_post/' . $name_sl . '/' .$post['thumbnail']) : base_url('uploads/images/no-thumbnail.jpg');
              $author = $this->db->where('id', $post['author_id'])->get('users')->row_array();
              $post['author_name'] = $author['last_name'] . ' ' . $author['first_name'];
              $postData[] = $post;
          }
          return $postData;
      }
      return false;
    }
    public function list_post_news($limit) {
      $posts = $this->db->limit($limit)->order_by('id', 'desc')->get('posts');
      if($posts->num_rows()>0) {
          $postData = array();
          $keyHot = 0;
          foreach ($posts->result_array() as $post) {
            if($keyHot < 5) {
              if($post['status'] != 1) {
                $post['url'] = base_url($post['slug']. '-' . $post['id'] . '.html');
                $date = date_create($post['date_post']);
                $name_sl = date_format($date,"Y/m");
                $post['date_post'] = date_format($date,"d/m/Y");
                $post['thumbnail'] = (!empty($post['thumbnail']))? base_url('uploads/thumbnail_post/' . $name_sl . '/' .$post['thumbnail']) : base_url('uploads/images/no-thumbnail.jpg');
                $author = $this->db->where('id', $post['author_id'])->get('users')->row_array();
                $post['author_name'] = $author['last_name'] . ' ' . $author['first_name'];
                $postData[] = $post;
              } else {
                $keyHot++;
                unset($post);
              }
            } else {
              $post['url'] = base_url($post['slug']. '-' . $post['id'] . '.html');
              $date = date_create($post['date_post']);
              $name_sl = date_format($date,"Y/m");
              $post['date_post'] = date_format($date,"d/m/Y");
              $post['thumbnail'] = (!empty($post['thumbnail']))? base_url('uploads/thumbnail_post/' . $name_sl . '/' .$post['thumbnail']) : base_url('uploads/images/no-thumbnail.jpg');
              $author = $this->db->where('id', $post['author_id'])->get('users')->row_array();
              $post['author_name'] = $author['last_name'] . ' ' . $author['first_name'];
              $postData[] = $post;
            }

          }
          return $postData;
      }
      return false;
    }
}
?>
