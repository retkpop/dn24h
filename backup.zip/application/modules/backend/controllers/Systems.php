<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Systems extends CI_Controller {
	public function __construct() {
      parent::__construct();
      $this->load->library('session');  //Load the Session
      $this->template->set_theme('frontend');
      date_default_timezone_set('Asia/Saigon');
      $method = $this->router->fetch_method();
      $this->template->set('page', $method)->set_breadcrumb('HomePage', base_url('index'));
      //pagination
      $this->load->library('pagination');
			$this->load->helper('text');
      $this->load->helper('url');
  }
	public function createSlug($str) {
			if ((bool) $str == false) {
					exit('');
			}
			$str = mb_strtolower(urldecode($str));
			echo url_title(removesign($str), '-');
	}
}
