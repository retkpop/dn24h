<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Community extends CI_Controller {
	public function __construct() {
      parent::__construct();
      if ($this->router->fetch_method() != 'login' && $this->router->fetch_method() != 'register') {
          if (!isset($_SESSION['loggedInUser']) || $_SESSION['loggedInUser']['type'] != 1) {
              redirect('admin/login');
          }
      }
      $this->load->library('session');  //Load the Session
      $this->template->set_theme('backend');
      date_default_timezone_set('Asia/Saigon');
      $method = $this->router->fetch_method();
			$this->load->library('pagination');
      //pagination
			$this->load->helper('url');
      $this->load->helper('text');
			$this->load->model('community_m');
			$this->template->set('page', $method)->set_breadcrumb('Home page', base_url('index'));
  }
	public function edit_community(){
		if(empty($this->input->get('id'))) {
				redirect('admin/community/add');
		}
		$id = $this->input->get('id');
		$rules = array(
				array (
						'field' => 'name',
						'label' => 'Tên cộng đồng',
						'rules' => 'trim|required'
				),
				array (
						'field' => 'name_seo',
						'label' => 'Tên cộng đồng SEO',
						'rules' => 'trim|required'
				),
				array (
						'field' => 'slug',
						'label' => 'Đường dẫn cộng đồng',
						'rules' => 'trim|required'
				),
				array (
						'field' => 'description',
						'label' => 'Mô tả danh mục',
						'rules' => 'trim|required'
				),
		);
		$this->form_validation->set_rules($rules);
		if($this->form_validation->run($this)) {
			if($_FILES['thumbnail']['name'] != ''){
          if(isset($_POST['old_thumb']) && $_POST['old_thumb'] != '') {
              $old_thumb = $_POST['old_thumb'];
          } else {
              $old_thumb = false;
          }
          $_POST['thumbnail'] =  $this->thumb_edit('community/thumbnail_community', 'thumbnail', $old_thumb);
      }
      unset($_POST['old_thumb']);
			$this->community_m->edit_community($this->input->post(),$id);
			redirect('admin/community/edit?id=' .$id);
		} else {
			$data['community'] = $this->community_m->get_community_by_id($id);
			$this->template->title('Sửa cộng đồng')->build('edit-community', $data);
		}
	}
	public function delete_community(){
		$this->community_m->delete_community($this->input->post('id'));
		echo 1;
	}
	public function thumb_edit($name_sl, $name_file, $old_thumb = false) {
        $path = dirname(BASEPATH) . '/uploads/'. $name_sl .'/';
        $tmp_name = $_FILES[$name_file]['tmp_name'];
        $name = $_FILES[$name_file]['name'];
        $array = explode('.', $name);
        $n = count($array);
        $name_file = md5(microtime() . rand(1, 1000));
        $new_name = $name_file . '.' . $array[$n - 1];
        if($old_thumb != false) {
            $path_old = dirname(BASEPATH) . '/uploads/' . $name_sl . '/' . $old_thumb;
            unlink($path_old);
        }
        move_uploaded_file($tmp_name, $path . $new_name);
        return $new_name;
    }
	public function list_discuss() {
			$config = $this->tk_system->pagination(30, 'communities');
			$config['uri_segment'] = 3;
			$config['total_rows'] = $this->community_m->count_all_discuss();
			$this->pagination->initialize($config);
			$data['communities'] = $this->community_m->all_discussion($config['per_page'],$this->uri->segment(3));
      $data['info'] = array (
          'title' => 'Cộng đồng',
          'description' => 'Trang thông tin thảo luận, chia sẽ liên quan đến các đề tài',
      );
			$this->template->title('Cộng đồng')->build('community', $data);
	}
	public function delete_discuss($id) {
		$this->community_m->delete_discuss($id);
		redirect('admin/communities');
	}
	public function bulk_action_community() {
			if(!empty($_POST['bulk_action_community'])) {
					if(isset($_POST['id'])) {
							if($_POST['bulk_action_community'] == 'delete') {
									foreach ($_POST['id'] as $value) {
											$this->community_m->delete_discuss($value);
									}
							}
					}
			}
			redirect('admin/communities');
	}
  public function add_community() {
      $rules = array(
          array (
              'field' => 'name',
              'label' => 'Tên cộng đồng',
              'rules' => 'trim|required'
          ),
          array (
              'field' => 'name_seo',
              'label' => 'Tên cộng đồng SEO',
              'rules' => 'trim|required'
          ),
          array (
              'field' => 'slug',
              'label' => 'Đường dẫn cộng đồng',
              'rules' => 'trim|required'
          ),
          array (
              'field' => 'description',
              'label' => 'Mô tả danh mục',
              'rules' => 'trim|required'
          ),
      );
      $this->form_validation->set_rules($rules);
      if($this->form_validation->run($this)) {
          if(isset($_FILES['thumbnail_community']['name']) && $_FILES['thumbnail_community']['name'] != ''){
              $name_sl = 'community/thumbnail_community/';
              $_POST['thumbnail'] = $this->file_upload($name_sl, 'thumbnail_community');
          }
          $this->community_m->insert_community($this->input->post());
          redirect('admin/community/add');
      } else {
          $data['info'] = array (
              'title' => 'Cộng đồng',
              'description' => 'Trang thông tin thảo luận, chia sẽ liên quan đến các đề tài',
          );
          $data['communities'] = $this->community_m->communities();
          $this->template->title('Thêm trang cộng đồng')->build('add_community', $data);
      }
	}
  public function file_upload($name_sl, $name_file) {
      if (!is_dir('uploads/'. $name_sl .'/')) {
          mkdir('uploads/'. $name_sl .'', 0777, true);
      }
      $path = dirname(BASEPATH) . '/uploads/'. $name_sl .'/';
      $tmp_name = $_FILES[$name_file]['tmp_name'];
      $name = $_FILES[$name_file]['name'];
      $array = explode('.', $name);
      $n = count($array);
      $name_file = md5(microtime() . rand(1, 1000));
      if($_FILES[$name_file]['error']==0){
          $new_name = $name_file . '.' . $array[$n - 1];
          move_uploaded_file($tmp_name, $path . $new_name);
          return $new_name;
      } else {
          $new_name = '';
          return $new_name;
      }
  }
	public function add_post() {
		$data['info'] = array (
				'title' => 'Đăng bài cộng đồng',
				'description' => 'Đăng bài chia sẽ thông tin, hỏi đáp cộng đồng',
		);
		$this->template->title('Website')->build('add-post', $data);
	}
}
